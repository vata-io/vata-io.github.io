<?php

/*******************************************************************************

 *
 * 	AlterVision Core Framework - CPA platform
 * 	Created by AlterVision - altervision.me
 *  Copyright © 2014-2017 Anton Reznichenko
 *

 *
 *  File: 			spacing zone / cms.php
 *  Description:	Spacing site simple CMS
 *  Author:			Anton 'AlterVision' Reznichenko - altervision13@gmail.com
 *

*******************************************************************************/

// Loading configuration
define( 'PATH', dirname(__FILE__) . '/' );
require_once PATH . 'config.php';

// Generic CURL request
function curl( $url ) {
	$curl = curl_init( $url );
	curl_setopt( $curl, CURLOPT_RETURNTRANSFER, 1 );
	curl_setopt( $curl, CURLOPT_FOLLOWLOCATION, 1 );
	curl_setopt( $curl, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:45.0) Gecko/20100101 Firefox/45.0' );
	$result = curl_exec( $curl );
	curl_close( $curl );
	return $result;
}

// Add 5-second period
if (isset( $_GET['good'] )) {	$gid = (int) $_GET['good'];
	if ( $gid ) curl( BASEURL . CC . '?g=' . $gid );
	die();
}

// URL creator
header( 'Content-type: text/html; charset=utf-8' );
function geturl ( $lands, $space, $defland ) {

	global $flow, $vid, $mtrk0; // I know I'll burn in hell for this ...
	$land = false;

	// Processing new flow from AlterCPA
	if ( $_GET['flow'] && $f = preg_replace( '#[^0-9\-]#i', '', $_GET['flow'] ) ) {
		$newflow = $f;
	} elseif ( preg_match( "#^([0-9\-]+)#i", $_SERVER['QUERY_STRING'], $mf ) ) {
		$newflow = $mf[0];
	} else $newflow = false;
	$unique = ( $newflow && $newflow != $_COOKIE['flow'] ) ? true : false;

	// Setting up flow id
	if ( $newflow ) {
		$flow = $newflow;
		setcookie( 'flow', $newflow, time() + 2592000, '/' );
	} else $flow = $_COOKIE['flow'] ? preg_replace( '#[^0-9\-]#i', '', $_COOKIE['flow'] ) : false;

	// Processing external ID from function
	if (function_exists( 'ext' )) {
		$ee = ext();
		$exti = $ee['i'] ? $ee['i'] : 0;
		$extu = $ee['u'] ? $ee['u'] : 0;
		$exts = $ee['s'] ? $ee['s'] : 0;
	} else $exti = $extu = $exts = 0;

	// Processing external ID by direct
	if ( $newexti = (int) $_GET['exti'] ) {		$exti = $newexti;
		$extu = preg_replace( '#[^0-9A-Za-z\_\-]+#i', '', $_GET['extu'] );
		$exts = preg_replace( '#[^0-9]+#i', '', $_GET['exts'] );
	}

	// Set up EXT cookie
	if ( $exti ) {
		if ( $_COOKIE['extd'] ) {
			$extd = explode( ':', $_COOKIE['extd'] );
			$unique = ( $extd[0] == $exti ) ? false : true;
		} else $unique = true;
		setcookie( 'extd', "$exti:$extu:$exts", $now + 86400, '/' );
	} else list( $exti, $extu, $exts ) = $_COOKIE['extd'] ? explode( ':', $_COOKIE['extd'] ) : array( 0, 0, 0 );

	// New Flow vs. ExtID
	if ( $newflow && $exti ) {
		unset( $exti, $extd, $extu );
		setcookie( 'extd', '', time() - 2592000, '/' );
	} elseif ( $exti && $flow ) {
		unset( $flow );
		setcookie( 'flow', '', time() - 2592000, '/' );
	}

	// Choosing langing by flow
	if ( $flow ) {
		if ( strpos( $flow, '-' ) !== false ) {
			$ff = explode( '-', $flow );
			$flow = (int) $ff[0];
			$land = (int) $ff[1];
		}
	}

	// Choose landing by default
	if ( isset( $_GET['l'] ) ) $land = (int) $_GET['l'];
	if ( ! $lands[$land] ) $land = $defland;

	// Choosing partner program
	if ( $flow ) {
		$line = $flow;
	} elseif ( $exti ) {
		$line = 'exti=' . $exti;
		if ( $extu ) $line .= '&extu=' . $extu;
		if ( $exts ) $line .= '&exts=' . $exts;
	} else $line = '';

	// Metrika
	if ( $_GET['mtrk'] && $mtrk = preg_replace( '#[^0-9\_]+#i', '', $_GET['mtrk'] ) ) {
		setcookie( 'mtrk', $mtrk, $now + 300, '/' );
	} else $mtrk = $_COOKIE['mtrk'] ? (int) $_COOKIE['mtrk'] : false;
	if ( strpos( $mtrk, '_' ) !== false ) {
		$mtrk = explode( '_', $mtrk );
		$mtrk0 = $mtrk[0];
		$mtrk1 = $mtrk[1];
	} else $mtrk0 = $mtrk1 = $mtrk;
	if ( $mtrk1 ) $line .= '&mtrk='.$mtrk1;

	//
	// Generic UTM analysis
	//

	// Get new UTM
	$hasutm = false;
	if (isset($_GET['utm_source']) && $_GET['utm_source'] ) $hasutm = $us = mb_substr(filter_var( $_GET['utm_source'], FILTER_SANITIZE_STRING ), 0, 50);
	if (isset($_GET['utm_campaign']) && $_GET['utm_campaign'] ) $hasutm = $uc = mb_substr(filter_var( $_GET['utm_campaign'], FILTER_SANITIZE_STRING ), 0, 50);
	if (isset($_GET['utm_content']) && $_GET['utm_content'] ) $hasutm = $un = mb_substr(filter_var( $_GET['utm_content'], FILTER_SANITIZE_STRING ), 0, 50);
	if (isset($_GET['utm_term']) && $_GET['utm_term'] ) $hasutm = $ut = mb_substr(filter_var( $_GET['utm_term'], FILTER_SANITIZE_STRING ), 0, 50);
	if (isset($_GET['utm_medium']) && $_GET['utm_medium'] ) $hasutm = $um = mb_substr(filter_var( $_GET['utm_medium'], FILTER_SANITIZE_STRING ), 0, 50);

	// Reset UTM or get the old ones
	$ass = '(!)'; // hope nobody uses it in UTM ...
	if ( $hasutm === false ) {
		if ( $_COOKIE['utm'] ) list( $us, $uc, $un, $ut, $um ) = explode( $ass, $_COOKIE['utm'] );
	} else setcookie( 'utm', $us.$ass.$uc.$ass.$un.$ass.$ut.$ass.$um, time() + 86400, '/' );

	// Add UTM to the line
	if ( $us ) $line .= '&utm_source='.rawurlencode($us);
	if ( $uc ) $line .= '&utm_campaign='.rawurlencode($uc);
	if ( $un ) $line .= '&utm_content='.rawurlencode($un);
	if ( $ut ) $line .= '&utm_term='.rawurlencode($ut);
	if ( $um ) $line .= '&utm_medium='.rawurlencode($um);

	// Checking for the Spacer ID
	$ru = explode( '/', trim( strtr( $_SERVER['REQUEST_URI'], '?', '/' ), '/' ) );
	$uu = str_replace( 'www.', '', $_SERVER['HTTP_HOST'] ) . '/' . $ru[0];
	if ( $sp = $space[$uu] ) $line .= '&sp=' . $sp;

	// Adding new click
	if ( $flow || $exti ) {
		$req = 'o='.OFFER.'&s='.$sp.'&b='.$land.'&p=1&ip=' . sprintf( "%u", ip2long( ip() ) );
		if ( $flow ) $req .= '&f=' . $flow;
		if ( $exti ) $req .= '&ei=' . $exti;
		if ( $exts ) $req .= '&es=' . $exts;
		if ( $unique ) $req .= '&u=1';
		if ( $us ) $req .= '&us='.rawurlencode($us);
		if ( $uc ) $req .= '&uc='.rawurlencode($uc);
		if ( $un ) $req .= '&un='.rawurlencode($un);
		if ( $ut ) $req .= '&ut='.rawurlencode($ut);
		if ( $um ) $req .= '&um='.rawurlencode($um);
		$res = curl( BASEURL . CC . '?' . $req );
		$res = explode( ':', trim( $res ), 2 );
		if (!( $res[0] == 'ok' || $res[0] == 'e' )) file_put_contents( PATH.'click.txt', $req . "\r\n", FILE_APPEND | LOCK_EX  );
		$vid = $res[1];
	} else $vid = 0;

	$theurl = $lands[$land] . $line;
	return $theurl;

}

function footer () {

	global $vid, $mtrk0;

	if ( $vid ) : ?><script type="text/javascript">
function noregret(){var xx = new XMLHttpRequest();xx.open("GET","?good=<?=$vid;?>&z="+Math.random(),true);xx.send(null);setTimeout("noregret()",500);}function trytosee(){isd&&(setTimeout("noregret()",500),isd=!1)}var isd=!0;window.onload=function(){document.hidden||document.msHidden||document.webkitHidden||document.mozHidden?window.onfocus=function(){trytosee(),window.onfocus=null}:trytosee()};
</script><? endif;

	if ( $mtrk0 ) : ?><!-- Yandex.Metrika counter --><script type="text/javascript"> (function (d, w, c) { (w[c] = w[c] || []).push(function() { try { w.yaCounter<?=$mtrk0;?> = new Ya.Metrika({ id:<?=$mtrk0;?>, clickmap:true, trackLinks:true, accurateTrackBounce:true, webvisor:true }); } catch(e) { } }); var n = d.getElementsByTagName("script")[0], s = d.createElement("script"), f = function () { n.parentNode.insertBefore(s, n); }; s.type = "text/javascript"; s.async = true; s.src = "https://mc.yandex.ru/metrika/watch.js"; if (w.opera == "[object Opera]") { d.addEventListener("DOMContentLoaded", f, false); } else { f(); } })(document, window, "yandex_metrika_callbacks"); </script><noscript><div><img src="https://mc.yandex.ru/watch/<?=$mtrk0;?>" style="position:absolute; left:-9999px;" alt="" /></div></noscript><!-- /Yandex.Metrika counter --><?
	elseif (defined( 'METRIKA' )) : ?><!-- Yandex.Metrika counter --><script type="text/javascript"> (function (d, w, c) { (w[c] = w[c] || []).push(function() { try { w.yaCounter<?=METRIKA;?> = new Ya.Metrika({ id:<?=METRIKA;?>, clickmap:true, trackLinks:true, accurateTrackBounce:true, webvisor:true }); } catch(e) { } }); var n = d.getElementsByTagName("script")[0], s = d.createElement("script"), f = function () { n.parentNode.insertBefore(s, n); }; s.type = "text/javascript"; s.async = true; s.src = "https://mc.yandex.ru/metrika/watch.js"; if (w.opera == "[object Opera]") { d.addEventListener("DOMContentLoaded", f, false); } else { f(); } })(document, window, "yandex_metrika_callbacks"); </script><noscript><div><img src="https://mc.yandex.ru/watch/<?=METRIKA;?>" style="position:absolute; left:-9999px;" alt="" /></div></noscript><!-- /Yandex.Metrika counter --><? endif;

if ( strpos( $_SERVER['QUERY_STRING'], 'cb' ) === false && !isset( $_GET['cb'] ) ) return false;

?><script type="text/javascript">
		var ua = navigator.userAgent;
    	if (!ua.match(/MSIE/)){
			var d = document.getElementsByTagName('a'), i = d.length, j;
			while(i--){
				j = d[i].attributes.length;
				while(j--){
					if(d[i].attributes[j].name == 'target') d[i].removeAttribute(d[i].attributes[j].name);
				}
			}

			var comebacker = null;
			var cb_jqi = false;
			var cb_ale = false;

			function cb_iJQ() {
				if (!window.jQuery) {
					if (!cb_jqi) {
						if (typeof $ == 'function') cb_ale = true;
						var script = document.createElement('script');
						script.type = "text/javascript";
						script.src = "//ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js";
						document.getElementsByTagName('head')[0].appendChild(script);
						cb_jqi = true;
					}
					setTimeout('cb_iJQ()', 50);
				} else {
					if (true == cb_ale) {
						$j = jQuery.noConflict();
					} else {
						$j = jQuery;
					}

					comebacker = '{"settings":{"script_path":"","page_to":"<?=addslashes(ourl());?>","how_often_show":"every_time","button_name_capitalization":"first_upper","work_page":"","working_in_opera":"on","working_in_opera_after":"3"},"exit_text":"**********************************\\n\\nВНИМАНИЕ!!! УНИКАЛЬНЫЙ ШАНС! СКИДКА 50%!\\n\\n**********************************\\n\\nТолько СЕЙЧАС в течение 30 минут у Вас есть шанс получить скидку 50%!\\n\\nНажмите на кнопку \\"Остаться на странице\\" и получите ГРАНДИОЗНУЮ СКИДКУ!","bar":{"link_text_left":"\u0421\u0434\u0435\u043b\u0430\u043d\u043e \u0441 \u043f\u043e\u043c\u043e\u0449\u044c\u044e \\\"Comebacker\\\"","link_text_right":"\u0414\u0430\u043d\u043d\u044b\u0439 \u0441\u043a\u0440\u0438\u043f\u0442 \u043c\u043e\u0436\u043d\u043e \u043f\u043e\u043b\u0443\u0447\u0438\u0442\u044c \u043a\u043b\u0438\u043a\u043d\u0443\u0432 \u0441\u044e\u0434\u0430","link_href":"<?=addslashes(ourl());?>","height":"0","background_color":"c9c7c7","link_size":"0","link_color":"242424"},"module_where_loaded":"site"}';
					jQuery.ajax({ type: "GET", url: "/comebacker/comebacker.js", data: {}, dataType: "script" });
				}
			}
			cb_iJQ();
		}
	</script><?

}

// Remote IP address
function ip() {
	static $ip;
	if (isset( $ip )) return $ip;
	if ( $_SERVER['HTTP_X_FORWARDED_FOR'] ) {
		if (strpos( $_SERVER['HTTP_X_FORWARDED_FOR'], ',' ) !== false ) {
			$xffd = explode( ',', $_SERVER['HTTP_X_FORWARDED_FOR'] );
			foreach ( $xffd as $xff ) {
				$xff = trim( $xff );
				$ip = filter_var( $xff, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 | FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE );
				if ( $ip ) break;
			}
		} else $ip = filter_var( $_SERVER['HTTP_X_FORWARDED_FOR'], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 | FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE );
	}
	if ( ! $ip ) $ip = filter_var( $_SERVER['HTTP_CLIENT_IP'], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 | FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE );
	if ( ! $ip ) $ip = $_SERVER['REMOTE_ADDR'];
	return $ip;
}