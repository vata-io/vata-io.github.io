<?php

/*******************************************************************************

 *
 * 	AlterVision Core Framework - CPA platform
 * 	Created by AlterVision - altervision.me
 *  Copyright � 2005-2017 Anton Reznichenko
 *

 *
 *  File: 			spacing zone / config.php
 *  Description:	Spacing Zone Configuration
 *  Author:			Anton 'AlterVision' Reznichenko - altervision13@gmail.com
 *

*******************************************************************************/

setlocale( LC_ALL , 'ru_RU.UTF-8' );
mb_language( 'uni' );
mb_internal_encoding( 'utf-8' );

// The base URL where cc.php can be found
// Something like: http://work.cpa/
define ( 'BASEURL', 'http://work.cpa/' );

// Name of counting script
// Default: cc.php
define ( 'CC', 'cc.php' );

// Yandex Metrika ID
//define ( 'METRIKA', '' );

// External processing
// Must return array( 'i' => exti, 'u' => extu, 's' => exts )
/*function ext () {
	if ( $_GET['pumo'] && is_numeric( $_GET['pumo'] ) ) {		return array( 'i' => 13, 'u' => preg_replace( '#[^0-9]+#i', '', $_GET['pumo'] ), 's' => 0 );
	} else return array();

}*/

// That's all, folks