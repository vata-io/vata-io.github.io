<?php

/*******************************************************************************

 *
 * 	AlterVision Core Framework - CPA platform
 * 	Created by AlterVision - altervision.me
 *  Copyright � 2005-2017 Anton Reznichenko
 *

 *
 *  File: 			spacing zone / cron.php
 *  Description:	Lost clicks processor
 *  Author:			Anton 'AlterVision' Reznichenko - altervision13@gmail.com
 *

*******************************************************************************/

// Loading configuration
define( 'PATH', dirname(__FILE__) . '/' );
require_once PATH . 'config.php';

// Generic CURL request
function curl( $url ) {
	$curl = curl_init( $url );
	curl_setopt( $curl, CURLOPT_RETURNTRANSFER, 1 );
	curl_setopt( $curl, CURLOPT_FOLLOWLOCATION, 1 );
	curl_setopt( $curl, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:45.0) Gecko/20100101 Firefox/45.0' );
	$result = curl_exec( $curl );
	curl_close( $curl );
	return $result;
}

// Process the lost clicks
if (file_exists( PATH . 'click.txt' )) {	rename( PATH . 'click.txt', PATH . 'click-work.txt' );
	$clicks = file( PATH . 'click-work.txt' );
	$badclick = array();
	foreach ( $clicks as &$c ) if ( $req = trim( $c ) ) {		$res = curl( BASEURL . CC . '?' . $req );
		$res = explode( ':', trim( $res ), 2 );
		if (!( $res[0] == 'ok' || $res[0] == 'e' )) $badclick[] = $req;
	} unset ( $c, $clicks );
	if ( $badclick ) file_put_contents( dirname(__FILE__) . '/click.txt', implode( "\r\n", $badclick ) . "\r\n", FILE_APPEND | LOCK_EX  );
	unlink( PATH . 'click-work.txt' );
}