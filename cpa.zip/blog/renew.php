<?php

/*******************************************************************************

 *
 * 	AlterVision Core Framework - CPA platform
 * 	Created by AlterVision - altervision.me
 *  Copyright � 2005-2017 Anton Reznichenko
 *

 *
 *  File: 			spacing zone / renew.php
 *  Description:	Spacing zone renewal script
 *  Author:			Anton 'AlterVision' Reznichenko - altervision13@gmail.com
 *

*******************************************************************************/

// Loading configuration
define( 'PATH', dirname(__FILE__) . '/' );
require_once PATH . 'config.php';

$id = (int) $_GET['id'];
if ( ! $id ) die( 'oops!' );

$data = json_decode( file_get_contents( BASEURL.'api/wm/land.json?oid=' . $id ), true );
if ( ! $data ) die( 'oops!!' );

$o = '<?
require_once "cms.php";
function ourl () {
static $theurl;
global $flow;
define( \'OFFER\', '.$id.' );
if ( $theurl ) return $theurl;
$defland = '.$data['default'].';
$lands = '.var_export( $data['lands'], true ).';
$space = '.var_export( $data['space'], true ).';
$theurl = geturl ( $lands, $space, $defland );
return $theurl;
}';

file_put_contents( PATH . 'offer'.$id.'.php', $o );
die( 'ok' );