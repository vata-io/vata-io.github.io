<?php

/*******************************************************************************

 *
 * 	AlterVision Core Framework - CPA platform
 * 	Created by AlterVision - altervision.me
 *  Copyright © 2005-2015 Anton Reznichenko
 *

 *
 *  File: 			core / lang_ru.php
 *  Description:	Language file
 *  Author:			Anton 'AlterVision' Reznichenko - altervision13@gmail.com
 *

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 2 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.

*******************************************************************************/

global $lang;
mb_language( 'uni' );
mb_internal_encoding( 'utf-8' );

$lang = array (

	// ************************************
    // Basic
    // ************************************

    'site_name'							=> 'MyCPA',
    'site_descr'						=> 'MyCPA - платформа автоматизации интернет-торговли',
    'site_url'							=> 'http://my.cpa',
    'site_meta_k'						=> '',
    'site_meta_d'						=> '',
    'site_copyright'					=> '© 2014-'.date('Y').'г. MyCPA - платформа автоматизации интернет-торговли',
    'cms_powered_by'					=> '<a href="/help/index.html">Помощь</a> | <a href="/help/faq.html">FAQ</a> | <a href="/help/api.html">API</a>',
    'partner_link'						=> 'http://work.cpa',

	'menu_search'						=> 'Поиск',
	'menu_about'						=> 'О проекте',
	'menu_partner'						=> 'Партнёрам',

    // ************************************
    // Common
    // ************************************

	'action' 					=> 'Действие',
	'active' 					=> 'Активный',
	'activity' 					=> 'Активность',
	'actor'						=> 'Участник',
	'actors'					=> 'Участники',
	'address'					=> 'Адрес',
    'all'						=> 'Все',
    'any'						=> '-- не установлено --',
	'author'					=> 'Автор',
	'art'						=> 'Статья',
	'avatar'					=> 'Аватар',
	'cancel' 					=> 'Отменить',
	'cash'						=> 'Сумма',
	'call'						=> 'Позвонить',
	'check' 					=> 'Проверить',
    'comment'					=> 'Комментарий',
    'comments'					=> 'Комментарии',
    'company'					=> 'Компания',
	'confirm' 					=> 'Вы уверены, что хотите удалить этот объект?',
	'confirma' 					=> 'Вы уверены, что хотите выполнить это действие?',
	'confirms' 					=> 'Вы уверены, что хотите удалить этот объект?\nВведите \"delete\" для подтверждения.',
    'contacts'					=> 'Контакты',
    'control'					=> 'Управление',
	'count' 					=> 'Количество',
	'course' 					=> 'Курс',
    'create'					=> 'Создать',
	'date'						=> 'Дата',
	'default' 					=> 'По умолчанию',
    'del'						=> 'Удалить',
    'dept'						=> 'Отдел',
	'descr' 		   			=> 'Описание',
	'div'						=> 'Раздел',
	'do' 						=> 'Выполнить',
	'done' 						=> 'Выполнено',
	'download' 					=> 'Скачать',
    'edit'						=> 'Правка',
	'email' 					=> 'E-Mail',
	'enter' 					=> 'Вход',
	'exit'						=> 'Выход',
	'file' 						=> 'Файл',
	'filter'					=> 'Отфильтровать',
	'find'						=> 'Найти',
	'flush'						=> 'Очистить',
	'folder' 					=> 'Папка',
	'ftext' 					=> 'Полный текст',
    'gallery'					=> 'Галерея',
	'headline' 		 			=> 'Заголовок',
	'hidden' 		 			=> 'cкрытый',
	'icq' 						=> 'ICQ',
	'id' 						=> 'Идентификатор',
	'image' 					=> 'Картинка',
    'index'						=> 'Индекс',
    'inf'						=> 'Инфо',
    'info'						=> 'Информация',
	'install' 					=> 'Установить',
	'lastvisit' 				=> 'Последний визит',
	'level' 					=> 'Уровень',
	'link' 						=> 'Ссылка',
	'login' 					=> 'Логин',
	'logout'					=> 'Выход',
	'logo' 						=> 'Логотип',
	'message_redirect'			=> 'Если браузер не перенаправляет Вас автоматически, нажмите эту ссылку',
	'more'						=> 'Подробнее',
	'month'						=> 'Месяц',
	'months'					=> array ( 'Нулябрь', 'Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь' ),
	'name'						=> 'Название',
	'no' 						=> 'Нет',
	'next' 						=> 'Далее',
	'ord'						=> 'Порядок',
	'order'						=> 'Заказ',
	'pay'						=> 'Оплатить',
	'pass' 						=> 'Пароль',
    'phone'						=> 'Телефон',
    'price'						=> 'Цена',
    'progress'					=> 'Прогресс',
	'pub' 						=> 'Публичный',
    'published'					=> 'Опубликовано',
	'rating' 					=> 'Рейтинг',
    'read_more'					=> 'Подробнее',
    'recount'					=> 'Пересчитать',
    'register'					=> 'Регистрация',
	'reset' 					=> 'Сбросить',
	'results'					=> 'Результаты',
	'report'					=> 'Отчёт',
	'requests'					=> 'Заявки',
	'save' 						=> 'Сохранить',
	'search'					=> 'Поиск',
	'send' 						=> 'Передать',
	'settings'					=> 'Настройка',
	'shown'						=> 'Показаны с %d по %d из %d',
	'size' 						=> 'Размер',
	'site' 						=> 'Веб-сайт',
	'status'					=> 'Статус',
	'store'						=> 'Склад',
	'subj' 						=> 'Тема',
	'text' 						=> 'Текст',
	'texts' 					=> 'Тексты',
	'time' 						=> 'Время',
    'title'						=> 'Заголовок',
	'today' 					=> 'сегодня в ',
	'total' 					=> 'Итого',
	'track'						=> 'Трек-код',
	'type'						=> 'Тип',
	'update' 					=> 'Обновить',
	'username' 					=> 'Имя',
	'user'						=> 'Пользователь',
	'variants'					=> 'Варианты',
	'view' 						=> 'Просмотреть',
	'views' 					=> 'Просмотры',
	'yes' 						=> 'Да',
	'yesterday' 				=> 'вчера в ',
	'year'						=> 'Год',

	// ***********************************************
	// Interface
	// ***********************************************

	'order_success'				=> '<b>Заказ принят!</b> Менеджер свяжется с Вами в течение часа.',
	'sms_sent'					=> '<b>Пароль отправлен!</b> Укажите пароль из смс для входа',
	'sms_pass'					=> 'Ваш пароль: %s, промо-код: %s',

	'search_h'					=> 'Мой промо-код',
	'search_t1'					=> 'Подробная статистика по заказам с вашим промо-кодом доступна онлайн в режиме реального времени.',
	'search_t2'					=> 'Чтобы узнать всё о привлечённых клиентах, укажите промо-код, полученный от менеджера или в посылке, и нажмите кнопку "Найти".',
	'search_n'					=> 'Промо-код',

	'notfound_h'				=> 'Код не найден ...',
	'notfound_t'				=> 'В системе не обнаружен введённый промо-код. Пожалуйста, уточните код и попробуйте снова.',

	'offer'						=> 'Товар',
	'promost'					=> 'Вознаграждение',

	'promo'						=> array(
							0	=> '<span class="text-muted"><i class="glyphicon glyphicon-time"></i> Ожидание</span>',
							1	=> '<span class="text-success"><i class="glyphicon glyphicon-ok"></i> Выполнено</span>',
							2	=> '<span class="text-danger"><i class="glyphicon glyphicon-remove"></i> Отказано</span>',
	),

	'statuso'					=> array(
							0	=> '<span class="text-muted"><i class="glyphicon glyphicon-time"></i> Обработка</span>',
							1	=> '<span class="text-muted"><i class="glyphicon glyphicon-time"></i> Обработка</span>',
							2	=> '<span class="text-muted"><i class="glyphicon glyphicon-time"></i> Обработка</span>',
							3	=> '<span class="text-muted"><i class="glyphicon glyphicon-time"></i> Обработка</span>',
							4	=> '<span class="text-muted"><i class="glyphicon glyphicon-time"></i> Обработка</span>',
							5	=> '<span class="text-danger"><i class="glyphicon glyphicon-remove"></i> Отменён</span>',
							6	=> '<span class="text-success"><i class="glyphicon glyphicon-ok"></i> Выполнен</span>',
							7	=> '<span class="text-success"><i class="glyphicon glyphicon-ok"></i> Выполнен</span>',
							8	=> '<span class="text-success"><i class="glyphicon glyphicon-ok"></i> Выполнен</span>',
							9	=> '<span class="text-success"><i class="glyphicon glyphicon-ok"></i> Выполнен</span>',
							10	=> '<span class="text-success"><i class="glyphicon glyphicon-ok"></i> Выполнен</span>',
							11	=> '<span class="text-danger"><i class="glyphicon glyphicon-remove"></i> Отменён</span>',
							12	=> '<span class="text-danger"><i class="glyphicon glyphicon-remove"></i> Отменён</span>',
	),

);

?>