<?php

/*******************************************************************************

 *
 * 	AlterVision Core Framework - CPA platform
 * 	Created by AlterVision - altervision.me
 *  Copyright © 2005-2015 Anton Reznichenko
 *

 *
 *  File: 			core / settings.php
 *  Description:	Site additional configs
 *  Author:			Anton 'AlterVision' Reznichenko - altervision13@gmail.com
 *

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 2 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.

*******************************************************************************/

// Database Tables
define( 'DB_OFFER',		SQL_PREF . 'offer' );
define( 'DB_ORDER',		SQL_PREF . 'order' );
define( 'DB_PROMO',		SQL_PREF . 'promo' );

// Promo Code
define ( 'PROMO', '312694187258' ); // 12 digits
define ( 'PROMOAUTH', 1 );

// ByteHand
define ( 'SMS_ID',		'10370' );	// ByteHand API ID
define ( 'SMS_KEY',		'E31337CA050278A9' );	// ByteHand API Key
define ( 'SMS_SIGN',	'Vasenko13' );

//
// Cron-Related Cleanup Functions
//

function crontab ( $core ) {	$core->cron->add ( 'control_cache', 'cron_control_cache', 86400 );
	$core->cron->add ( 'control_session', 'cron_control_session', 86400 );
}

function cron_control_cache ( $core ) {
	cron_control_cleanup ( DIR_CACHE, 86400 );
}

function cron_control_session ( $core ) {
	cron_control_cleanup ( DIR_SESSION, 2592000 );
}

function cron_control_cleanup ( $dir, $timeout ) {

	$timeout = time() - $timeout;
	$d = @opendir ( $dir );
	while ( $f = @readdir ( $d ) ) {
		if (is_file( $dir.$f )) {
			if ( filemtime( $dir.$f ) < $timeout ) unlink( $dir.$f );
		}
	}
	@closedir ( $d );

}

function sms ( $from, $to, $text ) {
	$result = @file_get_contents( 'http://bytehand.com:3800/send?id='.SMS_ID.'&key='.SMS_KEY.'&to='.urlencode($to).'&from='.urlencode($from).'&text='.urlencode($text) );
    return ( $result === false ) ? false : true;
}

// end. =)