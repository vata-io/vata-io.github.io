<?php

/*******************************************************************************

 *
 * 	AlterVision Core Framework - CPA platform
 * 	Created by AlterVision - altervision.me
 *  Copyright © 2005-2015 Anton Reznichenko
 *

 *
 *  File: 			index.php
 *  Description:	CPA order info
 *  Author:			Anton 'AlterVision' Reznichenko - altervision13@gmail.com
 *

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 2 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.

*******************************************************************************/

// Loading Site Core
//error_reporting (E_ALL & ~E_NOTICE); // Hard debug
error_reporting (0); // Production
define ( 'IN_ALTERCMS_CORE_ONE', true );
define ( 'ABSPATH', dirname(__FILE__).'/' );
define ( 'PATH', dirname(__FILE__).'/' );
include PATH . 'core/core.php';
header ( 'Content-Type: text/html; charset=utf-8' );

// Preparing Main Variables
$module = ( $core->get['m'] ) ? $core->get['m'] : null;
$action = ( $core->get['a'] ) ? $core->get['a'] : null;
$id		= ( $core->post['id'] ) ? preg_replace( '#([^0-9]+)#i', '', $core->post['id'] ) : ( ($core->get['id']) ? preg_replace( '#([^0-9]+)#i', '', $core->get['id'] ) : 0 );
$page	= ( $core->get['page'] > 0 ) ? (int) $core->get['page'] : 1;
$message = ( $core->get['message'] ) ? $core->get['message'] : null;

//
// Actions
//

switch ( $action ) {

  case 'find':
	if ( $id ) {		$core->go($core->url( 'm', $id ));
	} else $core->go($core->url( 'm', 'no' ));

  case 'exit':
  	if ( $id ) $core->session_set( 'c'.$id, '' );
	$core->go($core->url( 'm', '' ));

  case 'pass':
  	if ( $id ) {		$pass = rand( 100000, 999999 );
		$core->db->query( "REPLACE INTO ".DB_PROMO." ( `id`, `pass` ) VALUES ( '$id', '$pass' )" );
		sms( SMS_SIGN, depromo( $id ), sprintf( $core->lang['sms_pass'], $pass, $id ) );
		$core->go($core->url( 'mm', $id, 'pass' ));
	} else $core->go($core->url( 'm', 'no' ));

}

//
// Modules
//

switch ( $module ) {
  case 'info':

	if ( ! $id ) $core->go($core->url( 'm', 'no' ));

	if (defined( 'PROMOAUTH' )) {
		if ( $core->post['password'] ) {			$in = (int) $core->post['password'];
			$core->session_set( 'c'.$id, $in );
		} else $in = $core->session_get( 'c'.$id );

		$pp = $core->db->field( "SELECT `pass` FROM ".DB_PROMO." WHERE `id` = '$id' LIMIT 1" );
		if ( !$in || $pp != $in ) {
			$core->header();

			$core->tpl->load( 'body', 'pass' );
			$core->tpl->vars( 'body', array( 'promo' => $id ));
			if ( $core->get['message'] == 'pass' ) $core->tpl->block( 'body', 'pass' );
			$core->tpl->output( 'body' );

			$core->footer();
			$core->_die();

		}

	}

	$orders = $core->db->data( "SELECT offer_id, order_time, order_webstat, promo_status FROM ".DB_ORDER." WHERE promo_code = '$id' ORDER BY order_id DESC" );
	if ( $orders ) {
		$oids = array();
		foreach ( $orders as $o ) $oids[] = $o['offer_id'];
		$oids = array_unique( $oids );
		sort( $oids );
		$oids = implode( ',', $oids );
		$offer = $core->db->icol( "SELECT offer_id, offer_descr FROM ".DB_OFFER." WHERE offer_id IN ( $oids )" );
	} else $offer = array();

	$core->header();

	$core->tpl->load( 'body', 'order' );

	$core->tpl->vars( 'body', array(
		'promo'		=> $id,
	));

	if ( $orders ) {
		foreach ( $orders as $o ) {			if ( $o['order_webstat'] == 5 || $o['order_webstat'] == 12 ) $o['promo_status'] = 2;			$core->tpl->block( 'body', 'order', array(
				'offer'		=> $offer[$o['offer_id']],
				'time'		=> smartdate( $o['order_time'] ),
				'status'	=> $core->lang['statuso'][$o['order_webstat']],
				'promo'		=> $core->lang['promo'][$o['promo_status']],
			));
		}
	} else $core->tpl->block( 'body', 'no' );


	$core->tpl->output( 'body' );

	$core->footer();
  	break;

  case 'code':

	$core->header();

	$core->tpl->load( 'body', 'promo' );

	if ( $core->post['phone'] ) {		$phone = preg_replace( '#([^0-9]+)#i', '', $core->post['phone'] );
		$code = enpromo( $phone );
		if ( $code ) $core->tpl->block( 'body', 'promo', array( 'code' => $code ) );
	}

	$core->tpl->output( 'body' );

	$core->footer();
	break;

  case 'no':

	$core->header();

	$core->tpl->load( 'body', 'index' );

	$core->tpl->vars( 'body', array(
		'title'		=> $core->lang['notfound_h'],
		'text1'		=> $core->lang['notfound_t'],
		'text2'		=> $core->lang['search_t2'],
		'number'	=> $core->lang['search_n'],
		'find'		=> $core->lang['find'],
		'u_find'	=> $core->url( 'a', 'find', '' ),
	));

	$core->tpl->output( 'body' );

	$core->footer();

	break;

  default:

	$core->header();

	$core->tpl->load( 'body', 'index' );

	$core->tpl->vars( 'body', array(

		'title'		=> $core->lang['search_h'],
		'text1'		=> $core->lang['search_t1'],
		'text2'		=> $core->lang['search_t2'],
		'number'	=> $core->lang['search_n'],
		'find'		=> $core->lang['find'],
		'u_find'	=> $core->url( 'a', 'find', '' ),

	));

	$core->tpl->output( 'body' );

	$core->footer();

}

// end. =)