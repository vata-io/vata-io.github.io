<?php

/*******************************************************************************

 *
 * 	AlterVision Core Framework - CPA platform
 * 	Created by AlterVision - altervision.me
 *  Copyright © 2014-2017 Anton Reznichenko
 *

 *
 *  File: 			landing zone / cms.php
 *  Description:	Landing site simple CMS
 *  Author:			Anton 'AlterVision' Reznichenko - altervision13@gmail.com
 *

*******************************************************************************/

// Loading configuration
define( 'PATH', dirname(__FILE__) . '/' );
require_once PATH . 'config.php';

// Generic CURL request
function curl( $url ) {
	$curl = curl_init( $url );
	curl_setopt( $curl, CURLOPT_RETURNTRANSFER, 1 );
	curl_setopt( $curl, CURLOPT_FOLLOWLOCATION, 1 );
	curl_setopt( $curl, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:45.0) Gecko/20100101 Firefox/45.0' );
	$result = curl_exec( $curl );
	curl_close( $curl );
	return $result;
}

// Add 5-second period
if (isset( $_GET['good'] )) {
	$gid = (int) $_GET['good'];
	if ( $gid ) curl( BASEURL . CC . '?g=' . $gid );
	die();
}

// Let's start!
header( 'Content-type: text/html; charset=UTF-8' );
$now = time();

// Showing the message
if ( $_SERVER['QUERY_STRING'] == 'done' ) {
?><html>
<head>
	<title>Ваш заказ принят!</title>
	<meta charset="utf-8" />
	<style type="text/css">
		body, h1, h2, p, div { font: normal 12px OpenSans, Segoe UI, Tahoma, sans-serif; }
		body { padding: 40px 10px; text-align: center;  }
		h1 { font-size: 34px; padding: 0; margin: 0 0 20px 0; color: #292; }
		h2 { font-size: 20px; padding: 0; margin: 0 0 20px 0; color: #111; }
		p { font-size: 11px; padding: 0; margin: 0; color: #777; }
		div { font-size: 16px; padding: 2px; margin: 0; color: #822; }
	</style>
</head>
<body>
	<h1>Ваш заказ принят! Спасибо!</h1>
	<h2>Менеджер перезвонит Вам для уточнения деталей в течение часа</h2>
</body>
</html><?php
	die();
} elseif ( $_SERVER['QUERY_STRING'] == 'privacypolicy' ) {?><!DOCTYPE html>
<html lang="ru">
<head>
	<meta charset="utf-8">
	<title>Политика конфиденциальности</title>
	<style>
		body, html{
			min-height: 100%;
			margin:0px;
			padding: 0px;
			background: #eee;
		}
		body{
			padding-top: 40px;
		}
		.block_more_info{
			width: 800px;
			margin: 0px auto 20px;
			background: #fff;
			font-family: Arial;
			padding: 20px 40px 40px 40px;
			border: 1px solid #DADADA;
			line-height: 20px;
		}
		.block_more_info h1{
			color: #3B6A7C;
			margin-bottom: 30px;
			text-align: center;
		}
		.s1{
			font-style: italic;
			text-align: center;
			margin: 40px 0 0 0;
			font-weight: bold;
		}
		h2{
			font-size: 16px;
			margin-top: 26px;
		}
	</style>
</head>
<body>
	<div class="block_more_info">
		<h1>Политика конфиденциальности</h1>

		<h2>Защита личных данных</h2>
		<p>Для защиты ваших личных данных у нас внедрен ряд средств защиты, которые действуют при введении, передаче или работе с вашими личными данными.</p>

		<h2>Разглашение личных сведений и передача этих сведений третьим лицам</h2>
		<p>Ваши личные сведения могут быть разглашены нами  только в том случае это необходимо для: (а) обеспечения соответствия предписаниям закона или требованиям судебного процесса в нашем отношении ; (б) защиты наших прав или собственности (в) принятия срочных мер по обеспечению личной безопасности наших сотрудников или потребителей предоставляемых им услуг, а также обеспечению общественной безопасности. Личные сведения, полученные в наше распоряжение при регистрации, могут передаваться третьим организациям и лицам, состоящим с нами в партнерских отношениях для улучшения качества оказываемых услуг.  Эти сведения не будут использоваться в каких-либо иных целях, кроме перечисленных выше.   Адрес электронной почты, предоставленный вами при регистрации может использоваться для отправки вам сообщений или уведомлений об изменениях, связанных с вашей заявкой, а также  рассылки сообщений о происходящих в компании событиях и изменениях, важной информации о новых товарах и услугах и т.д.  Предусмотрена возможность отказа от подписки на эти почтовые сообщения.</p>

		<h2>Использование файлов «cookie»</h2>
		<p>Когда пользователь посещает веб-узел, на его компьютер записывается файл «cookie» (если пользователь разрешает прием таких файлов). Если же пользователь уже посещал данный веб-узел, файл «cookie» считывается с компьютера. Одно из направлений использования файлов «cookie» связано с тем, что с их помощью облегчается сбор статистики посещения. Эти сведения помогают определять, какая информация, отправляемая заказчикам, может представлять для них наибольший интерес. Сбор этих данных осуществляется в обобщенном виде и никогда не соотносится с личными сведениями пользователей.</p>
		<p>Третьи стороны, включая компании Google, показывают объявления нашей компании на страницах сайтов в Интернете. Третьи стороны, включая компанию  Google, используют cookie, чтобы показывать объявления, основанные на предыдущих посещениях пользователем наших вебсайтов и интересах в веб-браузерах. Пользователи могут запретить компаниям Google использовать cookie. Для этого необходимо посетить специальную страницу компании Google по этому адресу: http://www.google.com/privacy/ads/</p>

		<h2>Изменения в заявлении о соблюдении конфиденциальности</h2>
		<p>Заявление о соблюдении конфиденциальности предполагается периодически обновлять. При этом будет изменяться дата предыдущего обновления, указанная в начале документа. Сообщения об изменениях в данном заявлении будут размещаться на видном месте наших веб-узлов</p>
		<p class="s1">Благодарим Вас за проявленный интерес к нашей системе! </p>
	</div>
</body>
</html><?php
	die();
}

// Getting new flow ID
if ( $_GET['flow'] && $f = (int) $_GET['flow'] ) {
	$newflow = $f;
} elseif ( preg_match( "#^([0-9]+)#i", $_SERVER['QUERY_STRING'], $mf ) ) {
	$newflow = (int) $mf[0];
} else $newflow = false;

// Processing current flow ID
if ( $newflow ) {
	$flow = $newflow;
	setcookie( 'flow', $newflow, $now + 2592000, '/' );
} else $flow = (int) $_COOKIE['flow'];
$unique = ( $newflow && $newflow != $_COOKIE['flow'] ) ? true : false;

// Getting promo code
if ( $_GET['promo'] ) {
	$promo = preg_replace( '#[^0-9]+#i', '', $_GET['promo'] );
	setcookie( 'promo', $promo, $now + 2592000, '/' );
} elseif ( $_COOKIE['promo'] ) {
	$promo = preg_replace( '#[^0-9]+#i', '', $_COOKIE['promo'] );
} else $promo = false;

// Processing external ID from function
if (function_exists( 'ext' )) {
	$ee = ext();
	$exti = $ee['i'] ? $ee['i'] : 0;
	$extu = $ee['u'] ? $ee['u'] : 0;
	$exts = $ee['s'] ? $ee['s'] : 0;
} else $exti = $extu = $exts = 0;

// Processing external ID by direct
if ( $newexti = (int) $_GET['exti'] ) {
	$exti = $newexti;
	$extu = preg_replace( '#[^0-9A-Za-z\_\-]+#i', '', $_GET['extu'] );
	$exts = preg_replace( '#[^0-9]+#i', '', $_GET['exts'] );
}

// Set up EXT cookie
if ( $exti ) {
	if ( $_COOKIE['extd'] ) {
		$extd = explode( ':', $_COOKIE['extd'] );
		$unique = ( $extd[0] == $exti ) ? false : true;
	} else $unique = true;
	setcookie( 'extd', "$exti:$extu:$exts", $now + 86400, '/' );
} else list( $exti, $extu, $exts ) = $_COOKIE['extd'] ? explode( ':', $_COOKIE['extd'] ) : array( 0, 0, 0 );

// Processing Space Source
if ( $_GET['sp'] && $from = (int) $_GET['sp'] ) {
	setcookie( 'fromspace', $from, $now + 300, '/' );
} else $from = $_COOKIE['fromspace'] ? (int) $_COOKIE['fromspace'] : false;

// Metrika
if ( $_GET['mtrk'] && $mtrk = (int) $_GET['mtrk'] ) {
	setcookie( 'mtrk', $mtrk, $now + 300, '/' );
} else $mtrk = $_COOKIE['mtrk'] ? (int) $_COOKIE['mtrk'] : false;

//
// Generic UTM analysis
//

// Get new UTM
$hasutm = false;
if ( isset( $_GET['utm_source'] ) && $_GET['utm_source'] ) $hasutm = $us = mb_substr(filter_var( $_GET['utm_source'], FILTER_SANITIZE_STRING ), 0, 50 );
if ( isset( $_GET['utm_campaign'] ) && $_GET['utm_campaign'] ) $hasutm = $uc = mb_substr(filter_var( $_GET['utm_campaign'], FILTER_SANITIZE_STRING ), 0, 50 );
if ( isset( $_GET['utm_content'] ) && $_GET['utm_content'] ) $hasutm = $un = mb_substr(filter_var( $_GET['utm_content'], FILTER_SANITIZE_STRING ), 0, 50 );
if ( isset( $_GET['utm_term'] ) && $_GET['utm_term'] ) $hasutm = $ut = mb_substr(filter_var( $_GET['utm_term'], FILTER_SANITIZE_STRING ), 0, 50 );
if ( isset( $_GET['utm_medium'] ) && $_GET['utm_medium'] ) $hasutm = $um = mb_substr(filter_var( $_GET['utm_medium'], FILTER_SANITIZE_STRING ), 0, 50 );

// Reset UTM or get the old ones
$ass = '(!)'; // hope nobody uses it in UTM ...
if ( $hasutm === false ) {
	if ( $_COOKIE['utm'] ) list( $us, $uc, $un, $ut, $um ) = explode( $ass, $_COOKIE['utm'] );
} else setcookie( 'utm', $us.$ass.$uc.$ass.$un.$ass.$ut.$ass.$um, time() + 86400, '/' );

// New Flow vs. ExtID
if ( $newflow && $exti ) {
	unset( $exti, $extd, $extu );
	setcookie( 'extd', '', $now - 2592000, '/' );
} elseif ( $exti && $flow ) {
	unset( $flow );
	setcookie( 'flow', '', $now - 2592000, '/' );
}

// Checking for the post requests
$error = $request = false;
if ( $_POST['task'] == 'process' ) {

	// Check mobile
	$mobile = preg_match( '/mobile|ip(hone|od|ad)|android|blackberry|iemobile|kindle|netfront|(hpw|web)os|fennec|minimo|opera m(obi|ini)|blazer|dolfin|dolphin|skyfire|zune|tablet|silk|playbook/i', $_SERVER['HTTP_USER_AGENT'] ) ? 1 : 0;

	// Creating post request array
	$request = array(
		'offer'		=> OFFER,
		'site'		=> SITE,
		'flow'		=> (int) $_POST['flow'],
		'from'		=> (int) $_POST['from'],
		'us'		=> ( $q = mb_substr(filter_var( $_POST['us'], FILTER_SANITIZE_STRING ), 0, 50 ) ) ? $q : '',
		'uc'		=> ( $q = mb_substr(filter_var( $_POST['uc'], FILTER_SANITIZE_STRING ), 0, 50 ) ) ? $q : '',
		'un'		=> ( $q = mb_substr(filter_var( $_POST['un'], FILTER_SANITIZE_STRING ), 0, 50 ) ) ? $q : '',
		'ut'		=> ( $q = mb_substr(filter_var( $_POST['ut'], FILTER_SANITIZE_STRING ), 0, 50 ) ) ? $q : '',
		'um'		=> ( $q = mb_substr(filter_var( $_POST['um'], FILTER_SANITIZE_STRING ), 0, 50 ) ) ? $q : '',
		'exti'		=> (int) $_POST['exti'],
		'extu'		=> preg_replace( '#[^0-9A-Za-z\-\_\.]+#i', '', $_POST['extu'] ),
		'exts'		=> preg_replace( '#[^0-9]+#i', '', $_POST['exts'] ),
		'ip'		=> ip(),
		'name'		=> $_POST['name'],
		'addr'		=> $_POST['address'] ? $_POST['address'] : ( defined('ADDR') ? ADDR : '' ),
		'phone'		=> $_POST['phone'],
		'comm'		=> $_POST['comment'] ? $_POST['comment'] : '',
		'country'	=> $_POST['country'] ? strtolower(substr( $_POST['country'], 0, 2 )) : '',
		'currency'	=> (int) $_POST['curr'],
		'count'		=> defined( 'COUNT' ) ? COUNT : 1,
		'discount'	=> defined( 'DSCNT' ) ? DSCNT : 0,
		'more'		=> defined( 'MORE' ) ? MORE : 0,
		'promo'		=> $_POST['promo'] ? $_POST['promo'] : 0,
		'mobile'	=> $mobile ? 1 : 0,
		'bad'		=> $bad ? 1 : 0,
	);
//	$skey = hash_hmac( 'sha1', http_build_query( $request ), SKEY );
	$skey = SKEY;

	// Posting to the base site
	$curl = curl_init( BASEURL . 'neworder?key=' . $skey );
	curl_setopt( $curl, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:45.0) Gecko/20100101 Firefox/45.0' );
	curl_setopt( $curl, CURLOPT_RETURNTRANSFER, 1 );
	curl_setopt( $curl, CURLOPT_POST, 1 );
	curl_setopt( $curl, CURLOPT_POSTFIELDS, $request );
	$result = curl_exec( $curl );
	curl_close( $curl );

	// Checkign for errors or success
	$r = explode ( ':', $result, 2 );
	if ( $r[0] == 'e' ) {
		switch ( $r[1] ) {
         	case 'data':	$error = 'Ошибка заполнения формы!'; break;
         	case 'key':		$error = 'Ошибка сервера: поставщик неизвестен ...'; break;
         	case 'site':	$error = 'Ошибка сервера: сайт неизвестен ...'; break;
         	case 'offer':	$error = 'Ошибка сервера: товар неизвестен ...'; break;
         	case 'db':		$error = 'Внутренняя ошибка сервера ...'; break;
         	case 'ban':		$error = 'Вы занесены в чёрный список!';	break;
         	case 'security':$error = 'Заказ отклонён службой безопасности системы!';	break;
         	default:		$error = 'Произошла неизвестная ошибка сервера ...';
		}
	} else {
		if ( $r[0] != 'ok' ) file_put_contents( PATH.'query.txt', serialize(array( $skey, $request )) . "\r\n", FILE_APPEND | LOCK_EX  );
//		header( 'Location: '.SHOPURL.'?done' );
		header( 'Location: ?done' );
		die();
	}

} elseif ( $flow || $exti ) {	$req = 'o='.OFFER.'&s=' . SITE . '&ip=' . sprintf( "%u", ip2long( ip() ) );
	if ( $from ) $req .= '&b=' . $from;
	if ( $flow ) $req .= '&f=' . $flow;
	if ( $exti ) $req .= '&ei=' . $exti;
	if ( $exts ) $req .= '&es=' . $exts;
	if ( $unique ) $req .= '&u=1';
	if ( $us ) $req .= '&us='.rawurlencode($us);
	if ( $uc ) $req .= '&uc='.rawurlencode($uc);
	if ( $un ) $req .= '&un='.rawurlencode($un);
	if ( $ut ) $req .= '&ut='.rawurlencode($ut);
	if ( $um ) $req .= '&um='.rawurlencode($um);
	$res = curl( BASEURL . CC . '?' . $req );
	$res = explode( ':', $res, 2 );
	if (!( $res[0] == 'ok' || $res[0] == 'e' )) file_put_contents( PATH.'click.txt', $req . "&tm=$now\r\n", FILE_APPEND | LOCK_EX  );
	$vid = $res[1];
}

$params = '<input type="hidden" name="task" value="process" />'."\n";
if ( $flow ) $params .= '<input type="hidden" name="flow" value="'.$flow.'" />'."\n";
if ( $from ) $params .= '<input type="hidden" name="from" value="'.$from.'" />'."\n";
if ( $exti ) $params .= '<input type="hidden" name="exti" value="'.$exti.'" />'."\n";
if ( $extu ) $params .= '<input type="hidden" name="extu" value="'.$extu.'" />'."\n";
if ( $exts ) $params .= '<input type="hidden" name="exts" value="'.$exts.'" />'."\n";
if ( $promo ) $params .= '<input type="hidden" name="promo" value="'.$promo.'" />'."\n";
if ( $us ) $params .= '<input type="hidden" name="us" value="'.$us.'" />'."\n";
if ( $uc ) $params .= '<input type="hidden" name="uc" value="'.$uc.'" />'."\n";
if ( $un ) $params .= '<input type="hidden" name="un" value="'.$un.'" />'."\n";
if ( $ut ) $params .= '<input type="hidden" name="ut" value="'.$ut.'" />'."\n";
if ( $um ) $params .= '<input type="hidden" name="um" value="'.$um.'" />'."\n";

function checkpromo() {
	$promo = (string) $_POST['promo'];
	return ( strlen( $promo ) == 10 && $promo{0} == '2' ) ? true : false;
}

// Remote IP address
function ip() {	static $ip;
	if (isset( $ip )) return $ip;
	if ( $_SERVER['HTTP_X_FORWARDED_FOR'] ) {
		if (strpos( $_SERVER['HTTP_X_FORWARDED_FOR'], ',' ) !== false ) {			$xffd = explode( ',', $_SERVER['HTTP_X_FORWARDED_FOR'] );
			foreach ( $xffd as $xff ) {
				$xff = trim( $xff );
				$ip = filter_var( $xff, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 | FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE );
				if ( $ip ) break;
			}
		} else $ip = filter_var( $_SERVER['HTTP_X_FORWARDED_FOR'], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 | FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE );
	}
	if ( ! $ip ) $ip = filter_var( $_SERVER['HTTP_CLIENT_IP'], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 | FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE );
	if ( ! $ip ) $ip = $_SERVER['REMOTE_ADDR'];
	return $ip;
}

// User GEO data
function geo() {	static $geo;
	if (isset( $geo )) return $geo;
	$ip = ip2long( ip() );
	$geo = false;
	if ( $ip > 33554430 && $ip < 3656662434 ) {
		$ip = $ip - 33554432;
		$ip = $ip >> 7;
		$ipf = fopen( PATH . 'geocode.txt', 'r' );
		fseek( $ipf, $ip );
		$geo = fread( $ipf, 2 );
		fclose( $ipf );
		if ( $geo == '--' ) $geo = false;
	} return $geo;
}

// Page footer
function footer() {

	global $error, $vid, $mtrk;
	if ( $error ) echo '<script type="text/javascript">alert("Невозможно выполнить заказ.\\n'.$error.'");</script>';

	if ( $vid ) : ?><script type="text/javascript">
function noregret(){var xx = new XMLHttpRequest();xx.open("GET","?good=<?=$vid;?>&z="+Math.random(),true);xx.send(null);setTimeout("noregret()",5000);}function trytosee(){isd&&(setTimeout("noregret()",5000),isd=!1)}var isd=!0;window.onload=function(){document.hidden||document.msHidden||document.webkitHidden||document.mozHidden?window.onfocus=function(){trytosee(),window.onfocus=null}:trytosee()};
</script><? endif;

	if (defined( 'METRIKA' )) : ?><!-- Yandex.Metrika counter --> <script type="text/javascript"> (function (d, w, c) { (w[c] = w[c] || []).push(function() { try { w.yaCounter<?=METRIKA;?> = new Ya.Metrika({ id:<?=METRIKA;?>, clickmap:true, trackLinks:true, accurateTrackBounce:true, webvisor:true }); } catch(e) { } }); var n = d.getElementsByTagName("script")[0], s = d.createElement("script"), f = function () { n.parentNode.insertBefore(s, n); }; s.type = "text/javascript"; s.async = true; s.src = "https://mc.yandex.ru/metrika/watch.js"; if (w.opera == "[object Opera]") { d.addEventListener("DOMContentLoaded", f, false); } else { f(); } })(document, window, "yandex_metrika_callbacks"); </script> <noscript><div><img src="https://mc.yandex.ru/watch/<?=METRIKA;?>" style="position:absolute; left:-9999px;" alt="" /></div></noscript> <!-- /Yandex.Metrika counter --><? endif;

	if ( $mtrk ) : ?><!-- Yandex.Metrika counter --> <script type="text/javascript"> (function (d, w, c) { (w[c] = w[c] || []).push(function() { try { w.yaCounter<?=$mtrk;?> = new Ya.Metrika({ id:<?=$mtrk;?>, clickmap:true, trackLinks:true, accurateTrackBounce:true, webvisor:true }); } catch(e) { } }); var n = d.getElementsByTagName("script")[0], s = d.createElement("script"), f = function () { n.parentNode.insertBefore(s, n); }; s.type = "text/javascript"; s.async = true; s.src = "https://mc.yandex.ru/metrika/watch.js"; if (w.opera == "[object Opera]") { d.addEventListener("DOMContentLoaded", f, false); } else { f(); } })(document, window, "yandex_metrika_callbacks"); </script> <noscript><div><img src="https://mc.yandex.ru/watch/<?=$mtrk;?>" style="position:absolute; left:-9999px;" alt="" /></div></noscript> <!-- /Yandex.Metrika counter --><? endif;

}
