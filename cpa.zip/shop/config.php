<?php

/*******************************************************************************

 *
 * 	AlterVision Core Framework - CPA platform
 * 	Created by AlterVision - altervision.me
 *  Copyright � 2005-2017 Anton Reznichenko
 *

 *
 *  File: 			landing zone / config.php
 *  Description:	Landing Zone Configuration
 *  Author:			Anton 'AlterVision' Reznichenko - altervision13@gmail.com
 *

*******************************************************************************/

// The base URL where "click.php" and "neworder" can be found
// Something like: http://work.cpa/
define ( 'BASEURL', 'http://work.cpa/' );

// The shop URL where the landings are
// Something like: http://shop.cpa/
//define ( 'SHOPURL', '' ); // Keep on the landing page
define ( 'SHOPURL', 'http://shop.cpa/' ); // Redirect to one index page

// Name of counting script
// Default: cc.php
define ( 'CC', 'cc.php' );

// Yandex Metrika ID
//define ( 'METRIKA', '' );

// External processing
// Must return array( 'i' => exti, 'u' => extu, 's' => exts )
/*function ext () {

	if ( $_GET['pumo'] && is_numeric( $_GET['pumo'] ) ) {
		return array( 'i' => 13, 'u' => preg_replace( '#[^0-9]+#i', '', $_GET['pumo'] ), 's' => 0 );
	} else return array();

}*/

// That's all, folks