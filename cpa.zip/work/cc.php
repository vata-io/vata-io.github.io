<?php

/*******************************************************************************

 *
 * 	AlterVision Core Framework - CPA platform
 * 	Created by AlterVision - altervision.me
 *  Copyright © 2005-2016 Anton Reznichenko
 *

 *
 *  File: 			click.php
 *  Description:	Clicks processing utility
 *  Author:			Anton 'AlterVision' Reznichenko - altervision13@gmail.com
 *

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 2 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.

*******************************************************************************/

// Loading Site Core
error_reporting ( 0 );
define ( 'IN_ALTERCMS_CORE_ONE', true );
define ( 'PATH', dirname(__FILE__).'/' );
include PATH . 'config.php';
setlocale( LC_ALL , 'ru_RU.UTF-8' );
mb_language( 'uni' );
mb_internal_encoding( 'utf-8' );

// Setting click good
if ( isset( $_GET['g'] ) && $g = (int) $_GET['g'] ) {
	$db = mysqli_connect( SQL_HOST, SQL_USER, SQL_PASS, SQL_BASE );
	if ( $db ) {
		mysqli_query ( $db, "UPDATE LOW_PRIORITY `".SQL_PREF."click` SET `click_good` = `click_good` + 1 WHERE `click_id` = '$g' AND `click_good` < 179 LIMIT 1" );
		mysqli_close ( $db );
	}
	die();
}

// Get click data
$flow	= isset( $_GET['f'] ) ? (int) $_GET['f'] : 0;
$site	= isset( $_GET['s'] ) ? (int) $_GET['s'] : 0;
$sib	= isset( $_GET['b'] ) ? (int) $_GET['b'] : 0;
$offer	= isset( $_GET['o'] ) ? (int) $_GET['o'] : 0;
$exti	= isset( $_GET['ei'] ) ? (int) $_GET['ei'] : 0;
$exts	= isset( $_GET['es'] ) ? (int) $_GET['es'] : 0;
$ip		= isset( $_GET['ip'] ) ? (int) $_GET['ip'] : 0;
$unique	= ( isset( $_GET['u'] ) && $_GET['u'] ) ? 1 : 0;
$space	= ( isset( $_GET['p'] ) && $_GET['p'] ) ? 1 : 0;
$date	= ( isset( $_GET['tm'] ) && is_numeric( $_GET['tm'] ) ) ? date( 'Ymd', $_GET['tm'] ) : date( 'Ymd' );
$us		= isset( $_GET['us'] ) ? addslashes(mb_substr(filter_var( stripslashes($_GET['us']), FILTER_SANITIZE_STRING ), 0, 50)) : '';
$uc		= isset( $_GET['uc'] ) ? addslashes(mb_substr(filter_var( stripslashes($_GET['uc']), FILTER_SANITIZE_STRING ), 0, 50)) : '';
$un		= isset( $_GET['un'] ) ? addslashes(mb_substr(filter_var( stripslashes($_GET['un']), FILTER_SANITIZE_STRING ), 0, 50)) : '';
$ut		= isset( $_GET['ut'] ) ? addslashes(mb_substr(filter_var( stripslashes($_GET['ut']), FILTER_SANITIZE_STRING ), 0, 50)) : '';
$um		= isset( $_GET['um'] ) ? addslashes(mb_substr(filter_var( stripslashes($_GET['um']), FILTER_SANITIZE_STRING ), 0, 50)) : '';

// Add clicks the simplest way
if ( ( $flow || $exti ) && $site ) {

	// Connect to DB
	$db = mysqli_connect( SQL_HOST, SQL_USER, SQL_PASS, SQL_BASE );
	if ( !$db ) die( 'e' );
	mysqli_set_charset( $db, 'utf8' );

	// Processing GEO
	if ( $ip ) {		$o = mysqli_query( $db, "SELECT `country` FROM `".SQL_PREF."geoip` WHERE `ip` < '$ip' ORDER BY `ip` DESC LIMIT 1" );
		if ( $o ) {
			$g = mysqli_fetch_row( $o );
			$geo = $g[0];
		} else $geo = 'zz';
	} else $geo = 'zz';

	// Adding new click
	mysqli_query ( $db, "INSERT INTO `".SQL_PREF."click` SET
		`offer_id`		= '$offer',
		`site_id`		= '$site',
		`site_sib`		= '$sib',
		`flow_id`		= '$flow',
		`ext_id`		= '$exti',
		`ext_src`		= '$exts',
		`click_ip`		= '$ip',
		`click_geo`		= '$geo',
		`click_date`	= '$date',
		`click_unique`	= '$unique',
		`click_space`	= '$space',
		`utms`			= '$us',
		`utmc`			= '$uc',
		`utmn`			= '$un',
		`utmt`			= '$ut',
		`utmm`			= '$um'
	" );
	$uid = mysqli_insert_id( $db );

	// Finishing
	mysqli_close ( $db );
	echo 'ok:'.$uid;
	die();

} else die( 'e' );

// end. =)