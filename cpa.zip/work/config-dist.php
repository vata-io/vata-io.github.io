<?php

/*******************************************************************************

 *
 * 	AlterVision Core Framework - CPA platform
 * 	Created by AlterVision - altervision.me
 *  Copyright � 2014-2017 Anton Reznichenko
 *

 *
 *  File: 			config.php
 *  Description:	Database and system configuration
 *  Author:			Anton 'AlterVision' Reznichenko - altervision13@gmail.com
 *

*******************************************************************************/

if ( !defined('IN_ALTERCMS_CORE_ONE') ) die("Hacking attempt");

//
// Main settings
//

error_reporting ( 0 ); // Production
//error_reporting (E_ALL & ~E_NOTICE); // Debug
define ( 'HACK', 'hack-dist' ); // Hacks directory

//
// Database Configuration
//

define ( 'SQL_HOST', 'localhost' );			// Database server host
define ( 'SQL_BASE', 'altercpa' );			// Database name
define ( 'SQL_USER', 'root' );				// Database user
define ( 'SQL_PASS', '' );					// Database password
define ( 'SQL_PREF', 'cpa_' );				// Database prefix
define ( 'SQL_CHARSET', 'utf8' );			// Main charset
define ( 'SQL_COLLATE', 'utf8_general_ci');	// Collation charset

//
// Additional platform configs
//

// Memcache Caching Engine
//define ( 'MC_HOST',	'127.0.0.1' );	// Memcache host (default: 127.0.0.1)
//define ( 'MC_PORT',	'11211' );		// Memcache port (default: 11211)
//define ( 'MC_PREF',	'mycpa' );		// Memcache prefix

// Hostname configs
//define ( 'STRICT_HOST',	'work.cpa' );	// Use only this hostname
//define ( 'STRICT_HTTPS', 	true );			// Use only HTTPS connection

// end. =)