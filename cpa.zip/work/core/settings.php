<?php

/*******************************************************************************

 *
 * 	AlterVision Core Framework - CPA platform
 * 	Created by AlterVision - altervision.me
 *  Copyright © 2014-2017 Anton Reznichenko
 *

 *
 *  File: 			core / settings.php
 *  Description:	Site additional configs
 *  Author:			Anton 'AlterVision' Reznichenko - altervision13@gmail.com
 *

*******************************************************************************/

// Database Tables
define( 'DB_BAN_IP',	SQL_PREF . 'ban_ip' );
define( 'DB_BAN_PH',	SQL_PREF . 'ban_phone' );
define( 'DB_BL',		SQL_PREF . 'bl' );
define( 'DB_CALL',		SQL_PREF . 'call' );
define( 'DB_CASH',		SQL_PREF . 'cash' );
define( 'DB_CHANGE',	SQL_PREF . 'change' );
define( 'DB_CLICK',		SQL_PREF . 'click' );
define( 'DB_COMP',		SQL_PREF . 'comp' );
define( 'DB_DOMAIN',	SQL_PREF . 'domain' );
define( 'DB_EXT',		SQL_PREF . 'ext' );
define( 'DB_FLOW',		SQL_PREF . 'flow' );
define( 'DB_GEOIP',		SQL_PREF . 'geoip' );
define( 'DB_GEOCITY',	SQL_PREF . 'geocity' );
define( 'DB_NEWS',		SQL_PREF . 'news' );
define( 'DB_OFFER',		SQL_PREF . 'offer' );
define( 'DB_ORDER',		SQL_PREF . 'order' );
define( 'DB_PDB',		SQL_PREF . 'pdb' );
define( 'DB_PHONE',		SQL_PREF . 'pdb' );
define( 'DB_PRICE',		SQL_PREF . 'price' );
define( 'DB_SITE',		SQL_PREF . 'site' );
define( 'DB_STATS',		SQL_PREF . 'stats' );
define( 'DB_STORE',		SQL_PREF . 'store' );
define( 'DB_SUPP',		SQL_PREF . 'supp' );
define( 'DB_TEAM',		SQL_PREF . 'team' );
define( 'DB_USER',		SQL_PREF . 'user' );
define( 'DB_VARS',		SQL_PREF . 'vars' );

// Offers
define( 'OFFER_FILE',	PATH . 'data/offer/%d.jpg' );
define( 'OFFER_LOGO',	'/data/offer/%d.jpg' );

// News Images
define( 'DIR_NEWS',		PATH . 'data/news/' );
define( 'PATH_NEWS',	'/data/news/%s' );

// Dates
date_default_timezone_set( 'Etc/GMT-3' );

if (defined( 'HACK' )) require_once PATH . HACK . '/start.php';

// Fallback defines
if (!defined( 'SITENAME' ))		define ( 'SITENAME',	'MyCPA' );					// The site title
if (!defined( 'SITEMAIL' ))		define ( 'SITEMAIL',	'info@work.cpa' );			// The main e-mail
if (!defined( 'BASEURL' ))		define ( 'BASEURL',		'http://work.cpa/' );		// Site with control panel
if (!defined( 'USERURL' ))		define ( 'USERURL',		'http://my.cpa/' );			// Personal site
if (!defined( 'PROMOURL' ))		define ( 'PROMOURL',	'http://promo.cpa/' );		// Promo control panel
if (!defined( 'SPACEURL' ))		define ( 'SPACEURL',	'http://blog.cpa/' );		// Blogs site
if (!defined( 'LANDSURL' ))		define ( 'LANDSURL',	'http://shop.cpa/' );       // Landings main site
if (!defined( 'GOODCLICK' ))	define ( 'GOODCLICK', 2 );							// Time for the good click divided by 5

// end. =)