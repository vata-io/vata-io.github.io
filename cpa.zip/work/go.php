<?php

/*******************************************************************************

 *
 * 	AlterVision Core Framework - CPA platform
 * 	Created by AlterVision - altervision.me
 *  Copyright � 2014-2015 Anton Reznichenko
 *

 *
 *  File: 			go.php
 *  Description:	Redirection block
 *  Author:			Anton 'AlterVision' Reznichenko - altervision13@gmail.com
 *

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 2 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.

*******************************************************************************/

// Checking the domain
if (isset( $_GET['checkdomain'] )) die( 'ok' );

// Getting the ID
$id = isset( $_GET['flid'] ) ? (int) $_GET['flid'] : false;
if ( ! $id ) die( 'oups' );

// Loading Site Core
error_reporting (0);
define ( 'IN_ALTERCMS_CORE_ONE', true );
define ( 'PATH', dirname(__FILE__).'/' );
include PATH . 'config.php';
include PATH . 'core/settings.php';
include PATH . 'core/api.php';
include PATH . 'core/cache.php';
include PATH . 'core/db.php';
include PATH . 'lib/wmsale.php';

// Create working objects
$db = new sql_db ( SQL_HOST, SQL_USER, SQL_PASS, SQL_BASE, SQL_CHARSET, SQL_COLLATE );
if ( defined( 'MC_HOST' ) ) {
	$cache = new CacheControl ( PATH . 'cache/%s.txt' );
} else $cache = new CacheControl ( PATH . 'cache/%s.txt', array( 'host' => MC_HOST, 'port' => MC_PORT, 'pref' => MC_PREF, 'exp' => 7200 ) );

// Make new WMsale instance
$core = new stdClass();
$core->db = $db;
$core->cache = $cache;
$wmsale = new WMsale ( $core );

// Get the flow data
$flow = $wmsale->get ( 'flow', $id );
if ( ! $flow['flow_id'] ) die( 'oups' );

// Make the URL based on the offer countries data
if ( $flow['flow_url'] ) {

	$offer = $wmsale->get( 'offer', $flow['offer_id'] );
	$cntr = $offer['offer_country'] ? $offer['offer_country'] : 'ru';
	$cntr = explode( ',', $cntr );

	$ipl = array();
	if ( goodip ( $_SERVER['REMOTE_ADDR'] ) && !privateip( $_SERVER['REMOTE_ADDR'] )) $ipl[] = $_SERVER['HTTP_X_REAL_IP'];
	if ( goodip ( $_SERVER['HTTP_X_REAL_IP'] ) && !privateip( $_SERVER['HTTP_X_REAL_IP'] )) $ipl[] = $_SERVER['HTTP_X_REAL_IP'];
	if ( goodip ( $_SERVER['HTTP_X_FORWARDED_FOR'] ) && !privateip( $_SERVER['HTTP_X_FORWARDED_FOR'] )) $ipl[] = $_SERVER['HTTP_X_FORWARDED_FOR'];
	if ( goodip ( $_SERVER['HTTP_CLIENT_IP'] ) && !privateip( $_SERVER['HTTP_CLIENT_IP'] )) $ipl[] = $_SERVER['HTTP_CLIENT_IP'];
	$ipl = array_unique( $ipl );

	$match = false;
	foreach ( $ipl as $ip ) {
		$ipi = sprintf( "%u", ip2long( $ip ) );
		$ipd = $db->field( "SELECT `country` FROM `".DB_GEOIP."` WHERE `ip` < '$ipi' ORDER BY `ip` DESC LIMIT 1" );
		if ( in_array( $ipd, $cntr ) ) $match = true;
	}

	$url = $match ? false : $flow['flow_url'];

} else $url = false;

// Make the URL based on the flow data
if ( ! $url ) {

	if ( $flow['flow_space'] ) {
		$url = $wmsale->get( 'site', $flow['flow_space'], 'site_url' );
		$fid = $id . '-' . $flow['flow_site'];
	} elseif ( $flow['flow_site'] ) {
		$url = $wmsale->get( 'site', $flow['flow_site'], 'site_url' );
		$fid = $id;
	} else die( 'oups' );

	$url = 'http://' . $url . '/?' . ( $flow['flow_param'] ? 'flow=' : '' ) . $fid . ( $flow['flow_cb'] ? '&cb' : '' );

}

// Get parameters
if ( count( $_GET ) > 1 ) {
	unset ( $_GET['flid'] );
	$getline = http_build_query( $_GET );
	$url .= ( strpos( $url, '?' ) ? '&' : '?' ) . http_build_query( $_GET );
}

// Redirect to specific location
header( 'Location: ' . $url );

// end. =)