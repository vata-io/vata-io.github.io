<? // This file will be included in api.php cofiguration

/* // External connection example
function api_ext_example ( $core, $o = false ) {

	$idsg = $core->post['ids'] ? explode( ',', $core->post['ids'] ) : ( $core->get['ids'] ? explode( ',', $core->get['ids'] ) : array() );
	$ids = array(); foreach ( $idsg as $i ) if ( $i = (int) $i ) $ids[] = $i;
	$idsl = implode( ',', $ids );
	$orders = $core->db->data( "SELECT order_webstat, ext_uid FROM ".DB_ORDER." WHERE ext_id = 1 AND ext_uid IN ( $idsl )" );

	$result = array();
	foreach ( $orders as $o ) {
		$result[ (int) $o['ext_uid'] ] = array(
			'id'			=> (int) $o['ext_uid'],
			'status'		=> (int) $o['order_webstat'],
			'status_text'	=> $core->lang['statuso'][$o['order_webstat']],
		);
	}

	return $result;

}
*/
