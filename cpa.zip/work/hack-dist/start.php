<?php

/*******************************************************************************

 *
 * 	AlterVision Core Framework - CPA platform
 * 	Created by AlterVision - altervision.me
 *  Copyright © 2014-2017 Anton Reznichenko
 *

 *
 *  File: 			hack-dist / start.php
 *  Description:	Default hacks list
 *  Author:			Anton 'AlterVision' Reznichenko - altervision13@gmail.com
 *

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 2 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.

*******************************************************************************/

//
//  CPA settings
//

// Basic
define ( 'SITENAME',	'MyCPA' );
define ( 'SITEMAIL',	'info@my.cpa' );

// URLs
define ( 'BASEURL',		'http://my.cpa/' );
define ( 'USERURL',		'http://my.my.cpa/' );
define ( 'SPACEURL',	'http://blog.my.cpa/' );
define ( 'LANDSURL',	'http://shop.my.cpa/' );
define ( 'REDURL',		'http://go.my.cpa/' );
define ( 'REDURLGO',	'to' );

// Settins
//define ( 'NOREGISTER', true );		// Disable registration
//define ( 'HACK_NOREF', true );		// Disable referal program

//
// Hacks
//

//define ( 'HACK_STATS', true );		// Add hack/stats.php to work
//define ( 'HACK_CRON', true );			// Add hack/cron.php to crontab
//define ( 'HACK_SEND', true );			// Add hack/send.php to order sending
//define ( 'HACK_ADD', true );			// Add hack/add.php to new order script
//define ( 'HACK_API', true );			// Add hack/api.php to API interface
//define ( 'HACK_REGISTER', true );		// Add hack/register.php to registration and login

//
// Styling
//

// CSS tricks
//define ( 'HACK_NOSTYLE', true );		// Disable usage of style/style.css
//define ( 'HACK_MYSTYLE', true );		// Add personal css/style.css
// TPL replacement from style/XXX.tpl to hack/tpl/XXX.tpl
//define ( 'HACK_TPL_404', true );			// 404.tpl
//define ( 'HACK_TPL_ANALYTICS', true );	// analytics.tpl
//define ( 'HACK_TPL_BAN', true );			// ban.tpl
//define ( 'HACK_TPL_BUSINESS', true );		// business.tpl
//define ( 'HACK_TPL_CALLSTAT', true );		// callstat.tpl
//define ( 'HACK_TPL_COMP', true );			// comps.tpl
//define ( 'HACK_TPL_DOMAIN', true );		// domain.tpl
//define ( 'HACK_TPL_DYNAMICS', true );		// dynamics.tpl
//define ( 'HACK_TPL_ENTER', true );		// login-clean.tpl
//define ( 'HACK_TPL_EXTERNAL', true );		// eternal.tpl
//define ( 'HACK_TPL_FINANCE', true );		// finance.tpl
//define ( 'HACK_TPL_FLOWS', true );		// flows.tpl
//define ( 'HACK_TPL_FLOWSTAT', true );		// flowstat.tpl
//define ( 'HACK_TPL_FOOTER', true );		// footer.tpl
//define ( 'HACK_TPL_FORM', true );			// form.tpl
//define ( 'HACK_TPL_HEADER', true );		// header.tpl
//define ( 'HACK_TPL_LEAD', true );			// lead.tpl
//define ( 'HACK_TPL_LEADS', true );		// leads.tpl
//define ( 'HACK_TPL_LIST', true );			// list.tpl
//define ( 'HACK_TPL_LOGIN', true );		// login.tpl
//define ( 'HACK_TPL_MESSAGE', true );		// message.tpl
//define ( 'HACK_TPL_NEWS', true );			// news.tpl
//define ( 'HACK_TPL_OFFER', true );		// offer.tpl
//define ( 'HACK_TPL_OFFERS', true );		// offers.tpl
//define ( 'HACK_TPL_OFLIST', true );		// offerlist.tpl
//define ( 'HACK_TPL_ORDER', true );		// order.tpl
//define ( 'HACK_TPL_ORDERS', true );		// orders.tpl and csv-orders.tpl
//define ( 'HACK_TPL_OUTS', true );			// outs.tpl
//define ( 'HACK_TPL_PARAM', true );		// param.tpl
//define ( 'HACK_TPL_PRICE', true );		// price.tpl
//define ( 'HACK_TPL_REFERAL', true );		// referal.tpl
//define ( 'HACK_TPL_REFERALS', true );		// referals.tpl
//define ( 'HACK_TPL_SLIST', true );		// safelist.tpl
//define ( 'HACK_TPL_STATS', true );		// stats.tpl
//define ( 'HACK_TPL_SUPP', true );			// support.tpl
//define ( 'HACK_TPL_TALK', true );			// talk.tpl
//define ( 'HACK_TPL_TARGET', true );		// target.tpl
//define ( 'HACK_TPL_TRANS', true );		// trans.tpl
//define ( 'HACK_TPL_USERS', true );		// users.tpl
//define ( 'HACK_TPL_UTM', true );			// utm.tpl

//
// Misc
//

// Payment
define( 'WMR',			'R12345667890' ); // WebMoney Ruble Purse
define( 'WMK',			'' ); // WebMoney Auth Key

// ByteHand
define ( 'SMS_ID',		'' );	// ByteHand API ID
define ( 'SMS_KEY',		'' );	// ByteHand API Key
define ( 'SMS_SIGN',	'' );	// ByteHand Sign name
define ( 'SMS_LOGIN',	'' );	// ByteHand Login
define ( 'SMS_PASS',	'' );	// ByteHand Password
define ( 'SMS_COOKIE',	PATH . 'data/work/bytehand.txt' );

// Post Tracker
define ( 'SPSR_COOKIE',	PATH . 'data/work/spsr-%s.txt' );
define ( 'SPSR_CACHE',	PATH . 'data/work/spsr-cache-%s.txt' );
define ( 'SPSR_CITY',	'Москва' );	// Default SPSR city
define ( 'SPSR_LOGIN',	'' );	// Default SPSR login
define ( 'SPSR_PASS',	'' );	// Default SPSR password
define ( 'SPSR_ID',		'' );	// Default SPSR ID
define ( 'RUP_API',		'' );	// RuPost API ID
define ( 'RUP_KEY',		'' );	// RuPost API Key
define ( 'RUP_WG',		'0.1' );	// RuPost weight in kilos
define ( 'RUP_FROM',	'101000' );	// RuPost API Index

// Address Parsing
//define ( 'ADDR_XML',	'http://ahunter.ru/site/check?user=username;output=xml;query=' );	// AHunter XML check url
//define ( 'ADDR_ALT',	'http://ahunter.ru/site/search?user=username;output=xml;query=' );	// AHunter XML search url
define ( 'ADDR_CACHE',	PATH . 'data/work/address-%s.txt' );

// Email settings
define( 'MAIL_FROM',	'noreply@work.cpa' );		// From address
//define( 'MAIL_DOMAIN',	'work.cpa' );				// SMTP domain
//define( 'MAIL_SERVER',	'ssl://smtp.yandex.ru' );	// SMTP server address
//define( 'MAIL_PORT',	'465' );					// SMTP server port
//define( 'MAIL_USER',	'noreply@work.cpa' );		// SMTP login
//define( 'MAIL_PASS',	'password' );				// SMTP password

// Support notification email
define( 'SUPPORT_NOTIFY',	'support@work.cpa' );

// Disqus short name
define( 'DISQUS', 'workcpa' );