<?
define( 'IN_ALTERCMS_CORE_ONE', true );
require_once '../config.php';
if (defined( 'HACK' )) {
	require_once '../'.HACK.'/start.php';
} else require_once '../core/settings.php';
?><!DOCTYPE html>
<html lang="ru">
<head>
	<title>FAQ &mdash; <?=SITENAME;?>: руководство пользователя</title>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<link type="text/css" href="css/bootstrap.css" rel="stylesheet" />
	<link type="text/css" href="css/style.css" rel="stylesheet" />
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/bootstrap.js"></script>
</head>
<body class="faq">

<div class="container">

    <header class="navbar navbar-default navbar-fixed-top"><div class="container">
		<div class="navbar-header">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
			<a class="navbar-brand mainlogo" href="index.php"><?=SITENAME;?>: помощь</a>
		</div>
		<div class="navbar-collapse collapse">
			<ul class="nav navbar-nav">
				<li><a href="index.php">Общая информация</a></li>
				<li><a href="faq.php">FAQ</a></li>
				<li><a href="api.php">API</a></li>
			</ul>
			<ul class="nav navbar-nav navbar-right">
				<li><a href="/">Вернуться на сайт</a></li>
			</ul>
		</div>
	</div></header>

	<a class="anchor" name="top"></a>
	<h1 class="page-header">FAQ: частые вопросы о сервисе <?=SITENAME;?></h1>

	<h3>Общие вопросы</h3>
	<ul>
		<li><a href="#referal">Есть ли в системе реферальная программа?</a></li>
		<li><a href="#api">Поддерживает ли Ваш сервис API-интерфейс?</a></li>
		<li><a href="#iwant">Мне хотелось бы видеть в Вашей системе функцию ...</a></li>
	</ul>

	<h3>Вопросы вебмастера</h3>
	<ul>
		<li><a href="#start">Как мне начать лить трафик?</a></li>
		<li><a href="#landing">Какие есть лендинги для <i>%offername%</i> и какой самый лучший?</a></li>
		<li><a href="#flowlink">Каким образом формируется ссылка потока?</a></li>
		<li><a href="#subid">Как мне использовать свои SubID?</a></li>
		<li><a href="#postback">Как настроить PostBack-запрос?</a></li>
		<li><a href="#calls">Как осуществляется обзвон?</a></li>
		<li><a href="#outpay">Как осуществляются выплаты?</a></li>
		<li><a href="#noout">Почему мне не выводят деньги?!</a></li>
		<li><a href="#check">Что значит подпись <code>Заказ на проверке</code> в статистике по лидам?</a></li>
		<li><a href="#getname">Я хочу узнать имя / телефон / адрес заказчика</a></li>
	</ul>

	<h3>Вопросы поставщика</h3>
	<ul>
		<li><a href="#newsale">Я хочу присоединиться к вам в роли поставщика!</a></li>
		<li><a href="#saleface">У меня уже есть интерфейс обработки заказов и он меня устраивает</a></li>
	</ul>

	<h2 class="qublock">Общие вопросы</h2>

	<div class="question">
		<a class="anchor" name="referal"></a>
		<h4>Есть ли в системе реферальная программа?</h4>
		<p>Да, она доступна в разделе «<a href="/referal">Рефералы</a>» интерфейса. Вы можете получать вознаграждение за привлечение новых вебмастеров в нашу партнёрскую программу. С каждого подтверждённого лида от привлечённых вебмастеров вам будет начисляться партнёрское вознаграждение. Сумма вознаграждения может варьироваться в зависимости от оффера. Точную сумму можно найти на странице «<a href="/offers">Офферы</a>» в пункте «Реферальные отчисления».</p>
		<p class="small"><a href="#top"><i class="glyphicon glyphicon-chevron-up"></i> Вернуться к списку вопросов</a></p>
	</div>

	<div class="question">
		<a class="anchor" name="api"></a>
		<h4>Поддерживает ли Ваш сервис API-интерфейс?</h4>
		<p>Да, большинство функций нашего сервиса реализованы в качестве API. Подробнее с ними можно ознакомиться в <a href="api.php">соответствующем руководстве</a>.</p>
		<p class="small"><a href="#top"><i class="glyphicon glyphicon-chevron-up"></i> Вернуться к списку вопросов</a></p>
	</div>

	<div class="question">
		<a class="anchor" name="iwant"></a>
		<h4>Мне хотелось бы видеть в Вашей системе функцию ...</h4>
		<p>Вам требуются нестандартные или новые функции в системе? Новые инструменты анализа? У Вас есть идеи? Пишите нам <a href="/support">в раздел технической поддержки</a> - мы реализуем Ваши идеи!</p>
		<p class="small"><a href="#top"><i class="glyphicon glyphicon-chevron-up"></i> Вернуться к списку вопросов</a></p>
	</div>

	<h2 class="qublock">Вопросы вебмастера</h2>

	<div class="question">
		<a class="anchor" name="start"></a>
		<h4>Как мне начать лить трафик?</h4>
		<p>Чтобы начать лить трафик, необходимо получить ссылку потока. Для этого требуется выполнить следующие действия:</p>
		<ul>
			<li>В разделе «<a href="/offers">Офферы</a>» подобрать требуемый оффер для работы.</li>
			<li>С помощью кнопки «Создать поток по офферу» добавить новый поток для данного оффера. Имя потока может быть выбрано произвольно.</li>
			<li>В разделе «<a href="/flow">Потоки</a>» нажать кнопку «Сгенерировать ссылку потока» соответствующего оффера или кнопку «Ссылка» требуемого потока для открытия формы генерации ссылки.</li>
			<li>В открывшейся форме выбрать понравившийся лендинг и, при необходимости, прокладку, и использовать полученную ссылку потока.</li>
		</ul>
		<p align="center"><img src="docs/flowlink.png" alt="Генерация ссылки потока" class="img-responsive" /></p>
		<p>С доступными лэндингами и прокладками можно ознакомиться на странице каждого из офферов <a href="/offers">в соответствующем разделе</a>.</p>
		<p class="small"><a href="#top"><i class="glyphicon glyphicon-chevron-up"></i> Вернуться к списку вопросов</a></p>
	</div>

	<div class="question">
		<a class="anchor" name="landing"></a>
		<h4>Какие есть лендинги для <i>%offername%</i> и какой самый лучший?</h4>
		<p>Полный список рекламных материалов (лэндингов и прокладок) по каждому из офферов можно просмотреть на его странице. Для этого в разделе «<a href="/offers">Офферы</a>» нужно открыть заинтересовавший вас оффер, щелкнув по его картинке или названию.</p>
		<p>Кроме самого списка сайтов представлены также рейтинги CR и EPC для каждого из сайтов. Самым лучшим является сайт с наивысшим EPC. Данные характеристики по сайтам предоставляются только для ознакомления и являются экспериментальными. Для новых сайтов они могут "плавать".</p>
		<p class="small"><a href="#top"><i class="glyphicon glyphicon-chevron-up"></i> Вернуться к списку вопросов</a></p>
	</div>

	<div class="question">
		<a class="anchor" name="flowlink"></a>
		<h4>Каким образом формируется ссылка потока?</h4>
		<p>Ссылка потока может формироваться тремя способами:</p>
		<dl>
			<dt>Ссылка напрямую на лэндинг</dt>
			<dd>
            	В ссылке указывается только номер потока: <code>http://landing.com/?{flow}</code>, например: <code>/?13</code>.
            	Для увеличения конверта может быть использован comebacker-скрипт, для этого в конце ссылки необходимо добавить параметр <code>cb</code> без значения, например: <code>/?13&cb</code>.
            	Некоторые рекламные сети искажают ссылки при передаче. Чтобы избежать этого, параметр потока можно задавать явно, с помощью переменной <code>flow</code>, например: <code>/?flow=13</code>.
			</dd>
			<dt>Ссылка на лэндинг через прокладку</dt>
			<dd>
           		В ссылке может указываться не только номер потока, но и желаемый лэндинг: <code><?=SPACEURL;?>prelanding/?{flow}-{land}</code>, например: <code>/prelanding/?13-7</code>. Если номер лэндинга не указан явно, будет использован лендинг по умолчанию.
            	Для увеличения конверта может быть использован comebacker-скрипт, для этого в конце ссылки необходимо добавить параметр <code>cb</code> без значения, например: <code>/prelanding/?13-7&cb</code>.
            	Некоторые рекламные сети искажают ссылки при передаче. Чтобы избежать этого, параметр потока можно задавать явно, с помощью переменной <code>flow</code>, например: <code>/prelanding/?flow=13-7</code> или <code>/prelanding/?flow=13&land=7</code>.
			</dd>
			<dt>Ссылка через редирект-домен</dt>
			<dd>
				В ссылке указывается только идентификатор потока, например: <code><?=REDURL.REDURLGO;?>123</code>. Любой домен, припаркованный к <code><?=REDURL;?></code>, может быть использован как редирект-домен. Ссылки с трафбеком всегда используют редирект-домен.
			</dd>

		</dl>
		<p class="small"><a href="#top"><i class="glyphicon glyphicon-chevron-up"></i> Вернуться к списку вопросов</a></p>
	</div>

	<div class="question">
		<a class="anchor" name="subid"></a>
		<h4>Как мне использовать свои SubID?</h4>
		<p>В нашей системе вы можете использовать до 5 меток SubID. У нас они задаются следующими параметрами в URL: <code>utm_source</code>, <code>utm_content</code>, <code>utm_campaign</code>, <code>utm_term</code> и <code>utm_medium</code> - эти параметры вы можете добавить к своей ссылке потока и анализировать в <a href="/utm">соответствующем разделе</a>.</p>
		<p class="small"><a href="#top"><i class="glyphicon glyphicon-chevron-up"></i> Вернуться к списку вопросов</a></p>
	</div>

	<div class="question">
		<a class="anchor" name="postback"></a>
		<h4>Как настроить PostBack-запрос?</h4>
		<p>Вы можете получать обновления статуса заказа без использования <a href="api.php">API</a>. Все обновления в реальном времени могут направляться Вам с помощью PostBack-запроса. PostBack-запрос выполняется при <b>любом изменении</b> статуса заказа.</p>
		<p>URL для PostBack-запроса задаётся в настройках каждого из потоков. В GET-части запроса (самом URL-е) Вы можете использовать коды из таблицы ниже.</p>
		<p>По умолчанию, осуществляется только GET-запрос по указанному адресу. Если Вам требуется передача параметров в POST, допишите в начале URL PostBack-запроса <code>POST:</code>. В POST-части запроса передаются все параметры из списка ниже, названия параметров указаны в колонке POST и не могут быть переопределены.</p>
		<p>Пример простого запроса: <code>http://mydomain.ru/status.php?id={id}&flow={flow}&status={status}&reason={reason}</code></p>
		<p>Пример запроса с POST: <code>POST:http://mydomain.ru/status.php?id={id}&flow={flow}&status={status}&subid={utms}</code></p>
		<table class="table table-striped">
           	<thead><tr>
				<th>GET-код</th>
				<th>POST</th>
				<th>Описание</th>
           	</tr></thead>
           	<tbody>
				<tr>
					<td><code>{id}</code></td>
					<td><code>id</code></td>
					<td>Идентификатор заказа</td>
				</tr>
				<tr>
					<td><code>{offer}</code></td>
					<td><code>offer</code></td>
					<td>Идентификатор оффера. Список доступных ID офферов можно узнать с помощью функции <a href="api.php#offers">offers</a></td>
				</tr>
				<tr>
					<td><code>{flow}</code></td>
					<td><code>flow</code></td>
					<td>Идентификатор потока. Список доступных ID потоков можно узнать с помощью функции <a href="api.php#flows">flows</a></td>
				</tr>
				<tr>
					<td><code>{site}</code></td>
					<td><code>site</code></td>
					<td>Идентификатор сайта-лендинга. Список доступных ID сайтов можно узнать с помощью функции <a href="api.php#sites">sites</a></td>
				</tr>
				<tr>
					<td><code>{space}</code></td>
					<td><code>space</code></td>
					<td>Идентификатор сайта-прокладки. Список доступных ID сайтов можно узнать с помощью функции <a href="api.php#sites">sites</a></td>
				</tr>
				<tr>
					<td><code>{target}</code></td>
					<td><code>target</code></td>
					<td>Идентификатор цели</td>
				</tr>
				<tr>
					<td><code>{mobile}</code></td>
					<td><code>mobile</code></td>
					<td>Признак мобильного трафика (<code>0</code> - десктоп, <code>1</code> - мобильный)</td>
				</tr>
				<tr>
					<td><code>{ip}</code></td>
					<td><code>ip</code></td>
					<td>IP-адрес пользователя</td>
				</tr>
				<tr>
					<td><code>{geo}</code></td>
					<td><code>geo</code></td>
					<td>Двухбуквенный код страны заказа</td>
				</tr>
				<tr>
					<td><code>{date}</code></td>
					<td><code>date</code></td>
					<td>Время поступления заказа в формате UNIX Timestamp</td>
				</tr>
				<tr>
					<td><code>{status}</code></td>
					<td><code>status</code></td>
					<td>Статус заказа. Список статусов аналогичен описанному для функции <a href="api.php#lead">lead</a></td>
				</tr>
				<tr>
					<td><code>{reason}</code></td>
					<td><code>reason</code></td>
					<td>Причина отказа. Список причин отказа аналогичен описанному для 	функции <a href="api.php#lead">lead</a></td>
				</tr>
				<tr>
					<td><code>{cash}</code></td>
					<td><code>cash</code></td>
					<td>Отчисления за принятый заказ (отсылается только в момент одобрения заказа)</td>
				</tr>
				<tr>
					<td><code>{price}</code></td>
					<td><code>price</code></td>
					<td>Общая стоимость заказа</td>
				</tr>
				<tr>
					<td><code>{count}</code></td>
					<td><code>count</code></td>
					<td>Количество товаров в заказе</td>
				</tr>
				<tr>
					<td><code>{utms}</code></td>
					<td><code>utms</code></td>
					<td>UTM-метка: <code>utm_source</code></td>
				</tr>
				<tr>
					<td><code>{utmc}</code></td>
					<td><code>utmc</code></td>
					<td>UTM-метка: <code>utm_campaign</code></td>
				</tr>
				<tr>
					<td><code>{utmn}</code></td>
					<td><code>utmn</code></td>
					<td>UTM-метка: <code>utm_content</code></td>
				</tr>
				<tr>
					<td><code>{utmt}</code></td>
					<td><code>utmt</code></td>
					<td>UTM-метка: <code>utm_term</code></td>
				</tr>
				<tr>
					<td><code>{utmm}</code></td>
					<td><code>utmm</code></td>
					<td>UTM-метка: <code>utm_medium</code></td>
				</tr>
           	</tbody>
		</table>
		<p>Переменная <code>{status}</code> может принимать следующие значения:</p>
		<ul>
			<li><code>1</code> - Новый заказ (<b class="text-info">ожидание</b>)</li>
			<li><code>2</code> - В обработке (<b class="text-info">ожидание</b>)</li>
			<li><code>3</code> - Перезвонить (<b class="text-info">ожидание</b>)</li>
			<li><code>4</code> - Недозвон (<b class="text-info">ожидание</b>)</li>
			<li><code>5</code> - Отменён (<b class="text-danger">отказ</b>)</li>
			<li><code>6</code> - На упаковке (<b class="text-success">заказ принят</b>)</li>
			<li><code>7</code> - Отправка (<b class="text-success">заказ принят</b>)</li>
			<li><code>8</code> - В пути (<b class="text-success">заказ принят</b>)</li>
			<li><code>9</code> - Доставлен (<b class="text-success">заказ принят</b>)</li>
			<li><code>10</code> - Оплачен (<b class="text-success">заказ принят</b>)</li>
			<li><code>11</code> - Возврат (<b class="text-success">заказ принят</b>)</li>
			<li><code>12</code> - Удалён за фрод (<b class="text-danger">отказ</b>)</li>
		</ul>
		<p>Если Вам необходимо использовать свои значения статуса вместо указанных, Вы можете переопределить их, используя параметр: <code>{stage:Новый|Обработка|Перезвонить|Недозвон|Отмена|Упаковка|Отправка|Доставка|Доставлен|Оплачен|Возврат|Удалён}</code>, параметр
<code>{stage:0|0|0|0|2|1|1|1|1|1|1|2}</code> выдаст <code>0</code> для обработки, <code>1</code> для принятого и <code>2</code> для отклонённого заказа, а <code>{stage:P|P|P|P|D|A|A|A|A|A|A|D}</code> идеально подойдёт для OctoTracker.</p>
		<p class="small"><a href="#top"><i class="glyphicon glyphicon-chevron-up"></i> Вернуться к списку вопросов</a></p>
	</div>

	<div class="question">
		<a class="anchor" name="calls"></a>
		<h4>Как осуществляется обзвон?</h4>
		<p>Поставщики занимаются обзвоном клиентов с 10:00 до 22:00 по московскому времени ежедневно. В среднем, первый звонок покупателю поступает в течение часа с момента появления заказа. Возможны перерывы в обзвоне в праздничные дни (Новый год, 8 марта, 1 и 9 мая, 12 июня, 4 ноября).</p>
		<p>Заказы в статусе «Недозвон» обрабатываются в течение недели с момента поступления. В случае, если за этот срок дозвониться до покупателя не удалось, лид удаляется.</p>
		<p class="small"><a href="#top"><i class="glyphicon glyphicon-chevron-up"></i> Вернуться к списку вопросов</a></p>
	</div>

	<div class="question">
		<a class="anchor" name="outpay"></a>
		<h4>Как осуществляются выплаты?</h4>
		<p>Выплаты осуществляются в рабочие дни. Срок выплаты - 5-7 рабочих (банковских) дней с момента получения запроса. В случае большого количества выплат в системе возможны задержки до 2 недель.</p>
		<p>Минимальная сумма выплаты - 2000 рублей. Вывод средств осуществляется на WebMoney WMR-кошельки.</p>
		<p>Холд первой выплаты - 1 неделя. В случае <a href="#check">наличия подозрительных заказов</a> выплаты могут быть задержаны.</p>
		<p class="small"><a href="#top"><i class="glyphicon glyphicon-chevron-up"></i> Вернуться к списку вопросов</a></p>
	</div>

	<div class="question">
		<a class="anchor" name="noout"></a>
		<h4>Почему мне не выводят деньги?!</h4>
		<p>Прежде всего, перечитайте ещё раз вопрос <a href="#outpay">о сроках выплат</a>.</p>
		<p>Если по срокам выплаты уже обязаны были пройти: загляните в раздел «<a href="/lead">Статистика по лидам</a>» и проверьте, нет ли у какого-либо лида подписи «<a href="#check">Заказ на проверке</a>».</p>
		<p>Если сроки превышены и заказов на проверке нет, смело <a href="/support">пишите в техподдержку</a>!</p>
		<p class="small"><a href="#top"><i class="glyphicon glyphicon-chevron-up"></i> Вернуться к списку вопросов</a></p>
	</div>

	<div class="question">
		<a class="anchor" name="check"></a>
		<h4>Что значит подпись <code>Заказ на проверке</code> в статистике по лидам?</h4>
		<p>При просмотре раздела «<a href="/lead">Статистика по лидам</a>», вы можете заметить у некоторых не отклонённых лидов подпись «Заказ на проверке». Выглядит это как на рисунке ниже.</p>
		<p align="center"><img src="docs/check.png" alt="Заказ на проверке" class="img-responsive" /></p>
		<p>Данная надпись означает, что лид попал под проверку трафика из-за подозрений во фроде. Выплата по данному лиду будет задержана до момента доставки товара получателю и оплаты им товара. Проверка заказов на фрод производится как в автоматическом, так и в ручном режиме. Подозрительные заказы в дальнейшем контролируются службой безопасности в индивидуальном порядке.</p>
		<p class="text-success">В том случае, когда на добрую сотню ваших лидов попался один такой заказ, не отчаивайтесь - он ни коим образом не повлияет на вывод средств. Все выплаты будут осуществляться в срок.</p>
		<p class="text-warning"><b>Важно:</b> если подозрительных лидов от вас поступило слишком много, все выплаты блокируются до доставки заказов получателям. В такой ситуации пользователь может быть позднее заблокирован за фрод с полной отменой всех заказов.</p>
		<p class="small"><a href="#top"><i class="glyphicon glyphicon-chevron-up"></i> Вернуться к списку вопросов</a></p>
	</div>

	<div class="question">
		<a class="anchor" name="getname"></a>
		<h4>Я хочу узнать имя / телефон / адрес заказчика</h4>
		<p>Информация об имени, телефоне и адресе заказчика является конфиденциальной и не разглашается ни при каких обстоятельствах. Аналогично вебмастер не может узнать состав заказа, количество заказанных товаров того или иного типа, сумму заказа.</p>
		<p>По каждому лиду веб-мастеру доступна следующая информация: товар (оффер), дата и время поступления, текущий статус, источник заказа (IP, лэндинг, прокладка), для некоторых офферов - количество звонков и причина отказа.</p>
		<p class="small"><a href="#top"><i class="glyphicon glyphicon-chevron-up"></i> Вернуться к списку вопросов</a></p>
	</div>

	<h2 class="qublock">Вопросы поставщика</h2>

	<div class="question">
		<a class="anchor" name="newsale"></a>
		<h4>Я хочу присоединиться к вам в роли поставщика!</h4>
		<p>Чтобы присоединиться к нашему проекту в роли поставщика, свяжитесь с нами по почте <a href="mailto:<?=SITEMAIL;?>"><?=SITEMAIL;?></a>. Мы обсудим детали работы вашей компании и подготовим необходимые инструменты для начала работы.</p>
		<p class="small"><a href="#top"><i class="glyphicon glyphicon-chevron-up"></i> Вернуться к списку вопросов</a></p>
	</div>

	<div class="question">
		<a class="anchor" name="saleface"></a>
		<h4>У меня уже есть интерфейс обработки заказов и он меня устраивает</h4>
		<p>Мы можем передавать все заказы, поступающие к нам, в ваш интерфейс с помощью удобных вам инструментов или наших API. Детали интеграции специалисты нашего технического отдела могут обсудить с вами по почте <a href="mailto:<?=SITEMAIL;?>"><?=SITEMAIL;?></a>.</p>
		<p class="small"><a href="#top"><i class="glyphicon glyphicon-chevron-up"></i> Вернуться к списку вопросов</a></p>
	</div>

</div>
</body>
</html>