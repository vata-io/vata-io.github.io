<?php

/*******************************************************************************

 *
 * 	AlterVision Core Framework - CPA platform
 * 	Created by AlterVision - altervision.me
 *  Copyright © 2005-2015 Anton Reznichenko
 *

 *
 *  File: 			lib / addr.php
 *  Description:	Address parser
 *  Author:			Anton 'AlterVision' Reznichenko - altervision13@gmail.com
 *

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 2 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.

*******************************************************************************/

function checkaddr ( $addr ) {
	$cached = PATH . 'data/cache/addr-' . md5( $addr ) . '.txt';
	if ( ! file_exists( $cached ) ) {

		$data = parseaddress( $addr );

		if ( count( $data ) ) {

			$ind = 0;
			$ad = '';
			$region = $city = $street = $house = '';
			foreach ( $data as $d ) {

				if ( $d['id'] == 'zip' ) {
					$ind = $d['value'];
					continue;
				} else {
					if ( $d['id'] == 'region' || $d['id'] == 'district' ) {
						if ( $d['type'] == 'Респ' || $d['type'] == 'г' ) {
							$ad .= trim( $d['type'], '. ' ) . '. ' . $d['value'] . ', ';
						} else $ad .= $d['value'] . ' ' . $d['type'] . ', ';
					} else {
						if ( $d['type'] == 'ДОМ' || $d['type'] == 'дом' ) $d['type'] = 'д';
						$ad .= trim( $d['type'], '. ' ) . '. ' . $d['value'] . ', ';
					}
				}

	        	if ( $d['id'] == 'street' ) $street = trim( $d['type'], '. ' ) .'. '.$d['value'];
	        	elseif ( $d['id'] == 'city' || $d['id'] == 'place' ) $city .= $d['value'] . ', ';
	        	elseif ( $d['id'] == 'district' ) $city .=  $d['value'] . ' ' .trim( $d['type'], '. ' ).', ';
				elseif ( $d['id'] == 'region' ) {
				    if ( $d['type'] != 'г' ) {
						if ( $d['type'] == 'Респ' ) {
							$area = trim( $d['type'], '. ' ) . '. ' . $d['value'];
						} else $area = $d['value'] . ' ' . $d['type'];
					} else $city = $d['value'] . ', ';
				} else {
					if ( $d['type'] == 'ДОМ' || $d['type'] == 'дом' ) $d['type'] = 'д';
					$house .= trim( $d['type'], '. ' ) . '. ' . $d['value'] . ', ';
				}

			}

			$ad = trim( $ad, ' ,' );
			$house = trim ( $house, ', ' );
			$city = trim ( $city, ', ' );

			if ( $city == 'Москва' && ! $area ) $area = 'Московская обл.';
			if ( $city == 'Санкт-Петербург' && ! $area ) $area = 'Ленинградская обл.';

			$result = array(
				'status'	=> 'ok',
				'ind'		=> $ind,
				'addr'		=> $ad,
				'area'		=> $area,
				'city'		=> $city,
				'street'	=> $street,
				'house'		=> $house,
				'text'		=> sprintf( "Адрес распознан.\nИндекс: %s\nАдрес: %s\nОбласть: %s\nГород: %s\nУлица: %s\nДом: %s\nПодставить её в заказ?", $ind, $ad, $area, $city, $street, $house ),
			);

		} else $result = array( 'status' => 'error', 'text' => sprintf( 'Не удалось распознать адрес: %s', $addr ) );

		$result = json_encode( $result );
		file_put_contents( $cached, $result );
		return $result;

	} else return file_get_contents( $cached );

}

function normalizeaddr ( $addr ) {
	$addr = str_replace( '.', '. ', $addr );
	$addr = str_replace( ',', ', ', $addr );
	$addr = preg_replace( '/([0-9]+)/', ' $1 ', $addr );
	$addr = preg_replace( '/\.+/', '.', $addr );
	$addr = preg_replace( '/\,+/', ',', $addr );
	$addr = preg_replace( '/ +/', ' ', $addr );
	$addr = preg_replace( '/([0-9]+) ([a-zа-я]{1})[ \.\,]/', '$1$2', $addr );
	$addr = str_replace( '. ,', '.,', $addr );
	return $addr;

}

function parseaddress ( $addr ) {
	$cached = sprintf( ADDR_CACHE, md5( $addr ) );
	if (  !file_exists( $cached ) ) {

		if (defined( 'ADDR_XML' )) {

			$data = array();
			$info = file_get_contents( ADDR_XML . rawurlencode( $addr ) );

			if ( $info ) {
				$dp = simplexml_load_string( $info );
				foreach ( $dp->Address->Field as $f ) {
					$ff = $f->attributes();
					$value = (string) $ff['name'];
					if ( $value ) $data[] = array( 'id' => strtolower( $ff['level'] ), 'value' => $value, 'type' => (string) $ff['type']  );
				}

			}

		}

		if ( ! $data ) {

			if (defined( 'ADDR_ALT' )) {

				$data = array();
				$info = file_get_contents( ADDR_ALT . rawurlencode( $addr ) );

				if ( $info ) {

					$dp = simplexml_load_string( $info );
					foreach ( $dp->Address->Field as $f ) {
						$ff = $f->attributes();
						$value = (string) $ff['name'];
						if ( $value ) $data[] = array( 'id' => strtolower( $ff['level'] ), 'value' => $value, 'type' => (string) $ff['type']  );
					}

				}

			}

			if ( ! $data ) {

				$curl = curl_init( 'http://ahunter.ru/site/address/search' );
				curl_setopt( $curl, CURLOPT_REFERER, 'http://ahunter.ru/' );
				curl_setopt( $curl, CURLOPT_RETURNTRANSFER, 1 );
				curl_setopt( $curl, CURLOPT_POST, 1 );
				curl_setopt( $curl, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:45.0) Gecko/20100101 Firefox/45.0' );
				curl_setopt( $curl, CURLOPT_POSTFIELDS, 'query='.rawurlencode( $addr ) );
				curl_setopt( $curl, CURLOPT_HTTPHEADER, array(
					'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
					'Accept-Language: ru-RU,ru;q=0.8,en-US;q=0.5,en;q=0.3',
					'Connection: keep-alive',
					'Content-Type: application/x-www-form-urlencoded',
					'Accept-Encoding: gzip, deflate',
					'Cookie: spylog_check=1'
				));
				$result = curl_exec( $curl );
				curl_close( $curl );

				error_reporting ( 0 );
				$dom = new DOMDocument();
			   	$dom->loadHTML( $result );

				if ( !function_exists( 'domelementbyclass' ) ) {					function domelementbyclass( $dom, $tag, $class ) {
						$els = $dom->getElementsByTagName( $tag );
						foreach ( $els as $e ) {
							if ( $e->getAttribute( 'class' ) == $class ) return $e;
						} return false;
					}
				}

				$data = array();
				$table = domelementbyclass ( $dom, 'table', 'Address HLine PinkLine' );
				if ( $table ) {

					$trs = $table->getElementsByTagName( 'tr' );

					foreach ( $trs as $tr ) {
						$row = array();
						$tds = $tr->getElementsByTagName( 'td' );
						foreach ( $tds as $td ) {
							if ( $td->getAttribute( 'class' ) == 'type' ) $row['type'] = $td->nodeValue;
							if ( $td->getAttribute( 'class' ) == 'name' ) {
								$row['value'] = $td->nodeValue;
								$row['id'] = strtolower( $td->getAttribute( 'title' ) );
							}
						}
						$data[] = $row;
					}

				} else $data = array();

			}

		}

		file_put_contents( $cached, serialize( $data ) );
		return $data;

	} else return unserialize(file_get_contents( $cached ));

}