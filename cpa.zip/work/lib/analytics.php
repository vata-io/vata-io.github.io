<?php

/*******************************************************************************

 *
 * 	AlterVision Core Framework - CPA platform
 * 	Created by AlterVision - altervision.me
 *  Copyright © 2014-2015 Anton Reznichenko
 *

 *
 *  File: 			lib / analytics.php
 *  Description:	Company analysis
 *  Author:			Anton 'AlterVision' Reznichenko - altervision13@gmail.com
 *

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 2 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.

*******************************************************************************/

function analytics ( $core, $url, $cmp = false ) {
	$page = ( $core->get['page'] > 0 ) ? (int) $core->get['page'] : 1;

	$today = date( 'Ymd' );
	$yest = date( 'Ymd', strtotime( '-1 day' ) );
	$week1 = date( 'Ymd', strtotime( '-1 week' ) );
	$month = date( 'Ymd', strtotime( '-1 month' ) );
	$month3 = date( 'Ymd', strtotime( '-3 months' ) );

	// Getting params
	extract(params( $core, array( 'to' => 'date', 'from' => 'date' ) ));
	if ( ! $to || $to > $today ) $to = $today;
	if ( $from > $to ) $from = $to;
	if ( ! $from ) $from = $today;
	$ff = strtotime( date2form( $from ) . ' 00:00:00' );
	$tt = strtotime( date2form( $to ) . ' 23:59:59' );

	// Basic search data
	$param = $where = array();
	$param['from'] = date2form( $from );
	$param['to'] = date2form( $to );
	$where[] = "call_time BETWEEN '$ff' AND '$tt'";

	// Offer
	if ( $o = (int) $core->get['o'] ) {
		$param['o'] = $o;
		$where[] = "offer_id = '$o'";
	} else $o = false;

	// Offer
	if ( $wm = (int) $core->get['wm'] ) {
		$param['wm'] = $wm;
		$where[] = "wm_id = '$wm'";
	} else $wm = false;

	// Company
	if ( $cmp || $cc = (int) $core->get['c'] ) {
		if ( !$cmp ) $param['c'] = $cc;
		$where[] = $cmp ? "comp_id = '$cmp'" : "comp_id = '$cc'";
	} else $cc = false;

	$offer = $core->db->icol( "SELECT offer_id, offer_name FROM ".DB_OFFER." ORDER BY offer_name ASC" );
	$comps = $core->db->icol( "SELECT comp_id, comp_name FROM ".DB_COMP." ORDER BY comp_name ASC" );

	// Making stats
	$where = $where ? ' WHERE ' . implode( ' AND ', $where ) : '';
	$csd = $core->db->data( "SELECT order_id, offer_id, wm_id, comp_id, call_time, call_status, call_reason, call_accept, call_price, call_cur, call_in, call_out FROM ".DB_CALL.$where );

	$bc = $bw = $bo = array();
	$total = $line = array( 'ort' => array(), 'orc' => array(), 'st2' => 0, 'st3' => 0, 'st4' => 0, 'st5' => 0, 'st6' => 0, 'st7' => 0, 'st8' => 0, 'st9' => 0, 'st10' => 0, 'st11' => 0, 'st12' => 0, 'ac' => 0, 'mc' => array(), 'ma' => array(), 'mi' => 0, 'mo' => 0 );
	$total['name'] = $core->lang['total'];

	foreach ( $csd as $c ) {

		// Prepare lines		$ic = $c['comp_id'];
		$iw = $c['wm_id'];
		$io = $c['offer_id'];
		$oi = $c['order_id'];
		if (!isset( $bc[$ic] )) {
			$bc[$ic] = $line;
			$bc[$ic]['name'] = $comps[$ic];
			$bc[$ic]['u'] = $core->url( 'm', 'order?' ) . parset( $param, 'c', $ic );
		}
		if (!isset( $bw[$iw] )) {
			$bw[$iw] = $line;
			$bw[$iw]['name'] = $iw ? ( $cmp ? $iw : $core->user->get( $iw, 'user_name' ) ) : $core->lang['anal_search'];
			$bw[$iw]['u'] = $core->url( 'm', 'order?' ) . parset( $param, 'wm', $iw );
		}
		if (!isset( $bo[$io] )) {
			$bo[$io] = $line;
			$bo[$io]['name'] = $offer[$io];
			$bo[$io]['u'] = $core->url( 'm', 'order?' ) . parset( $param, 'o', $io );
		}

		// Status
		$ss = $c['call_status'];
		if ( $ss == 5 ) if ( $c['order_reason'] == 5 || $c['order_reason'] == 6 || $c['order_reason'] == 7 ) $ss = 12;

		// Total orders
		$total['ort'][$oi] = 1;
		$bc[$ic]['ort'][$oi] = 1;
		$bw[$iw]['ort'][$oi] = 1;
		$bo[$io]['ort'][$oi] = 1;

		// Order status
		$total['st'.$ss] += 1;
		$bc[$ic]['st'.$ss] += 1;
		$bw[$iw]['st'.$ss] += 1;
		$bo[$io]['st'.$ss] += 1;

		// Call Center Orders
		if ( $ss > 1 && $ss < 5 ) {
			$total['orc'][$oi] = 1;
			$bc[$ic]['orc'][$oi] = 1;
			$bw[$iw]['orc'][$oi] = 1;
			$bo[$io]['orc'][$oi] = 1;
		}

		// Approve orders
		if ( $ss == 2 || $ss == 5 || $c['call_accept'] ) {
			$total['ora'][$oi] = 1;
			$bc[$ic]['ora'][$oi] = 1;
			$bw[$iw]['ora'][$oi] = 1;
			$bo[$io]['ora'][$oi] = 1;
		}

		// Money
		if ( $c['call_accept'] ) {			$total['ac'] += 1;
			$total['mc'][$c['call_cur']] += 1;
			$total['ma'][$c['call_cur']] += $c['call_price'];
			$total['mi'] += $c['call_in'];
			$total['mo'] += $c['call_out'];
			$bc[$ic]['ac'] += 1;
			$bc[$ic]['mc'][$c['call_cur']] += 1;
			$bc[$ic]['ma'][$c['call_cur']] += $c['call_price'];
			$bc[$ic]['mi'] += $c['call_in'];
			$bc[$ic]['mo'] += $c['call_out'];
			$bw[$iw]['ac'] += 1;
			$bw[$iw]['mc'][$c['call_cur']] += 1;
			$bw[$iw]['ma'][$c['call_cur']] += $c['call_price'];
			$bw[$iw]['mi'] += $c['call_in'];
			$bw[$iw]['mo'] += $c['call_out'];
			$bo[$io]['ac'] += 1;
			$bo[$io]['mc'][$c['call_cur']] += 1;
			$bo[$io]['ma'][$c['call_cur']] += $c['call_price'];
			$bo[$io]['mi'] += $c['call_in'];
			$bo[$io]['mo'] += $c['call_out'];
		}

	}

    $core->mainline->add ( $core->lang['menu_sub_'.$url] ? $core->lang['menu_sub_'.$url] : $core->lang['menu_'.$url], $core->url('m', $url) );
    $core->header ();

	$core->tpl->load( 'body', 'analytics', defined('HACK_TPL_ANALYTICS') ? HACK : false );

	$core->tpl->vars( 'body', array(

		'from'		=> date2form( $from ),
		'to'		=> date2form( $to ),
		'admin'		=> $cmp ? false : true,
		'wm'		=> $wm,

		'offer'		=> $core->lang['offer'],
		'comp'		=> $core->lang['company'],
		'order'		=> $core->lang['order'],
		'user'		=> $core->lang['user'],
		'status'	=> $core->lang['status'],
		'time'		=> $core->lang['date'],
		'next'		=> $core->lang['log_next'],
		'length'	=> $core->lang['log_length'],
		'show'		=> $core->lang['show'],
		'noitem'	=> $core->lang['anal_noitem'],

		'today'		=> $core->lang['anal_today'],
		'yest'		=> $core->lang['anal_yest'],
		'day7'		=> $core->lang['anal_day7'],
		'day30'		=> $core->lang['anal_day30'],
		'day90'		=> $core->lang['anal_day90'],

		'u_search'	=> $core->url( 'm', $url ),
		'u_today'	=> $core->url( 'm', $url ).'?'. parmult( $param, array( 'from'=>date2form($today), 'to'=>date2form($today) )),
		'u_yest'	=> $core->url( 'm', $url ).'?'. parmult( $param, array( 'from'=>date2form($yest), 'to'=>date2form($yest) )),
		'u_day7'	=> $core->url( 'm', $url ).'?'. parmult( $param, array( 'from'=>date2form($week1), 'to'=>date2form($today) )),
		'u_day30'	=> $core->url( 'm', $url ).'?'. parmult( $param, array( 'from'=>date2form($month), 'to'=>date2form($today) )),
		'u_day90'	=> $core->url( 'm', $url ).'?'. parmult( $param, array( 'from'=>date2form($month3), 'to'=>date2form($today) )),

	));

	foreach ( $offer as $i => $of) {
		$core->tpl->block( 'body', 'offer', array(
			'name'		=> $of,
			'value'		=> $i,
			'select'	=> ( $o == $i ) ? 'selected="selected"' : '',
		));
	}

	foreach ( $comps as $i => $of) {
		$core->tpl->block( 'body', 'comp', array(
			'name'		=> $of,
			'value'		=> $i,
			'select'	=> ( $cc == $i ) ? 'selected="selected"' : '',
		));
	}

	if ( $total['ort'] ) {
		// Totals
		$core->tpl->block( 'body', 'block' );
//		$core->tpl->block( 'body', 'block.row', analyticline( $total ) );
		analyticline( $core, $total );

		// Companies
		if (!( $cmp || $cc )) {			usort( $bc, 'analyticsort' );
			$core->tpl->block( 'body', 'block', array( 'head' => $core->lang['anal_comps'] ) );
//			foreach ( $bc as $l ) $core->tpl->block( 'body', 'block.row', analyticline( $l ) );
			foreach ( $bc as $l ) analyticline( $core, $l );
		}

		// Webmasters
		if ( ! $wm ) {
			usort( $bw, 'analyticsort' );
			$core->tpl->block( 'body', 'block', array( 'head' => $core->lang['anal_users'] ) );
	//		foreach ( $bw as $l ) $core->tpl->block( 'body', 'block.row', analyticline( $l ) );
			foreach ( $bw as $l ) analyticline( $core, $l );
		}

		// Offers
		if ( ! $o ) {
			usort( $bo, 'analyticsort' );
			$core->tpl->block( 'body', 'block', array( 'head' => $core->lang['anal_offer'] ) );
//			foreach ( $bo as $l ) $core->tpl->block( 'body', 'block.row', analyticline( $l ) );
			foreach ( $bo as $l ) analyticline( $core, $l );
		}

	} else $core->tpl->block( 'body', 'no' );

	$core->tpl->output( 'body' );

	$core->footer ();
	$core->_die();

}

function analyticsort ( $a, $b ) {	return strcmp( $a['name'], $b['name'] );
}

function analyticline ( $core, $l ) {
	$ll = array( 'name' => $l['name'] );
	if ( $l['u'] ) $ll['u'] = $l['u'];
	for ( $i = 2; $i < 13; $i++ ) $ll['st'.$i] = $l['st'.$i];

	$ll['ot'] = count( $l['ort'] );
	$ll['op'] = count( $l['orc'] );
	$ll['cp'] = $l['st3'] + $l['st4'] + $l['st5'] + $l['st6'];
	$ll['pr6'] = sprintf( '%0.1f', $l['ac'] ? $l['ac'] * 100 / count( $l['ora'] ) : 0 );
	$ll['pr10'] = sprintf( '%0.1f', $l['st10'] ? $l['st10'] * 100 / ( $l['st10'] + $l['st11'] ) : 0 );
	$ll['pr11'] = sprintf( '%0.1f', $l['st11'] ? $l['st11'] * 100 / ( $l['st10'] + $l['st11'] ) : 0 );

	// Money
	$ll['mi'] = rurc( $l['mi'] );
	$ll['mo'] = rurc( $l['mo'] );
	$ll['mt'] = rurc( $l['mi'] - $l['mo'] );

	$core->tpl->block( 'body', 'block.row', $ll );
	foreach ( $l['mc'] as $cu => $cc ) {
		$core->tpl->block( 'body', 'block.row.mn', array(
			'c'	=> $core->lang['price_curs'][$cu],
			'm'	=> ceil( $l['ma'][$cu] / $cc ),
			't'	=> $l['ma'][$cu],
		));
	}
}