<?php

/*******************************************************************************

 *
 * 	AlterVision Core Framework - CPA platform
 * 	Created by AlterVision - altervision.me
 *  Copyright � 2014-2015 Anton Reznichenko
 *

 *
 *  File: 			lib / company.php
 *  Description:	Company control panel
 *  Author:			Anton 'AlterVision' Reznichenko - altervision13@gmail.com
 *

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 2 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.

*******************************************************************************/

//
// Module functions
//

function company_menu ( $core, $menu ) {
	$menu['company'] = array( 'company', 'companal', 'teams', 'personel', 'compset' );
	return $menu;

}

function company_action ( $core ) {
	$action = ( $core->get['a'] ) ? $core->get['a'] : null;
	$id		= ( $core->post['id'] ) ? (int) $core->post['id'] : ( ($core->get['id']) ? (int) $core->get['id'] : 0 );
	$ci		= $core->user->comp;

	switch ( $action ) {

	  case 'comp-info':		// Company basic information

		$edit = array(
			'comp_name'		=> $core->text->line ( $core->post['name'] ),
			'comp_fio'		=> $core->text->line ( $core->post['fio'] ),
			'comp_phone'	=> $core->text->line ( $core->post['phone'] ),
			'comp_index'	=> preg_replace( '#([^0-9]+)#', '', $core->post['index'] ),
			'comp_addr'		=> $core->text->line ( $core->post['addr'] ),
			'comp_bank'		=> $core->text->line ( $core->post['bank'] ),
			'comp_acc'		=> preg_replace( '#([^0-9]+)#', '', $core->post['acc'] ),
			'comp_ks'		=> preg_replace( '#([^0-9]+)#', '', $core->post['ks'] ),
			'comp_bik'		=> preg_replace( '#([^0-9]+)#', '', $core->post['bik'] ),
			'comp_inn'		=> preg_replace( '#([^0-9]+)#', '', $core->post['inn'] ),
			'sms_accept'		=> $core->post['sms_accept'] ? 1 : 0,
			'sms_post'			=> $core->post['sms_post'] ? 1 : 0,
			'sms_spsr'			=> $core->post['sms_spsr'] ? 1 : 0,
			'sms_rupo'			=> $core->post['sms_rupo'] ? 1 : 0,
			'autoaccept'		=> $core->post['autoaccept'] ? 1 : 0,
			'callscheme'		=> $core->text->line ( $core->post['callscheme'] ),
			'ccp_day'			=> (int) $core->post['ccp_day'],
			'ccp_night'			=> (int) $core->post['ccp_night'],
			'ccp_sale'			=> (int) $core->post['ccp_sale'],
			'ccp_upsale'		=> $core->text->line ( $core->post['ccp_upsale'] ),
		);

		if ( $core->db->edit( DB_COMP, $edit, "comp_id = '".$core->user->comp."'" ) ) {			$core->wmsale->clear( 'comp', $core->user->comp );
			$core->wmsale->clear( 'comps' );
			$core->go($core->url( 'mm', 'compset', 'save-ok' ));
	    } else $core->go($core->url( 'mm', 'compset', 'save-e' ));
/*
	  case 'comp-income':	// Company store income

		foreach ( $core->post['store'] as $i => &$s ) {
			$i = (int) $i; if ( !$i ) continue;
			if ( is_array( $s ) ) {
				foreach ( $s as $j => &$v ) {
					$j = (int) $j; if ( !$j ) continue;
					$v = (int) $v; if ( !$v ) continue;
	             	if ( $sid = $core->db->field( "SELECT store_id FROM ".DB_STORE." WHERE comp_id = '".$core->user->comp."' AND offer_id = '$i' AND var_id = '$j' LIMIT 1" ) ) {
	                	$core->db->query( "UPDATE ".DB_STORE." SET store_count = store_count + '$v' WHERE store_id = '$sid' LIMIT 1" );
	             	} else $core->db->query( "INSERT INTO ".DB_STORE." ( comp_id, offer_id, var_id, store_count ) VALUES ( '".$core->user->comp."', '$i', '$j', '$v' )" );
				} unset ( $v );
			} else {
             	$s = (int) $s; if ( !$s ) continue;
             	if ( $sid = $core->db->field( "SELECT store_id FROM ".DB_STORE." WHERE comp_id = '".$core->user->comp."' AND offer_id = '$i' AND var_id = 0 LIMIT 1" ) ) {
                	$core->db->query( "UPDATE ".DB_STORE." SET store_count = store_count + '$s' WHERE store_id = '$sid' LIMIT 1" );
             	} else $core->db->query( "INSERT INTO ".DB_STORE." ( comp_id, offer_id, var_id, store_count ) VALUES ( '".$core->user->comp."', '$i', 0, '$s' )" );
			}
		} unset ( $s );

	  	$core->go($core->url( 'mm', 'comp', 'income' ));

	  case 'comp-store':	// Company store correction

		foreach ( $core->post['store'] as $i => &$s ) {			$i = (int) $i; if ( ! $i ) continue;
			if ( is_array( $s ) ) {				foreach ( $s as $j => &$v ) {					$j = (int) $j; if ( ! $j ) continue;
	             	$v = (int) $v;
	             	if ( $v ) {
	                	$core->db->query( "REPLACE INTO ".DB_STORE." ( comp_id, offer_id, var_id, store_count ) VALUES ( '".$core->user->comp."', '$i', '$j', '$v' )" );
	             	} else $core->db->query( "DELETE FROM ".DB_STORE." WHERE comp_id = '".$core->user->comp."' AND offer_id = '$i' AND var_id = '$j' LIMIT 1" );
				} unset ( $v );
			} else {             	$s = (int) $s;
             	if ( $s ) {                	$core->db->query( "REPLACE INTO ".DB_STORE." ( comp_id, offer_id, var_id, store_count ) VALUES ( '".$core->user->comp."', '$i', 0, '$s' )" );
             	} else $core->db->query( "DELETE FROM ".DB_STORE." WHERE comp_id = '".$core->user->comp."' AND offer_id = '$i' AND var_id = 0 LIMIT 1" );
			}
		} unset ( $s );

	  	$core->go($core->url( 'mm', 'comp', 'store' ));  */

	  //
	  // Managers
	  //

	  // Add new manager
	  case 'comp-user-add':

		$name 	= $core->text->line ( $core->post['name'] );
		$email	= $core->text->email ( $core->post['email'] );
		$pass	= $core->text->pass ( trim( $core->post['pass'] ) );
		$team	= (int) $core->post['team'];

		$uid = $core->db->field( "SELECT user_id FROM ".DB_USER." WHERE user_mail = '$email' LIMIT 1" );
		if ( ! $uid ) {

		    $sql = "INSERT INTO ".DB_USER." SET user_name = '$name', user_mail = '$email', user_pass = '$pass', user_work = 1, user_comp = '$ci', user_team = '$team'";
		    if ( $name && $email && trim($core->post['pass']) && $core->db->query( $sql ) ) {				$uid = $core->db->lastid();
				$core->wmsale->clear( 'mans', $core->user->comp );
				$core->wmsale->clear( 'allman' );
		        $core->go($core->url( 'im', 'personel', $uid, 'ok' ));
		    } else $core->go($core->url( 'mm', 'personel', 'error' ));

		} else $core->go($core->url( 'mm', 'personel', 'exists' ));

	  // Edit manager data
	  case 'comp-user-edit':

		$user = $core->db->row( "SELECT * FROM ".DB_USER." WHERE user_id = '$id' LIMIT 1" );
		if ( $user['user_comp'] && $user['user_comp'] == $ci ) {

			$email	= $core->text->email ( $core->post['email'] );
			if ( $email != $user['user_mail'] ) {				$uid = $core->db->field( "SELECT user_id FROM ".DB_USER." WHERE user_mail = '$email' LIMIT 1" );
				if ( $uid ) $core->go($core->url( 'mm', 'personel', 'exists' ));
			}

			$data = array(
				'user_name'		=> $core->text->line ( $core->post['name'] ),
				'user_mail'		=> $email,
				'user_ban'		=> $core->post['ban'] ? 1 : 0,
				'user_compad'	=> $core->post['compad'] ? 1 : 0,
				'user_team'		=> (int) $core->post['team'],
				'user_teamlead'	=> $core->post['teamlead'] ? 1 : 0,
			);
			if ( $pass = trim( $core->post['pass'] ) ) $data['user_pass'] = $core->text->pass( $pass );

			if ( $data['user_ban'] && $id == $core->user->id ) $core->go($core->url( 'mm', 'personel', 'access' ));
			if ( !$data['user_compad'] && $id == $core->user->id ) $core->go($core->url( 'mm', 'personel', 'access' ));

		    if ( $core->user->set ( $id, $data ) ) {
				$core->wmsale->clear( 'mans', $core->user->comp );
				$core->wmsale->clear( 'allman' );
				$core->go($core->url( 'mm', 'personel', 'ok' ));
		    } else $core->go($core->url( 'mm', 'personel', 'error' ));

		} else $core->go($core->url( 'mm', 'personel', 'access' ));

	  // Deleting manager
	  case 'comp-user-del':

		$user = $core->db->row( "SELECT * FROM ".DB_USER." WHERE user_id = '$id' LIMIT 1" );
		if ( $id != 1 && $id != $core->user->id && $user['user_comp'] == $ci ) {
			$core->db->query( "DELETE FROM ".DB_CASH." WHERE user_id = '$id'" );
			if ( $core->db->query ( "DELETE FROM ".DB_USER." WHERE user_id = '$id'" ) ) {
				$core->wmsale->clear( 'mans', $core->user->comp );
				$core->wmsale->clear( 'allman' );
				$core->go($core->url( 'mm', 'personel', 'ok' ));
			} else $core->go($core->url( 'mm', 'personel', 'error' ));
		} else $core->go($core->url( 'mm', 'personel', 'access' ));

	  //
	  // Team mamagement
	  //

	  // Add new team
	  case 'team-add':

		$name = $core->text->line( $core->post['name'] );
		if ( ! $name ) $core->go($core->url( 'mm', 'teams', 'error' ));

		$data = array( 'team_name' => $name, 'comp_id' => $ci );
		if ( $core->db->add( DB_TEAM, $data ) ) {			$ti = $core->db->lastid();
			$core->wmsale->clear( 'teams', $ci );
			$core->go($core->url( 'im', 'teams', $ti, 'ok' ));
		} else $core->go($core->url( 'mm', 'teams', 'error' ));

	  // Edit team info
	  case 'team-edit':

		$tc = $core->db->field( "SELECT comp_id FROM ".DB_TEAM." WHERE team_id = '$id' LIMIT 1" );
		if ( $tc != $ci ) $core->go($core->url( 'mm', 'teams', 'access' ));

		$data = array(
			'team_name'		=> $core->text->line( $core->post['name'] ),
			'team_call'		=> $core->post['call'] ? 1 : 0,
			'team_pack'		=> $core->post['pack'] ? 1 : 0,
			'team_send'		=> $core->post['send'] ? 1 : 0,
			'team_delivery'	=> $core->post['delivery'] ? 1 : 0,
			'team_mod'		=> $core->post['mod'] ? 1 : 0,
			'pay_use'		=> $core->post['pay_use'] ? 1 : 0,
			'pay_day'		=> (int) $core->post['pay_day'],
			'pay_night'		=> (int) $core->post['pay_night'],
			'pay_sale'		=> (int) $core->post['pay_sale'],
			'pay_upsale'	=> $core->text->line ( $core->post['pay_upsale'] ),
		);

		if ( $core->db->edit( DB_TEAM, $data, "team_id = '$id'" ) ) {			$core->wmsale->clear( 'team', $id );
			$core->wmsale->clear( 'teams', $ci );
			$core->go($core->url( 'mm', 'teams', 'ok' ));
		} else $core->go($core->url( 'mm', 'teams', 'error' ));

	  // Detele team
	  case 'team-del':

		$tc = $core->db->field( "SELECT comp_id FROM ".DB_TEAM." WHERE team_id = '$id' LIMIT 1" );
		if ( $tc == $ci ) {
			if ( $core->db->query ( "DELETE FROM ".DB_TEAM." WHERE team_id = '$id' LIMIT 1" ) ) {
				$core->db->query( "UPDATE ".DB_USER." SET user_team = 0, user_teamlead = 0 WHERE user_team = '$id'" );
				$core->wmsale->clear( 'teams', $ci );
				$core->go($core->url( 'mm', 'teams', 'ok' ));
			} else $core->go($core->url( 'mm', 'teams', 'error' ));
		} else $core->go($core->url( 'mm', 'teams', 'access' ));

	}

	return false;

}

function company_module ( $core ) {
	$module	= ( $core->get['m'] ) ? $core->get['m'] : null;
	$id		= ( $core->post['id'] ) ? (int) $core->post['id'] : ( ($core->get['id']) ? (int) $core->get['id'] : 0 );
	$page	= ( $core->get['page'] > 0 ) ? (int) $core->get['page'] : 1;
	$message = ( $core->get['message'] ) ? $core->get['message'] : null;

	$ci		= $core->user->comp;
	$comp 	= $core->wmsale->get( 'comp', $ci );

	switch ( $module ) {

	  case 'compset':

		$core->mainline->add ( $core->lang['company'], $core->url( 'm', 'comp' ) );
		$core->mainline->add ( $core->lang['comp_info_h'] );
		$core->header ();

		$title	= $core->lang['comp_info_h'];
		$action	= $core->url ( 'a', 'comp-info', '' );
		$method	= 'post';
		$field 	= array(
			array( 'type' => 'line', 'value' => $core->text->lines( $core->lang['comp_info_t'] ) ),
			array( 'type' => 'text', 'length' => 100, 'name' => 'name', 'head' => $core->lang['name'], 'value' => $comp['comp_name']),
			array( 'type' => 'text', 'length' => 100, 'name' => 'fio', 'head' => $core->lang['comp_name'], 'descr' => $core->lang['comp_name_d'], 'value' => $comp['comp_fio']),
			array( 'type' => 'text', 'length' => 100, 'name' => 'phone', 'head' => $core->lang['phone'], 'value' => $comp['comp_phone']),
			array( 'type' => 'text', 'length' => 100, 'name' => 'addr', 'head' => $core->lang['address'], 'descr' => $core->lang['comp_addr_d'], 'value' => $comp['comp_addr']),
			array( 'type' => 'text', 'length' => 8, 'name' => 'index', 'head' => $core->lang['index'], 'descr' => $core->lang['comp_index_d'], 'value' => $comp['comp_index']),
			array( 'type' => 'head', 'value' => $core->lang['comp_banking'] ),
			array( 'type' => 'text', 'length' => 100, 'name' => 'bank', 'head' => $core->lang['comp_bank'], 'descr' => $core->lang['comp_bank_d'], 'value' => $comp['comp_bank']),
			array( 'type' => 'text', 'length' => 15, 'name' => 'bik', 'head' => $core->lang['comp_bik'], 'value' => $comp['comp_bik']),
			array( 'type' => 'text', 'length' => 30, 'name' => 'acc', 'head' => $core->lang['comp_acc'], 'value' => $comp['comp_acc']),
			array( 'type' => 'text', 'length' => 30, 'name' => 'ks', 'head' => $core->lang['comp_ks'], 'value' => $comp['comp_ks']),
			array( 'type' => 'text', 'length' => 15, 'name' => 'inn', 'head' => $core->lang['comp_inn'], 'descr' => $core->lang['comp_inn_d'], 'value' => $comp['comp_inn']),
			array( 'type' => 'head', 'value' => $core->lang['comp_sms'] ),
            array( 'type' => 'checkbox', 'name' => 'sms_accept', 'head' => $core->lang['comp_sms_accept'], 'descr' => $core->lang['comp_sms_accept_d'], 'checked' => $comp['sms_accept'] ),
            array( 'type' => 'checkbox', 'name' => 'sms_post', 'head' => $core->lang['comp_sms_post'], 'descr' => $core->lang['comp_sms_post_d'], 'checked' => $comp['sms_post'] ),
            array( 'type' => 'checkbox', 'name' => 'sms_spsr', 'head' => $core->lang['comp_sms_spsr'], 'descr' => $core->lang['comp_sms_spsr_d'], 'checked' => $comp['sms_spsr'] ),
            array( 'type' => 'checkbox', 'name' => 'sms_rupo', 'head' => $core->lang['comp_sms_rupo'], 'descr' => $core->lang['comp_sms_rupo_d'], 'checked' => $comp['sms_rupo'] ),
            array( 'type' => 'checkbox', 'name' => 'autoaccept', 'head' => $core->lang['comp_autoaccept'], 'descr' => $core->lang['comp_autoaccept_d'], 'checked' => $comp['autoaccept'] ),
            array( 'type' => 'text', 'name' => 'callscheme', 'head' => $core->lang['comp_callscheme'], 'descr' => $core->lang['comp_callscheme_d'], 'value' => $comp['callscheme'] ),
			array( 'type' => 'head', 'value' => $core->lang['comp_ccp'] ),
			array( 'type' => 'line', 'value' => $core->text->lines($core->lang['comp_ccp_d']) ),
			array( 'type' => 'text', 'name' => 'ccp_day', 'head' => $core->lang['comp_ccp_day'], 'descr' => $core->lang['comp_ccp_day_d'], 'value' => $comp['ccp_day']),
			array( 'type' => 'text', 'name' => 'ccp_night', 'head' => $core->lang['comp_ccp_night'], 'descr' => $core->lang['comp_ccp_night_d'], 'value' => $comp['ccp_night']),
			array( 'type' => 'text', 'name' => 'ccp_sale', 'head' => $core->lang['comp_ccp_sale'], 'descr' => $core->lang['comp_ccp_sale_d'], 'value' => $comp['ccp_sale']),
			array( 'type' => 'text', 'name' => 'ccp_upsale', 'head' => $core->lang['comp_ccp_upsale'], 'descr' => $core->lang['comp_ccp_upsale_d'], 'value' => $comp['ccp_upsale']),
		);
		$button = array(array('type' => 'submit', 'value' => $core->lang['save']));
		$core->form ('comp', $action, $method, $title, $field, $button);

		$core->footer ();
		$core->_die();

/*	  case 'comp-store': $isstore = true;
	  case 'comp-income':

		$oids = $core->db->col( "SELECT offer_id FROM ".DB_SITE." WHERE comp_id = '".$core->user->comp."'" );
		$stores = $core->db->data( "SELECT * FROM ".DB_STORE." WHERE comp_id = '".$core->user->comp."'" );
		$store = array();
		foreach ( $stores as &$s ) {
			if ( ! isset( $store[$s['offer_id']] ) ) $store[$s['offer_id']] = array( 'count' => 0, 'vars' => array() );
			if ( $s['var_id'] ) {
				$store[$s['offer_id']]['vars'][$s['var_id']] = array( 'count' => $s['store_count'] );
			} else $store[$s['offer_id']]['count'] = $s['store_count'];
			$oids[] = $s['offer_id'];
		} unset ( $s, $stores );
		$oids = implode( ', ', array_unique( $oids ) );

		// Storage offers
		$offers = $oids ? $core->db->data( "SELECT offer_id, offer_name FROM ".DB_OFFER." WHERE offer_id IN ( $oids )" ) : array();
		foreach ( $offers as &$o ) {
			$store[$o['offer_id']]['name'] = $o['offer_name'];
		} unset ( $o, $offers );

		// Storage offer variants
		$vars = $oids ? $core->db->data( "SELECT offer_id, var_id, var_name, var_price FROM ".DB_VARS." WHERE offer_id IN ( $oids )" ) : array();
		foreach ( $vars as &$o ) {
			$store[$o['offer_id']]['vars'][$o['var_id']]['name'] = $o['var_name'];
		} unset ( $o, $vars );

		$core->mainline->add ( $core->lang['company'], $core->url('m', 'comp') );
		$core->mainline->add ( $isstore ? $core->lang['comp_store_h'] : $core->lang['comp_income_h'] );
		$core->header ();

		$title	= $isstore ? $core->lang['comp_store_h'] : $core->lang['comp_income_h'];
		$action	= $core->url ( 'a', $isstore ? 'comp-store' : 'comp-income', '' );
		$method	= 'post';
		$field 	= array(array( 'type' => 'line', 'value' => $core->text->lines( $isstore ? $core->lang['comp_store_t'] : $core->lang['comp_income_t'] ) ));

		foreach ( $store as $i => &$s ) {			$field[] = array( 'type' => 'head', 'value' => $s['name'] );
			if ( $s['vars'] ) {            	foreach ( $s['vars'] as $j => &$v ) {					$field[] = array( 'type' => 'text', 'name' => "store[$i][$j]", 'head' => $v['name'], 'value' => $isstore ? (int) $v['count'] : '' );
            	} unset ( $j, $v );
			} else $field[] = array( 'type' => 'text', 'name' => "store[$i]", 'head' => $s['name'], 'value' => $isstore ? (int) $s['count'] : '' );
		} unset ( $s, $store );

		$button = array(array('type' => 'submit', 'value' => $isstore ? $core->lang['save'] : $core->lang['comp_income_do'] ));
		$core->form ('store', $action, $method, $title, $field, $button);

		$core->footer ();
		$core->_die();    */

	  case 'company':

		require_once PATH_LIB . 'callstat.php';
		callstat ( $core, 'company' );

	  case 'companal':

		require_once PATH . 'lib/analytics.php';
		analytics ( $core, 'companal', $core->user->comp );

	  // Teams
	  case 'teams':

		switch ( $message ) {
	    	case 'ok':		$core->info( 'info', 'done_basic' ); break;
	    	case 'error':	$core->info( 'info', 'error_basic' ); break;
	    	case 'access':	$core->info( 'error', 'access_denied' ); break;
		}

		if ( $id ) {
    		$t = $core->wmsale->get( 'team', $id );

			$core->mainline->add ( $core->lang['company'], $core->url('m', 'comp') );
			$core->mainline->add ( $core->lang['teams'], $core->url('m', 'teams') );
			$core->mainline->add ( $t['team_name'] );
			$core->header ();

		    $field 	= array(
				array('type' => 'line', 'value' => $core->text->lines( $core->lang['company_team_edit_t'] ) ),
	            array('type' => 'text', 'length' => 100, 'name' => 'name', 'head' => $core->lang['team_name'], 'descr' => $core->lang['team_name_d'], 'value' => $t['team_name'] ),
	            array('type' => 'checkbox', 'name' => 'call', 'head' => $core->lang['team_call'], 'descr' => $core->lang['team_call_d'], 'checked' => $t['team_call'] ),
	            array('type' => 'checkbox', 'name' => 'pack', 'head' => $core->lang['team_pack'], 'descr' => $core->lang['team_pack_d'], 'checked' => $t['team_pack'] ),
	            array('type' => 'checkbox', 'name' => 'send', 'head' => $core->lang['team_send'], 'descr' => $core->lang['team_send_d'], 'checked' => $t['team_send'] ),
	            array('type' => 'checkbox', 'name' => 'delivery', 'head' => $core->lang['team_delivery'], 'descr' => $core->lang['team_delivery_d'], 'checked' => $t['team_delivery'] ),
	            array('type' => 'checkbox', 'name' => 'mod', 'head' => $core->lang['team_mod'], 'descr' => $core->lang['team_mod_d'], 'checked' => $t['team_mod'] ),
				array( 'type' => 'head', 'value' => $core->lang['comp_ccp'] ),
				array( 'type' => 'line', 'value' => $core->text->lines($core->lang['comp_ccp_d']) ),
	            array('type' => 'checkbox', 'name' => 'pay_use', 'head' => $core->lang['comp_ccp_use'], 'descr' => $core->lang['comp_ccp_use_d'], 'checked' => $t['pay_use'] ),
				array( 'type' => 'text', 'name' => 'pay_day', 'head' => $core->lang['comp_ccp_day'], 'descr' => $core->lang['comp_ccp_day_d'], 'value' => $t['pay_day']),
				array( 'type' => 'text', 'name' => 'pay_night', 'head' => $core->lang['comp_ccp_night'], 'descr' => $core->lang['comp_ccp_night_d'], 'value' => $t['pay_night']),
				array( 'type' => 'text', 'name' => 'pay_sale', 'head' => $core->lang['comp_ccp_sale'], 'descr' => $core->lang['comp_ccp_sale_d'], 'value' => $t['pay_sale']),
				array( 'type' => 'text', 'name' => 'pay_upsale', 'head' => $core->lang['comp_ccp_upsale'], 'descr' => $core->lang['comp_ccp_upsale_d'], 'value' => $t['pay_upsale']),
		    );
		    $button = array(array('type' => 'submit', 'value' => $core->lang['save']));
		    $core->form ( 'useradd', $core->url ( 'a', 'team-edit', $id ), 'post', $core->lang['company_team_edit_h'], $field, $button );

			$core->footer();

		} else {
			$teams = $core->db->data( "SELECT * FROM ".DB_TEAM." WHERE comp_id = '$ci' ORDER BY team_name ASC" );

			$core->mainline->add ( $core->lang['company'], $core->url('m', 'comp') );
			$core->mainline->add ( $core->lang['teams'] );
			$core->header ();

			$core->tpl->load( 'body', 'list', defined('HACK_TPL_LIST') ? HACK : false );

			$core->tpl->vars( 'body', array(
				'title'			=> $core->lang['company_teams_h'],
				'text'			=> $core->text->lines( $core->lang['company_teams_t'] ),
				'name'			=> $core->lang['name'],
				'info'			=> $core->lang['access'],
				'action'		=> $core->lang['action'],
				'edit'			=> $core->lang['edit'],
				'del'			=> $core->lang['del'],
				'confirm'		=> $core->lang['confirm'],
			));

			if ( $teams ) {				foreach ( $teams as $t ) {
					$auths = array();
					if ( $t['team_call'] ) $auths[] = '<span class="status status100">'.$core->lang['team_call'].'</span>';
					if ( $t['team_pack'] ) $auths[] = '<span class="status status6">'.$core->lang['team_pack'].'</span>';
					if ( $t['team_send'] ) $auths[] = '<span class="status status7">'.$core->lang['team_send'].'</span>';
					if ( $t['team_delivery'] ) $auths[] = '<span class="status status8">'.$core->lang['team_delivery'].'</span>';
					if ( $t['team_mod'] ) $auths[] = '<span class="status status-1">'.$core->lang['team_mod'].'</span>';

					if ( $auths ) {						$auths = implode( ' ', $auths );
					} else $auths = '<span class="browse">'.$core->lang['team_readonly'].'</span>';

					$core->tpl->block( 'body', 'item', array(
						'id'	=> $t['team_id'],
						'name'	=> $t['team_name'],
						'info'	=> $auths,
						'url'	=> $core->url( 'i', 'teams', $t['team_id'] ),
						'edit'	=> $core->url( 'i', 'teams', $t['team_id'] ),
						'del'	=> $core->url( 'a', 'team-del', $t['team_id'] ),
					));

				}
			} else $core->tpl->block( 'body', 'noitem' );

			$core->tpl->output( 'body' );

		    $field 	= array(
				array( 'type' => 'line', 'value' => $core->text->lines( $core->lang['company_team_add_t'] ) ),
	            array('type' => 'text', 'length' => 100, 'name' => 'name', 'head' => $core->lang['team_name'], 'descr' => $core->lang['team_name_d'] ),
		    );
		    $button = array(array('type' => 'submit', 'value' => $core->lang['create']));
		    $core->form ( 'useradd', $core->url ( 'a', 'team-add', '' ), 'post', $core->lang['company_team_add_h'], $field, $button );

			$core->footer();

		}

	  	$core->_die();

	  // Company workers
	  case 'personel':

		switch ( $message ) {
	    	case 'ok':		$core->info( 'info', 'done_basic' ); break;
	    	case 'error':	$core->info( 'info', 'error_basic' ); break;
	    	case 'exists':	$core->info( 'error', 'error_user_exist' ); break;
	    	case 'access':	$core->info( 'error', 'access_denied' ); break;
		}

		if ( $id ) {

			$user = $core->db->row ( "SELECT * FROM ".DB_USER." WHERE user_id = '$id' LIMIT 1" );
			if ( $user['user_comp'] != $ci ) $core->go($core->url( 'mm', 'personel', 'access' ));

			$teams = $core->wmsale->get( 'teams', $ci );
			if ( $teams ) {
				$teamsel = select( $teams, $user['user_team'] );
				array_unshift( $teamsel, array( 'value' => 0, 'name' => '&mdash;' ) );
			} else $teamsel = false;

		    $core->mainline->add ( $core->lang['company'], $core->url('m', 'comp') );
		    $core->mainline->add ( $core->lang['personel'], $core->url('m', 'personel') );
			$core->mainline->add ( $user['user_name'] );
			$core->header ();

			$field 	= array(
				array( 'type' => 'text', 'length' => 100, 'name' => 'name', 'head' => $core->lang['user_name'], 'descr' => $core->lang['user_name_d'], 'value' => $user['user_name']),
				array( 'type' => 'checkbox', 'name' => 'ban', 'head' => $core->lang['user_ban'], 'descr' => $core->lang['user_ban_d'], 'checked' => $user['user_ban'] ),
				array( 'type' => 'text', 'length' => 100, 'name' => 'email', 'head' => $core->lang['user_email'], 'descr' => $core->lang['user_email_d'], 'value' => $user['user_mail']),
				array( 'type' => 'pass', 'length' => 32, 'name' => 'pass', 'head' => $core->lang['user_pass'], 'descr' => $core->lang['user_pass_d'] ),
				array( 'type' => 'checkbox', 'name' => 'compad', 'head' => $core->lang['user_compad'], 'descr' => $core->lang['user_compad_d'], 'checked' => $user['user_compad'] ),
			);
		    if ( $teamsel ) {		    	$field[] = array( 'type' => 'select', 'name' => 'team', 'head' => $core->lang['user_team'], 'descr' => $core->lang['user_team_d'], 'value' => $teamsel );
				$field[] = array( 'type' => 'checkbox', 'name' => 'teamlead', 'head' => $core->lang['user_teamlead'], 'descr' => $core->lang['user_teamlead_d'], 'checked' => $user['user_teamlead'] );
			}
			$button = array(array('type' => 'submit', 'value' => $core->lang['save']));
			$core->form ('useredit', $core->url ( 'a', 'comp-user-edit', $id ), 'post', $core->lang['user_edit'], $field, $button);

			$core->footer ();

		} else {

			$mans = $core->db->data( "SELECT * FROM ".DB_USER." WHERE user_comp = '$ci' ORDER BY user_name ASC" );
			$teams = $core->wmsale->get( 'teams', $ci );

		    $core->mainline->add ( $core->lang['company'], $core->url('m', 'comp') );
		    $core->mainline->add ( $core->lang['personel'] );
		    $core->header ();

			$core->tpl->load( 'body', 'list', defined('HACK_TPL_LIST') ? HACK : false );

			$core->tpl->vars( 'body', array(
				'title'			=> $core->lang['company_personel_h'],
				'text'			=> $core->text->lines( $core->lang['company_personel_t'] ),
				'name'			=> $core->lang['name'],
				'info'			=> $core->lang['access'],
				'action'		=> $core->lang['action'],
				'level'			=> $core->lang['level'],
				'edit'			=> $core->lang['edit'],
				'del'			=> $core->lang['del'],
				'confirm'		=> $core->lang['confirm'],
			));

		    foreach ( $mans as &$i ) {

				if ( $i['user_ban'] ) {
					$level = '<b class="warn red">'.$core->lang['ban'].'</b>';
				} elseif ( $i['user_team'] ) {					$tg = $i['user_teamlead'] ? 'b' : 'span';
					$tc = $i['user_compad'] ? 'boss' : 'teams';
					$level = '<'.$tg.' class="'.$tc.'">'.$teams[$i['user_team']].'</'.$tg.'>';
				} elseif ( $i['user_compad'] ) {					$level = '<b class="boss">'.$core->lang['admin'].'</b>';
				} else $level = $core->lang['user_works'][1];

		        $core->tpl->block ( 'body', 'item', array (
		        	'id'		=> $i['user_id'],
		            'name'		=> $i['user_name'],
		            'more' 		=> '<a href="mailto:'.$i['user_mail'].'" class="small grey">'.$i['user_mail'].'</a>',
		            'info'		=> $level,
		            'url'		=> $core->url ( 'i', 'personel', $i['user_id'] ),
		            'edit'		=> $core->url ( 'i', 'personel', $i['user_id'] ),
		            'del'		=> $core->url ( 'a', 'comp-user-del', $i['user_id'] ),
		        ));

		    } unset ( $i, $mans );

			$core->tpl->output( 'body' );

			if ( $teams ) {
				$teamsel = select( $teams );
				array_unshift( $teamsel, array( 'value' => 0, 'name' => '&mdash;' ) );
			} else $teamsel = false;

		    $title	= $core->lang['comp_user_add'];
		    $action	= $core->url ( 'a', 'comp-user-add', '' );
		    $field 	= array(
	            array('type' => 'text', 'length' => 100, 'name' => 'name', 'head' => $core->lang['user_name'], 'descr' => $core->lang['user_name_d'] ),
	            array('type' => 'text', 'length' => 100, 'name' => 'email', 'head' => $core->lang['user_email'], 'descr' => $core->lang['user_email_d'] ),
	            array('type' => 'pass', 'length' => 32, 'name' => 'pass', 'head' => $core->lang['user_pass'], 'descr' => $core->lang['user_pass_d'] ),
		    );
		    if ( $teamsel ) $field[] = array( 'type' => 'select', 'name' => 'team', 'head' => $core->lang['user_team'], 'descr' => $core->lang['user_team_d'], 'value' => $teamsel );
		    $button = array(array('type' => 'submit', 'value' => $core->lang['create']));
		    $core->form ( 'useradd', $action, 'post', $title, $field, $button );

			$core->footer ();

		}

	  	$core->_die();

	}

	return false;

}