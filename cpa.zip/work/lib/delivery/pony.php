<?php

/*******************************************************************************

 *
 * 	AlterVision Core Framework - CPA platform
 * 	Created by AlterVision - altervision.me
 *  Copyright © 2005-2015 Anton Reznichenko
 *

 *
 *  File: 			lib / delivery / pony.php
 *  Description:	Russian Post Delivery
 *  Author:			Anton 'AlterVision' Reznichenko - altervision13@gmail.com
 *

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 2 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.

*******************************************************************************/

class pony_delivery {
	private $core;
	private $id = 3; // Delivery ID

	private $client = false;
	private $error	= false;

	public function __construct ( $core ) {		$this->core = $core;
	}

	// Checking the order stage of delivery
	public function stage ( $id ) {
		$core = $this->core;
		$t = $core->db->row( "SELECT * FROM ".DB_ORDER." WHERE order_id = '$id' LIMIT 1" );
		if ( !$t['order_id'] ) return false;
		$c = $core->wmsale->get( 'comp', $id, 'pony_key' );
		if ( ! $c ) $c = PONY_KEY;

		if ( $t['order_status'] < 8 || $t['order_status'] > 9 ) {			if ( $t['track_on'] ) $core->db->query( "UPDATE ".DB_ORDER." SET track_on = 0 WHERE order_id = '$id' LIMIT 1" );
			return false;
		}

		if ( $info = $this->check( $t['track_code'], $c ) ) {

			if ( $t['order_status'] == 8 ) {				if ( $info[2] == 'Arrived' ) order_edit( $core, $id, array( 'status' => 9 ) );
				if ( $info[2] == 'OnLastMile' ) order_edit( $core, $id, array( 'status' => 9 ) );
			}

			if ( $info[2] == 'Delivered' ) order_edit( $core, $id, array( 'status' => 10 ) );
			if ( $info[2] == 'Returned' ) order_edit( $core, $id, array( 'status' => 11 ) );

			return array( $info[0], $info[1] );

		} else return true;

	}

	// Checking order delivery history
	public function history ( $id ) {
		$core = $this->core;
		$t = $core->db->row( "SELECT comp_id, track_code FROM ".DB_ORDER." WHERE order_id = '$id' LIMIT 1" );
		$c = $core->wmsale->get( 'comp', $id, 'pony_key' );
		if ( ! $c ) $c = PONY_KEY;

		return $this->info( $t['track_code'], $c );

	}

	// Calculate delivery time and price
	public function calc ( $data ) {

		return $d ? array( 'status' => 'ok', 'dd' => $d, 'cost' => $c ) : array( 'status' => 'error', 'error' => 'nodelivery' );

	}

	// Periodical processing
	public function cron () {


	}

	//
	// Low-level functions
	//

	private function request ( $code, $type, $body ) {
		if ( ! $this->client ) $this->client = new SoapClient( 'https://svc-api.p2e.ru/UI_Service.svc?singleWsdl', array( 'cache_wsdl' => 0, 'trace' => 1, 'exceptions' => 0 ) );

		$qu = new StdClass();
		$qu->accesskey = $code;
		$qu->requestBody = '<?xml version="1.0" encoding="utf-8"?><Request xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xsi:type="'.$type.'">'.$body.'</Request>';

		try {
			$request = $this->client->SubmitRequest( $qu );
			$result = simplexml_load_string( $request->SubmitRequestResult );
		} catch ( SOAPFault $f ) {
			$this->error = $f;
			return false;
		}

		return $result;

	}

	public function info ( $track, $code ) {
		$re = $this->request( $code, 'OrderRequest',
		'<Id>1</Id><Mode>Status</Mode><OrderList><Order>
			<ServiceList><Service xsi:type="DeliveryService">
				<Waybill><Number>'.$track.'</Number></Waybill>
			</Service></ServiceList>
		</Order></OrderList>' );

		if ( $re && isset( $re->OrderList->Order->StatusList->OrderStatus ) ) {
			$result = array();
			foreach ( $re->OrderList->Order->StatusList->OrderStatus as $s ) {				$result[] = array(
             		'date' => date( 'd.m.Y H:i', strtotime( $s->Date ) ),
             		'city' => (string) $s->City,
             		'pro' => (string) $s->Code,
             		'state' => (string) $s->Description,
             		'status' => sprintf( '%s - %s', $s->Code, $s->Description ),
				);
			}
			return $result;
		} else return false;

	}

	public function check ( $track, $code ) {

		$info = $this->info( $track, $code );
		if ( $info ) {
			$position = end( $info );
			return array( $position['date'], $position['status'], $position['pro'] );
		} else return false;

	}

}