<?php

/*******************************************************************************

 *
 * 	AlterVision Core Framework - CPA platform
 * 	Created by AlterVision - altervision.me
 *  Copyright © 2005-2015 Anton Reznichenko
 *

 *
 *  File: 			lib / delivery / rupost.php
 *  Description:	Russian Post Delivery
 *  Author:			Anton 'AlterVision' Reznichenko - altervision13@gmail.com
 *

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 2 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.

*******************************************************************************/

class rupost_delivery {
	private $core;
	private $id = 1; // Delivery ID

	public function __construct ( $core ) {		$this->core = $core;
	}

	// Checking the order stage of delivery
	public function stage ( $id ) {
		$core = $this->core;
		$t = $core->db->row( "SELECT * FROM ".DB_ORDER." WHERE order_id = '$id' LIMIT 1" );
		if ( !$t['order_id'] ) return false;
		if ( $t['order_status'] < 8 || $t['order_status'] > 9 ) {			if ( $t['track_on'] ) $core->db->query( "UPDATE ".DB_ORDER." SET track_on = 0 WHERE order_id = '$id' LIMIT 1" );
			return false;
		}

		if ( $info = $this->info( $t['track_code'] ) ) {

			foreach ( $info as $i ) {
	           	if ( $i['pro'] == 'Возврат' ) {
	           		order_edit( $core, $t['order_id'], array( 'status' => 11 ), $t );
					return false;
				}
			}

			$now = end( $info );
			$status = sprintf( '%s - %s (%s, %s)', $now['pro'], $now['state'], $now['index'], $now['city'] );
			$date = $now['date'];

			if ( $todo && $status ) {
				if ( $now['pro'] == 'Вручение' ) {
	               	order_edit( $core, $t['order_id'], array( 'status' => 10 ) );
				} elseif ( $t['order_status'] == 8 ) {
					$check = array( 'вручени', 'заберет отправление сам', 'временное отсутствие адресата' );
					foreach ( $check as $c ) if ( mb_stripos( $status, $c, 0, 'utf-8' ) !== false ) order_edit( $core, $t['order_id'], array( 'status' => 9 ) );
				}
			}

			return array( $date, $status );

		} else return true;

	}

	// Checking order delivery history
	public function history ( $id ) {
		$core = $this->core;
		$t = $core->db->field( "SELECT track_code FROM ".DB_ORDER." WHERE order_id = '$id' LIMIT 1" );
		return $t ? $this->info( $t ) : false;

	}

	// Calculate delivery time and price
	public function calc ( $data ) {
		$to		= $data['index'];
		$price 	= $data['price'];

		$req = $reqmd5 = array( 'apikey' => RUP_API, 'method' => 'calc', 'from_index' => RUP_FROM, 'to_index' => $to, 'weight' => RUP_WG, 'ob_cennost_rub' => $price );
		$reqmd5[] = RUP_KEY;
		$req['hash'] = md5(implode( '|', $reqmd5 ));
		$info = json_decode( curl( 'http://russianpostcalc.ru/api_v1.php', $req ), true );
		if ( $info['calc'] ) {
			$d = 0; $c = 0;
			foreach ( $info['calc'] as $i ) {
		    	if ( $i['type'] == 'rp_1class' ) {
					$d = $i['days'];
					$c = $i['cost'];
		         	break;
		    	}
			}
			return $d ? array( 'status' => 'ok', 'id' => $this->id, 'dd' => $d, 'cost' => $c ) : array( 'status' => 'error', 'error' => 'nodelivery' );
		} else return array( 'status' => 'error' );

	}

	// Periodical processing
	public function cron () {
		$ct = time() + 1800;
		$core = $this->core;

		$totrack = $core->db->data( "SELECT order_id, track_code FROM ".DB_ORDER." WHERE order_delivery = 1 AND track_on = 0 AND order_status = 8" );
		if ( count( $totrack ) ) {
			foreach ( $totrack as &$t ) {
				$this->check( $t['track_code'] );
				$core->db->query( "UPDATE ".DB_ORDER." SET track_on = 1, track_check = '$ct', track_start = '$ct' WHERE order_id = '".$t['order_id']."' LIMIT 1" );
			} unset ( $t, $totrack, $pt );
		}

	}

	//
	// Low-level functions
	//

	private function request ( $url, $post ) {
		$post['apikey'] = RUP_API;
		$reqmd5 = $post;
		$reqmd5[] = RUP_KEY;
		$post['hash'] = md5(implode( '|', $reqmd5 ));

		$curl = curl_init( $url );
		curl_setopt( $curl, CURLOPT_RETURNTRANSFER, 1 );
		curl_setopt( $curl, CURLOPT_POST, 1 );
		curl_setopt( $curl, CURLOPT_POSTFIELDS, $post );

		$result = curl_exec( $curl );
		curl_close( $curl );
		return $result ? json_decode( $result, true ) : false;

	}

	public function check ( $code ) {
		$info = $this->request( 'http://russianpostcalc.ru/api_v1.php', array( 'method' => 'parcel', 'rpo' => $code ) );
		if ( $info['status0'] ) {			$date = $info['date'];
			$status = sprintf( '%s - %s (%s, %s)', $info['status1'], $info['status0'], $info['index'], $info['place'] );
		} else $date = $status = false;
		return array( $date, $status );

	}

	public function info ( $code ) {
		$info = $this->request( 'http://russianpostcalc.ru/api_v1.php', array( 'method' => 'parcel', 'rpo' => $code ) );
		$data = array();

		if ( $info['status0'] ) {
			$log = json_decode( $info['log_json'], true );
			foreach ( $log as $l ) {             	$data[] = array(
             		'date' => $l['date'],
             		'city' => $l['place'],
             		'index' => $l['index'],
             		'pro' => $l['status1'],
             		'state' => $l['status0'],
             		'status' => sprintf( '%s - %s (%s)', $l['status1'], $l['status0'], $l['index'] ),
             	);
			}
		}

		return $data;

	}

}