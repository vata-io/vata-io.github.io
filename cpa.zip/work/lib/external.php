<?php

/*******************************************************************************

 *
 * 	AlterVision Core Framework - CPA platform
 * 	Created by AlterVision - altervision.me
 *  Copyright � 2014-2015 Anton Reznichenko
 *

 *
 *  File: 			lib / external.php
 *  Description:	External agancy statistics
 *  Author:			Anton 'AlterVision' Reznichenko - altervision13@gmail.com
 *

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 2 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.

*******************************************************************************/

function external_menu ( $core, $menu ) {

	$menu[] = 'lead';
	$menu['stats'] = array( 'stats', 'offerstat' );
	$menu[] = 'offers';
	return $menu;

}

function external_module ( $core ) {
	$module	= ( $core->get['m'] ) ? $core->get['m'] : null;
	$id		= ( $core->post['id'] ) ? (int) $core->post['id'] : ( ($core->get['id']) ? (int) $core->get['id'] : 0 );
	$page	= ( $core->get['page'] > 0 ) ? (int) $core->get['page'] : 1;
	$message = ( $core->get['message'] ) ? $core->get['message'] : null;

	if ( $module == 'stats' ) return external_stats( $core );
	if ( $module == 'offerstat' ) return external_offerstat( $core );
	if ( $module == 'offers' ) {		require_once PATH_LIB . 'offers.php';
		offers ( $core );
	}

  	$where = array( "ext_id = '".$core->user->ext."'" );

	if ( isset( $core->get['d'] ) && $core->get['d'] ) {
		$d = date2form(form2date( $core->get['d'] ));
		$ds = strtotime( $d . ' 00:00:00' );
		$de = strtotime( $d . ' 23:59:59' );
		$where[] = " order_time BETWEEN '$ds' AND '$de' ";
	} else $d = false;

	if ( isset( $core->get['o'] ) && $core->get['o'] ) {
		$o = (int) $core->get['o'];
		$where[] = " offer_id = '$o' ";
	} else $o = false;

	if ( isset( $core->get['w'] ) && $core->get['w'] ) {
		$w = (int) $core->get['w'];
		$where[] = " site_id = '$w' ";
	} else $w = false;

	if ( isset( $core->get['s'] ) && $s = $core->get['s'] ) {
		switch ( $s ) {			case 'w':	$where[] = " order_webstat < 5 "; break;
			case 'c':	$where[] = " order_webstat IN ( 5, 12 ) "; break;
			case 'a':	$where[] = " order_webstat BETWEEN 6 AND 11 "; break;
			default:	$s = false;
		}
	} else $s = false;

	$where = implode( ' AND ', $where );
	$sh = 30; $st = ( $page - 1 ) * $sh;
	$orders = $core->db->field( "SELECT COUNT(*) FROM ".DB_ORDER." WHERE $where " );
	$order = $orders ? $core->db->data( "SELECT * FROM ".DB_ORDER." WHERE $where ORDER BY order_id DESC LIMIT $st, $sh" ) : array();

	$offer = $core->wmsale->get( 'offers' );
	$site = $core->wmsale->get( 'lands' );

	$core->mainline->add( $core->lang['stats_lead'] );
	$core->header();

	$core->tpl->load( 'body', 'external', defined('HACK_TPL_EXTERNAL') ? HACK : false );

	$core->tpl->vars( 'body', array(
		'nostats'		=> $core->lang['nostats'],
		'date'			=> $core->lang['date'],
		'flow'			=> $core->lang['flow'],
		'offer'			=> $core->lang['offer'],
		'status'		=> $core->lang['status'],
		'show'			=> $core->lang['show'],
		'site'			=> $core->lang['site'],
		'calls'			=> $core->lang['order_calls_sh'],
		'reason'		=> $core->lang['order_reason'],
		'd'				=> $d,
		'u_stat'		=> $core->url( 'm', 'lead' ),
		'stat'			=> $core->lang['stats_date'],
		'pages'			=> pages ( $core->url( 'm', '?' ) . ( $f ? 'f='.$f.'&' : '' ) . ( $d ? 'd='.$d.'&' : '' ) . ( $s ? 's='.$s.'&' : '' ) . ( $o ? 'o='.$o : '' ) . ( $w ? 'w='.$w : '' ), $orders, $sh, $page ),
		'shown'			=> sprintf( $core->lang['shown'], $st+1, min( $st+$sh, $orders ), $orders ),
	));

	foreach ( $offer as $of => $n ) {
		$core->tpl->block( 'body', 'offer', array( 'name' => $n, 'value' => $of, 'select' => ($of==$o) ? 'selected="selected"' : '' ) );
	}

	foreach ( $site as $sl => $n ) {
		$core->tpl->block( 'body', 'site', array( 'name' => $n, 'value' => $sl, 'select' => ($sl==$w) ? 'selected="selected"' : '' ) );
	}

	foreach ( $core->lang['stat_status'] as $st => $n ) {
		$core->tpl->block( 'body', 'status', array( 'name' => $n, 'value' => $st, 'select' => ($st==$s) ? 'selected="selected"' : '' ) );
	}

	if ( $orders ) foreach ( $order as $r ) {

		if ( $r['order_webstat'] == 5 ) {
			if ( $r['order_reason'] ) {
				$reason = $core->lang['reasono'][$r['order_reason']];
			} else $reason = $r['order_comment'] ? sprintf( $core->lang['noreason_comment'], $r['order_comment'] ) :  $core->lang['noreason'];
		} elseif ( $r['order_webstat'] == 12 ) {
			$reason = $core->lang['noreasonfraud'];
		} elseif ( $r['order_check'] ) {
			$reason = $core->lang['stat_check'];
		} else $reason = false;
		$core->tpl->block( 'body', 'order', array(
			'id'			=> $r['order_id'],
			'offer'			=> $offer[$r['offer_id']],
			'site'			=> $site[$r['site_id']],
			'uid'			=> (strlen($r['ext_uid'])>25) ? sprintf( '<input type="text" value="%s" class="intable-view" />', htmlspecialchars($r['ext_uid']) ) : $r['ext_uid'],
			'src'			=> $r['ext_src'],
			'ip'			=> int2ip( $r['order_ip'] ),
			'country'		=> $r['order_country'],
			'time'			=> smartdate( $r['order_time'] ),
			'stid'			=> ( $r['order_webstat'] < 6 || $r['order_webstat'] == 12 ) ? $r['order_webstat'] : 10,
			'status'		=> ( $r['order_webstat'] < 6 || $r['order_webstat'] == 12 ) ? $core->lang['statuso'][$r['order_webstat']] : $core->lang['statusok'],
			'edit'			=> $core->url ( 'i', 'order', $r['order_id'] ),
			'calls'			=> $r['order_calls'],
			'reason'		=> $reason,
		));

	} else $core->tpl->block( 'body', 'nostat' );

	$core->tpl->output( 'body' );

	$core->footer();
  	$core->_die();


}

function external_stats ( $core ) {
	$today = date( 'Ymd' );
	$week1 = date( 'Ymd', strtotime( '-1 week' ) );
	$yest = strtotime( '-1 day' );
	$ext = $core->user->ext;

	extract(params( $core, array( 'to' => 'date', 'from' => 'date' ) ));
	if ( ! $to || $to > $today ) $to = $today;
	if ( $from > $to ) $from = $to;
	if ( ! $from ) $from = $week1;

	// Offer ID
	$o = isset( $core->get['o'] ) ? (int) $core->get['o'] : 0;
	$where1 = $where2 = $o ? " AND offer_id = '$o' " : '';

	// Website ID
	$w = isset( $core->get['w'] ) ? (int) $core->get['w'] : 0;
	if ( $w ) {		$where0 .= " AND site_sib = '$w'";
		$where1 .= " AND site_id = '$w'";
		$where2 .= " AND site_id = '$w'";
	}
	// Spacing ID
	$s = isset( $core->get['s'] ) ? (int) $core->get['s'] : 0;
	if ( $s ) {
		$where0 .= " AND site_id = '$s'";
		$where1 .= " AND site_sib = '$s'";
		$where2 .= " AND space_id = '$s'";
	}

	// Counting spacing clicks
	$spaces = $core->db->icol( "SELECT click_date, COUNT(*) FROM ".DB_CLICK." WHERE ( click_date BETWEEN '$from' AND '$to' ) $where0 AND ext_id = '$ext' AND click_space = 1 GROUP BY click_date" );
	$suni = $core->db->icol( "SELECT click_date, COUNT(*) FROM ".DB_CLICK." WHERE ( click_date BETWEEN '$from' AND '$to' ) $where0 AND ext_id = '$ext' AND click_space = 1 AND click_unique = 1 GROUP BY click_date" );
	$sgood = $core->db->icol( "SELECT click_date, COUNT(*) FROM ".DB_CLICK." WHERE ( click_date BETWEEN '$from' AND '$to' ) $where0 AND ext_id = '$ext' AND click_space = 1 AND click_good >= ".GOODCLICK." GROUP BY click_date" );
	$stm = $core->db->icol( "SELECT click_date, AVG(click_good) FROM ".DB_CLICK." WHERE ( click_date BETWEEN '$from' AND '$to' ) $where0 AND ext_id = '$ext' AND click_space = 1 GROUP BY click_date" );

	// Counting landing clicks
	$clicks = $core->db->icol( "SELECT click_date, COUNT(*) FROM ".DB_CLICK." WHERE ( click_date BETWEEN '$from' AND '$to' ) $where1 AND ext_id = '$ext' AND click_space = 0 GROUP BY click_date" );
	$unique = $core->db->icol( "SELECT click_date, COUNT(*) FROM ".DB_CLICK." WHERE ( click_date BETWEEN '$from' AND '$to' ) $where1 AND ext_id = '$ext' AND click_space = 0 AND click_unique = 1 GROUP BY click_date" );
	$good = $core->db->icol( "SELECT click_date, COUNT(*) FROM ".DB_CLICK." WHERE ( click_date BETWEEN '$from' AND '$to' ) $where1 AND ext_id = '$ext' AND click_space = 0 AND click_good >= ".GOODCLICK." GROUP BY click_date" );
	$tm = $core->db->icol( "SELECT click_date, AVG(click_good) FROM ".DB_CLICK." WHERE ( click_date BETWEEN '$from' AND '$to' ) $where1 AND ext_id = '$ext' AND click_space = 0 GROUP BY click_date" );

	// Processing
	$stats = array();
	$ids = array_unique(array_merge( array_keys( $spaces ), array_keys( $clicks ) ));
	foreach ( $ids as $i ) {
		$stats[$i] = array(
			'spaces' => $spaces[$i], 'suni'  => $suni[$i], 'sgood'  => $sgood[$i], 'stime'  => $stm[$i],
			'clicks' => $clicks[$i], 'unique'  => $unique[$i], 'good'  => $good[$i], 'time'  => $tm[$i]
		);
	}

	$ff = strtotime( date2form( $from ) . ' 00:00:00' );
	$tt = strtotime( date2form( $to ) . ' 23:59:59' );

	$orders = $core->db->start( "SELECT order_webstat, order_reason, order_time, offer_id, cash_wm FROM ".DB_ORDER." WHERE ext_id = '$ext' $where2 AND order_time BETWEEN '$ff' AND '$tt'" );
	while ( $oo = $core->db->one( $orders ) ) {

		if ( $oo['order_webstat'] < 5 ) {
			$l = 'w';
		} elseif ( $oo['order_webstat'] > 5 && $oo['order_webstat'] < 11 ) {
			$l = 'a';
		} elseif ( $oo['order_webstat'] == 12 || $oo['order_reason'] == 5 || $oo['order_reason'] == 6 || $oo['order_reason'] == 7 ) {
			$l = 'x';
		} else $l = 'c';
		$d = date( 'Ymd', $oo['order_time'] );

		if ( $stats[$d]['c'.$l] ) $stats[$d]['c'.$l] += 1; else $stats[$d]['c'.$l] = 1;
		if ( $stats[$d]['m'.$l] ) $stats[$d]['m'.$l] += $oo['cash_wm']; else $stats[$d]['m'.$l] = $oo['cash_wm'];
		if ( $l != 'x' ) {
			if ( $stats[$d]['ct'] ) $stats[$d]['ct'] += 1; else $stats[$d]['ct'] = 1;
			if ( $stats[$d]['mt'] ) $stats[$d]['mt'] += $oo['cash_wm']; else $stats[$d]['mt'] = $oo['cash_wm'];
		}

	} $core->db->stop( $orders );

	krsort( $stats );
	$csv = ( $core->get['show'] == 'csv' ) ? 1 : 0;

	$core->mainline->add( $core->lang['stats_h'] );
	if ( $csv ) {
		header('Content-type: text/csv');
		header('Content-disposition: attachment;filename=stats.csv');
	} else $core->header();

	if ( $csv ) {
		$core->tpl->load( 'body', 'csv-stats' );
	} else $core->tpl->load( 'body', 'stats', defined('HACK_TPL_STATS') ? HACK : false );

	$core->tpl->vars( 'body', array(
		'nostats'		=> $core->lang['nostats'],
		'date'			=> $core->lang['date'],
		'wait'			=> $core->lang['stat_wait'],
		'accept'		=> $core->lang['stat_accept'],
		'cancel'		=> $core->lang['stat_cancel'],
		'spaces'		=> $core->lang['stat_spaces'],
		'clicks'		=> $core->lang['stat_clicks'],
		'unique'		=> $core->lang['stat_unique'],
		'offer'			=> $core->lang['offer'],
		'show'			=> $core->lang['show'],
		'from'			=> date2form( $from ),
		'to'			=> date2form( $to ),
		'u_csv'			=> $core->url( 'm', 'stats?show=csv&from=' ) . date2form( $from ) . '&to=' . date2form( $to ) . ( $o ? '&o='.$o : '' ),
		'u_today'		=> $core->url( 'm', 'stats?from=' ) . date( 'Y-m-d' ) . '&to=' . date( 'Y-m-d' ) . ( $o ? '&o='.$o : '' ),
		'u_yesterday'	=> $core->url( 'm', 'stats?from=' ) . date( 'Y-m-d', $yest ) . '&to=' . date( 'Y-m-d', $yest ) . ( $o ? '&o='.$o : '' ),
	));

	$offer = $core->wmsale->get( 'offers' );
	foreach ( $offer as $of => $n ) $core->tpl->block( 'body', 'offer', array( 'name' => $n, 'value' => $of, 'select' => ($of==$o) ? 'selected="selected"' : '' ) );

	$sc = count( $stats );
	$t = array( 'spaces' => 0, 'suni' => 0, 'sgood' => 0, 'stime' => 0, 'clicks' => 0, 'unique' => 0, 'good' => 0, 'time' => 0, 'ca' => 0, 'cw' => 0, 'cc' => 0, 'ct' => 0, 'cx' => 0, 'ma' => 0, 'mw' => 0, 'mc' => 0, 'mt' => 0 );
	$tk = array_keys( $t );
	if ( $stats ) {
		foreach ( $stats as $d => &$s ) {
			$cl = max( $s['suni'], $s['unique'] );
			foreach ( $tk as $k ) if ( $s[$k] ) $t[$k] += $s[$k];
			$core->tpl->block( 'body', 'stat', array(
            	'date'		=> date2form( $d ),
				'cr'		=> $cl ? sprintf( "%0.2f", ( $s['ca'] / $cl ) * 100 ) : 0,
				'epc'		=> $cl ? rur ( $s['ma'] / $cl ) : '-',
				'epcr'		=> $cl ? sprintf ( "%0.2f", $s['ma'] / $cl ) : '-',
				'app'		=> $s['ct'] ? sprintf( '%d', $s['ca'] * 100 / $s['ct'] ) : 0,
                'spaces'	=> (int) $s['spaces'],
                'suni'		=> (int) $s['suni'],
                'sbad'		=> sprintf( '%d', $s['spaces'] ? ( ( $s['spaces'] - $s['sgood'] ) / $s['spaces'] * 100 ) : 0  ),
				'stime'		=> sprintf( '%d', $s['stime'] * 5 ),
           	    'per'		=> $s['suni'] ? sprintf( '%d', $s['unique'] / $s['suni'] * 100 ) : 0,
                'clicks'	=> (int) $s['clicks'],
                'unique'	=> (int) $s['unique'],
                'bad'		=> sprintf( '%d', $s['clicks'] ? ( ( $s['clicks'] - $s['good'] ) / $s['clicks'] * 100 ) : 0  ),
				'time'		=> sprintf( '%d', $s['time'] * 5 ),
				'ua'		=> $core->url( 'm', 'lead' ) . '?from=' . date2form( $d ) . '&to=' . date2form( $d ) . '&s=a',
				'uw'		=> $core->url( 'm', 'lead' ) . '?from=' . date2form( $d ) . '&to=' . date2form( $d ) . '&s=w',
				'uc'		=> $core->url( 'm', 'lead' ) . '?from=' . date2form( $d ) . '&to=' . date2form( $d ) . '&s=c',
				'ut'		=> $core->url( 'm', 'lead' ) . '?from=' . date2form( $d ) . '&to=' . date2form( $d ),
                'ca'		=> (int) $s['ca'],
				'cw'		=> (int) $s['cw'],
                'cc'		=> (int) $s['cc'],
                'cx'		=> (int) $s['cx'],
                'ct'		=> (int) $s['ct'],
                'ma'		=> rur( $s['ma'] ),
                'mw'		=> rur( $s['mw'] ),
                'mc'		=> rur( $s['mc'] ),
                'mt'		=> rur( $s['mt'] ),
                'mar'		=> (int) $s['ma'],
                'mwr'		=> (int) $s['mw'],
                'mcr'		=> (int) $s['mc'],
                'mtr'		=> (int) $s['mt'],
			));
		} unset ( $d, $s, $stats );
	} else $core->tpl->block( 'body', 'nostat' );

	if ( $sc > 1 ) {
       	$cl = max( $t['suni'], $t['unique'] );
		$core->tpl->block( 'body', 'total', array(
			'cr'		=> $cl ? sprintf( "%0.2f", $t['ct'] / $cl * 100 ) : 0,
			'epc'		=> $cl ? rur ( $t['ma'] / $cl ) : '-',
			'app'		=> $t['ct'] ? sprintf( '%d', $t['ca'] * 100 / $t['ct'] ) : 0,
			'spaces'	=> (int) $t['spaces'],
			'suni'		=> (int) $t['suni'],
			'per'		=> $t['suni'] ? sprintf( '%d', $t['unique'] / $t['suni'] * 100 ) : 0,
			'sbad'		=> sprintf( '%d', $t['spaces'] ? ( ( $t['spaces'] - $t['sgood'] ) / $t['spaces'] * 100 ) : 0  ),
			'stime'		=> sprintf( '%d', $t['stime'] * 5 / $sc ),
			'clicks'	=> (int) $t['clicks'],
			'unique'	=> (int) $t['unique'],
			'bad'		=> sprintf( '%d', $t['clicks'] ? ( ( $t['clicks'] - $t['good'] ) / $t['clicks'] * 100 ) : 0  ),
			'time'		=> sprintf( '%d', $t['time'] * 5 / $sc ),
			'ca'		=> (int) $t['ca'],
			'cw'		=> (int) $t['cw'],
			'cc'		=> (int) $t['cc'],
			'cx'		=> (int) $t['cx'],
			'ct'		=> (int) $t['ct'],
			'ma'		=> rur( $t['ma'] ),
			'mw'		=> rur( $t['mw'] ),
			'mc'		=> rur( $t['mc'] ),
			'mt'		=> rur( $t['mt'] ),
		));
	}

	$core->tpl->output( 'body', $csv ? 'windows-1251' : false  );

	if ( ! $csv ) $core->footer();
	$core->_die();

}

function external_offerstat ( $core ) {
	$ext = $core->user->ext;
	$today = date( 'Ymd' );
	$week1 = date( 'Ymd', strtotime( '-2 week' ) );
	$yest = strtotime( '-1 day' );

	extract(params( $core, array( 'to' => 'date', 'from' => 'date' ) ));
	if ( ! $to || $to > $today ) $to = $today;
	if ( $from > $to ) $from = $to;
	if ( ! $from ) $from = $today;

	// Counting spacing clicks
	$spaces = $core->db->icol( "SELECT offer_id, COUNT(*) FROM ".DB_CLICK." WHERE ( click_date BETWEEN '$from' AND '$to' ) AND ext_id = '$ext' AND click_space = 1 GROUP BY offer_id" );
	$suni = $core->db->icol( "SELECT offer_id, COUNT(*) FROM ".DB_CLICK." WHERE ( click_date BETWEEN '$from' AND '$to' ) AND ext_id = '$ext' AND click_space = 1 AND click_unique = 1 GROUP BY offer_id" );
	$sgood = $core->db->icol( "SELECT offer_id, COUNT(*) FROM ".DB_CLICK." WHERE ( click_date BETWEEN '$from' AND '$to' ) AND ext_id = '$ext' AND click_space = 1 AND click_good >= ".GOODCLICK." GROUP BY offer_id" );
	$stm = $core->db->icol( "SELECT offer_id, AVG(click_good) FROM ".DB_CLICK." WHERE ( click_date BETWEEN '$from' AND '$to' ) AND ext_id = '$ext' AND click_space = 1 GROUP BY offer_id" );

	// Counting landing clicks
	$clicks = $core->db->icol( "SELECT offer_id, COUNT(*) FROM ".DB_CLICK." WHERE ( click_date BETWEEN '$from' AND '$to' ) AND ext_id = '$ext' AND click_space = 0 GROUP BY offer_id" );
	$unique = $core->db->icol( "SELECT offer_id, COUNT(*) FROM ".DB_CLICK." WHERE ( click_date BETWEEN '$from' AND '$to' ) AND ext_id = '$ext' AND click_space = 0 AND click_unique = 1 GROUP BY offer_id" );
	$good = $core->db->icol( "SELECT offer_id, COUNT(*) FROM ".DB_CLICK." WHERE ( click_date BETWEEN '$from' AND '$to' ) AND ext_id = '$ext' AND click_space = 0 AND click_good >= ".GOODCLICK." GROUP BY offer_id" );
	$tm = $core->db->icol( "SELECT offer_id, AVG(click_good) FROM ".DB_CLICK." WHERE ( click_date BETWEEN '$from' AND '$to' ) AND ext_id = '$ext' AND click_space = 0 GROUP BY offer_id" );

	// Processing
	$stats = array();
	$ids = array_unique(array_merge( array_keys( $spaces ), array_keys( $clicks ) ));
	foreach ( $ids as $i ) {
		$stats[$i] = array(
			'space' => $spaces[$i], 'suni'  => $suni[$i], 'sgood'  => $sgood[$i], 'stime'  => $stm[$i],
			'clicks' => $clicks[$i], 'unique'  => $unique[$i], 'good'  => $good[$i], 'time'  => $tm[$i]
		);
	}

	// Counting orders
	$ff = strtotime( date2form( $from ) . ' 00:00:00' );
	$tt = strtotime( date2form( $to ) . ' 23:59:59' );

	$orders = $core->db->start( "SELECT order_id, order_webstat, order_reason, offer_id, cash_wm FROM ".DB_ORDER." WHERE order_time BETWEEN '$ff' AND '$tt' AND ext_id = '$ext'" );
	while ( $oo = $core->db->one( $orders ) ) {

		if ( $oo['order_webstat'] < 5 ) {
			$l = 'w';
		} elseif ( $oo['order_webstat'] > 5 && $oo['order_webstat'] < 11 ) {
			$l = 'a';
		} elseif ( $oo['order_webstat'] == 12 || $oo['order_reason'] == 5 || $oo['order_reason'] == 6 || $oo['order_reason'] == 7 ) {
			$l = 'x';
		} else $l = 'c';

		if ( $stats[$oo['offer_id']]['c'.$l] ) $stats[$oo['offer_id']]['c'.$l] += 1; else $stats[$oo['offer_id']]['c'.$l] = 1;
		if ( $stats[$oo['offer_id']]['m'.$l] ) $stats[$oo['offer_id']]['m'.$l] += $oo['cash_wm']; else $stats[$oo['offer_id']]['m'.$l] = $oo['cash_wm'];
		if ( $l != 'x' ) {
			if ( $stats[$oo['offer_id']]['ct'] ) $stats[$oo['offer_id']]['ct'] += 1; else $stats[$oo['offer_id']]['ct'] = 1;
			if ( $stats[$oo['offer_id']]['mt'] ) $stats[$oo['offer_id']]['mt'] += $oo['cash_wm']; else $stats[$oo['offer_id']]['mt'] = $oo['cash_wm'];
		}

	} $core->db->stop( $orders );

	$core->mainline->add( $core->lang['stats_flow'] );
	$core->header();

	$core->tpl->load( 'body', 'offerstat', defined('HACK_TPL_FLOWSTAT') ? HACK : false );

	$core->tpl->vars( 'body', array(
		'nostats'		=> $core->lang['nostats'],
		'type'			=> $core->lang['type'],
		'today'			=> $core->lang['today'],
		'yesterday'		=> $core->lang['yesterday'],
		'target'		=> $core->lang['target'],
		'wait'			=> $core->lang['stat_wait'],
		'accept'		=> $core->lang['stat_accept'],
		'cancel'		=> $core->lang['stat_cancel'],
		'spaces'		=> $core->lang['stat_spaces'],
		'clicks'		=> $core->lang['stat_clicks'],
		'unique'		=> $core->lang['stat_unique'],
		'total'			=> $core->lang['total'],
		'flow'			=> $core->lang['flow'],
		'offer'			=> $core->lang['offer'],
		'show'			=> $core->lang['show'],
		'help'			=> $core->lang['help'],
		'helptext'		=> $core->lang['stat_help'],
		'confirm'		=> $core->lang['confirm'],
		'from'			=> date2form( $from ),
		'to'			=> date2form( $to ),
		'u_today'		=> $core->url( 'm', 'offerstat?from=' ) . date( 'Y-m-d' ) . '&to=' . date( 'Y-m-d' ),
		'u_yesterday'	=> $core->url( 'm', 'offerstat?from=' ) . date( 'Y-m-d', $yest ) . '&to=' . date( 'Y-m-d', $yest ),
	));

	if ( $stats ) {

		$t = array( 'space' => 0, 'suni' => 0, 'sgood' => 0, 'stime' => 0, 'clicks' => 0, 'unique' => 0, 'good' => 0, 'time' => 0, 'ca' => 0, 'cw' => 0, 'cc' => 0, 'ct' => 0, 'cx' => 0, 'ma' => 0, 'mw' => 0, 'mc' => 0, 'mt' => 0 );
		$tf = array_keys( $t );

		$offer = $core->wmsale->get( 'offers' );
		foreach ( $stats as $d => &$s ) {

			$tc = max( (int) $s['suni'], (int) $s['unique'] );
			foreach ( $tf as $ttf ) if ( $s[$ttf] ) $t[$ttf] += $s[$ttf];

			$core->tpl->block( 'body', 'stat', array(
				'offer'		=> $offer[$d],
				'cr'		=> $tc ? sprintf( "%0.2f", $s['ct'] / $tc * 100 ) : 0,
				'epc'		=> $tc ? rur ( $s['ma'] / $tc ) : '-',
				'app'		=> $s['ct'] ? sprintf( '%d', $s['ca'] * 100 / $s['ct'] ) : 0,
				'spaces'	=> (int) $s['space'],
				'suni'		=> (int) $s['suni'],
				'sbad'		=> sprintf( '%d', $s['space'] ? ( ( $s['space'] - $s['sgood'] ) / $s['space'] * 100 ) : 0  ),
				'stime'		=> sprintf( '%d', $s['stime'] * 5 ),
				'per'		=> $s['suni'] ? sprintf( '%d', $s['unique'] / $s['suni'] * 100 ) : 0,
				'clicks'	=> (int) $s['clicks'],
				'unique'	=> (int) $s['unique'],
				'bad'		=> sprintf( '%d', $s['clicks'] ? ( ( $s['clicks'] - $s['good'] ) / $s['clicks'] * 100 ) : 0  ),
				'time'		=> sprintf( '%d', $s['time'] * 5 ),
				'ca'		=> (int) $s['ca'],
				'cw'		=> (int) $s['cw'],
				'cc'		=> (int) $s['cc'],
				'ct'		=> (int) $s['ct'],
				'cx'		=> (int) $s['cx'],
				'ma'		=> rur( $s['ma'] ),
				'mw'		=> rur( $s['mw'] ),
				'mc'		=> rur( $s['mc'] ),
				'mt'		=> rur( $s['mt'] ),
			));

		} unset ( $d, $s );

		$sc = count( $stats );
		if ( $sc > 1 ) {
			$cl = max( $t['suni'], $t['unique'] );
			$core->tpl->block( 'body', 'total', array(
				'cr'		=> $cl ? sprintf( "%0.2f", $t['ct'] / $cl * 100 ) : 0,
				'epc'		=> $cl ? rur ( $t['ma'] / $cl ) : '-',
				'app'		=> $t['ct'] ? sprintf( '%d', $t['ca'] * 100 / $t['ct'] ) : 0,
				'spaces'	=> (int) $t['space'],
				'suni'		=> (int) $t['suni'],
				'sbad'		=> sprintf( '%d', $t['space'] ? ( ( $t['space'] - $t['sgood'] ) / $t['space'] * 100 ) : 0  ),
				'stime'		=> sprintf( '%d', $t['stime'] * 5 / $sc ),
				'per'		=> $t['suni'] ? sprintf( '%d', $t['unique'] / $t['suni'] * 100 ) : 0,
				'clicks'	=> (int) $t['clicks'],
				'unique'	=> (int) $t['unique'],
				'bad'		=> sprintf( '%d', $t['clicks'] ? ( ( $t['clicks'] - $t['good'] ) / $t['clicks'] * 100 ) : 0  ),
				'time'		=> sprintf( '%d', $t['time'] * 5 / $sc  ),
				'ca'		=> (int) $t['ca'],
				'cw'		=> (int) $t['cw'],
				'cc'		=> (int) $t['cc'],
				'ct'		=> (int) $t['ct'],
				'cx'		=> (int) $t['cx'],
				'ma'		=> rur( $t['ma'] ),
				'mw'		=> rur( $t['mw'] ),
				'mc'		=> rur( $t['mc'] ),
				'mt'		=> rur( $t['mt'] ),
			));
		}

	} else $core->tpl->block( 'body', 'nostat' );

	$core->tpl->output( 'body' );

	$core->footer();
	$core->_die();

}