<?php

/*******************************************************************************

 *
 * 	AlterVision Core Framework - CPA platform
 * 	Created by AlterVision - altervision.me
 *  Copyright � 2014-2017 Anton Reznichenko
 *

 *
 *  File: 			lib / offers.php
 *  Description:	Offers listing
 *  Author:			Anton 'AlterVision' Reznichenko - altervision13@gmail.com
 *

*******************************************************************************/

function offers ( $core ) {

	$id = ( $core->post['id'] ) ? (int) $core->post['id'] : ( ($core->get['id']) ? (int) $core->get['id'] : 0 );
  	if ( $id && $core->wmsale->get( 'offer', $id, 'offer_active' ) ) {
		offerone( $core, $id );
  	} else offerlist( $core );
	$core->_die();

}

function offerlist ( $core ) {

	$price = offerprice( $core );

	$cat = (int) $_GET['cat'];
	$csq = $cat ? " AND cat_id = '$cat' " : '';

	$ex = $_GET['ex'] ? 1 : 0;
	$esq = $ex ? " AND offer_excl = '1' " : '';

	$offers = $core->db->data( "SELECT * FROM ".DB_OFFER." WHERE offer_active = 1 $csq $esq ORDER BY offer_sort DESC, offer_name ASC" );
 	if ( $core->user->work == 0 || $core->user->work == 2 ) {
		$flows = $core->db->icol( "SELECT offer_id, COUNT(*) FROM ".DB_FLOW." WHERE user_id = '".$core->user->id."' GROUP BY offer_id" );
	} else $flows = false;

	$core->mainline->add( $core->lang['offers_h'], $core->url( 'm', 'offers' ) );
	if ( $cat ) $core->mainline->add( $core->lang['offer_cats'][$cat] );
	if ( $core->get['format'] != 'txt' ) $core->header();

	$core->tpl->load( 'body', 'offers', defined('HACK_TPL_OFFERS') ? HACK : false );
	if ( $core->get['format'] == 'txt' ) {
		$core->tpl->load( 'body', 'offers-txt' );
		header( 'Content-type: text/plain; charset=utf-8' );
	}

	$core->tpl->vars( 'body', array(

		'text'		=> $core->text->lines( $core->lang['offers_text'] ),
       	'nooffers'	=> $core->lang['offers_no'],
       	'name'		=> $core->lang['name'],
       	'price'		=> $core->lang['price'],
       	'gender'	=> $core->lang['gender'],
       	'wm'		=> $core->lang['offer_towm'],
       	'action'	=> $core->lang['action'],
       	'status'	=> $core->lang['status'],
       	'cats'		=> $core->lang['cat'],
       	'add'		=> $core->lang['offer_newflow'],
       	'confirm'	=> $core->lang['offer_confirm'],
       	'excl'		=> $core->lang['offer_excl'],
       	'isexcl'	=> $ex,
       	'u_excl'	=> $core->url( 'm', 'offers' ) . '?ex=1' . ( $cat ? '&cat='.$cat : '' )

	));

	$he = $ex ? true : false;
	if (count( $offers )) {
		foreach ( $offers as &$o ) {

			if ( $o['offer_excl'] ) $he = true;

			$core->tpl->block( 'body', 'offer', array(
				'u'			=> $core->url( 'i', 'offers', $o['offer_id'] ),
				'id'		=> $o['offer_id'],
				'logo'		=> sprintf( OFFER_LOGO, $o['offer_id'] ),
				'add'		=> ( $core->user->work == 0 || $core->user->work == 2 ) ? $core->url( 'a', 'flow-add', $o['offer_id'] ) : false,
				'name'		=> $o['offer_name'],
				'text'		=> $core->text->out( $o['offer_text'] ),
				'excl'		=> $o['offer_excl'],
				'u_cat'		=> $core->url( 'm', 'offers' ).'?cat='.$o['cat_id'],
				'cat'		=> $o['cat_id'],
				'catname'	=> $core->lang['offer_cats'][$o['cat_id']],
				'cr'		=> $o['offer_convert'],
				'epc'		=> rur( $o['offer_epc'] ),
				'my'		=> $flows[$o['offer_id']] ? true : false,
				'status'	=> $flows[$o['offer_id']] ? sprintf( $core->lang['offer_flows'], $flows[$o['offer_id']] ) : $core->lang['offer_noflow'],
				'stat_m'	=> sprintf( "%0.1f", $o['stat_m'] ),
				'stat_f'	=> sprintf( "%0.1f", $o['stat_f'] ),
			));

			foreach ( $price[$o['offer_id']] as $p ) {
				$p['dske'] = rur( $p['dsk'] * $o['offer_convert'] / 100 );
				$p['mobe'] = rur( $p['mob'] * $o['offer_convert'] / 100 );
				$core->tpl->block( 'body', 'offer.price', $p );
			}

		} unset ( $o, $offers );
	} else $core->tpl->block( 'body', 'nooffer' );

	$hc = $core->db->icol( "SELECT cat_id, COUNT(*) FROM ".DB_OFFER." WHERE offer_active = 1 GROUP BY cat_id" );
	if ( $he ) $core->tpl->block( 'body', 'exc' );
	foreach ( $core->lang['offer_cats'] as $c => $n ) if ( $hc[$c] ) {
		$core->tpl->block( 'body', 'cat', array(
			'id'		=> $c,
			'name'		=> $n,
			'url'		=> $core->url( 'm', 'offers' ) . '?cat='.$c,
			'isit'		=> $c == $cat,
		));
	}

	$core->tpl->output( 'body' );

	if ( $core->get['format'] != 'txt' ) $core->footer();

}

function offerone ( $core, $id ) {

	$offer = $core->wmsale->get( 'offer', $id );
	$sites = $core->wmsale->get( 'sites', $id );
	if ( $core->user->work == 0 || $core->user->work == 2 ) {
		$flows = $core->db->data( "SELECT * FROM ".DB_FLOW." WHERE user_id = '".$core->user->id."' AND offer_id = '$id'" );
		$fc = count( $flows );
	} else $flows = $fc = false;

	$core->mainline->add( $core->lang['offers_h'], $core->url( 'm', 'offers' ) );
	$core->mainline->add( $offer['offer_name'] );
	$core->header();

	$core->tpl->load( 'body', 'offer', defined('HACK_TPL_OFFER') ? HACK : false );

	$core->tpl->vars( 'body', $offer );
	$core->tpl->vars( 'body', array(

       	'url'		=> $core->lang['site'],
       	'price'		=> $core->lang['price'],
       	'wm'		=> $core->lang['offer_towm'],
       	'action'	=> $core->lang['action'],
       	'add'		=> $core->lang['offer_newflow'],
       	'confirm'	=> $core->lang['offer_confirm'],
		'logo'		=> sprintf( OFFER_LOGO, $offer['offer_id'] ),
		'u_add'		=> ( $core->user->work == 0 || $core->user->work == 2 ) ? $core->url( 'a', 'flow-add', $offer['offer_id'] ) : false,
		'text'		=> $offer['offer_text'] ? $core->text->out( $offer['offer_text'] ) : $core->lang['offer_notext'],

		'cr'		=> $offer['offer_convert'],
		'epc'		=> rur( $offer['offer_epc'] ),
		'stat_m'	=> sprintf( "%0.1f", $offer['stat_m'] ),
		'stat_f'	=> sprintf( "%0.1f", $offer['stat_f'] ),
		'status'	=> $fc ? sprintf( $core->lang['offer_flows'], $fc ) : $core->lang['offer_noflow'],
		'cat_name'	=> $core->lang['offer_cats'][$offer['cat_id']],

	));

	$price = offerprice( $core, $id );
	foreach ( $price as $p ) {
		$p['dske'] = rur( $p['dsk'] * $offer['offer_convert'] / 100);
		$p['mobe'] = rur( $p['mob'] * $offer['offer_convert'] / 100 );
		$core->tpl->block( 'body', 'price', $p );
	}

	$counts = array( 'site' => 0, 'space' => 0 );
	foreach ( $sites as $s ) {
		$type = $s['site_type'] ? 'space' : 'site';
		$counts[$type] += 1;
		$core->tpl->block( 'body', $type, array(
			'u'		=> $s['site_url'],
			'n'		=> $s['site_name'] ? $s['site_name'] : $s['site_url'],
			'cr'	=> $s['site_convert'],
			'epc'	=> rur( $s['site_epc'] ),
			'mb'	=> $s['site_mobile'],
			'mbt'	=> $core->lang['site_mobiles'][$s['site_mobile']],
		));
	} unset ( $s, $sites );
	foreach ( $counts as $c => $i ) if ( ! $i ) $core->tpl->block( 'body', 'no'.$c );

	if ( $core->user->work == 0 || $core->user->work == 2 ) {
        $core->tpl->block( 'body', 'wm' );
		if ( $fc ) {
			foreach ( $flows as $f ) {
				$core->tpl->block( 'body', 'wm.flow', array(
					'stats'	=> $core->url( 'm', 'stats' ) . '?f=' . $f['flow_id'],
					'name'	=> $f['flow_name'],
					'epc'	=> rur( $f['flow_epc'] ),
					'cr'	=> $f['flow_convert'],
					'total'	=> rur( $f['flow_total'] ),
				));
			} unset ( $f, $flows );
		} else $core->tpl->block( 'body', 'wm.noflow' );
	}

	$name = 'stats' . $id; $tm = time(); $tv = $tm - 1800;
	$os = $core->cache->offer->$name;
	if ( !$os || $os['valid'] < $tv ) {

/*			$os = array( 'valid' => $tm ); $tt = $tm - 2592000;
		$orders = $core->db->data( "SELECT order_time, order_webstat, order_reason, order_count FROM ".DB_ORDER." WHERE offer_id = '$id' AND order_time > '$tt'" );

		if ( count( $orders ) > 30 ) {

			$os['bt'] = array(); for ( $i = 0; $i < 24; $i++ ) $os['bt'][$i] = 0;
			$os['bd'] = array(); for ( $i = 0; $i < 7; $i++ ) $os['bd'][$i] = 0;
			$os['br'] = array(); foreach ( $core->lang['reasono'] as $i => $r ) $os['br'][$i] = 0;
			$os['bs'] = array( 'w' => 0, 'a' => 0, 't' => 0, 'c' => 0, 'cc' => 0, 'rc' => 0, 'na' => 0, 'nw' => 0, 'pr' => 0, 'to' => date( 'd.m.Y H:i:s'), 'from' => date( 'd.m.Y', $tt ) );

           	foreach ( $orders as $o ) {

           		if ( $o['order_webstat'] > 5 && $o['order_webstat'] < 12 ) {
            		$os['bt'][ (int) date( 'H', $o['order_time'] ) ] += 1;
            		$os['bd'][ (int) date( 'w', $o['order_time'] ) ] += 1;
            		$os['bs']['t'] += 1; $os['bs']['a'] += 1;
           		} elseif ( $o['order_webstat'] == 5 ) {
					$os['br'][$o['order_reason']] += 1;
					$os['bs']['cc'] += 1;
                       if ( $o['order_reason'] < 6 ) {
						$os['bs']['c'] += 1;
						$os['bs']['t'] += 1;
					}
           		} else {
                    	switch ( $o['order_webstat'] ) {
                    		case 1:	$os['bs']['t'] += 1; $os['bs']['w'] += 1; $os['bs']['nw'] += 1; break;
                    		case 2:	$os['bs']['t'] += 1; $os['bs']['w'] += 1; $os['bs']['pr'] += 1; break;
                    		case 3:	$os['bs']['t'] += 1; $os['bs']['w'] += 1; $os['bs']['rc'] += 1; break;
                    		case 4:	$os['bs']['t'] += 1; $os['bs']['w'] += 1; $os['bs']['na'] += 1; break;
                    	}
           		}

           	}

           	$q = $os['bd'][0]; unset( $os['bd'][0] ); $os['bd'][0] = $q;
            	$bdmx = $btmx = 1;
			foreach ( $os['bd'] as $b ) $bdmx = max( $bdmx, $b );
			foreach ( $os['bt'] as $b ) $btmx = max( $btmx, $b );

			$os['bs']['w']	= sprintf( "%0.1f", $os['bs']['w'] / $os['bs']['t'] * 100 );
			$os['bs']['a']	= sprintf( "%0.1f", $os['bs']['a'] / $os['bs']['t'] * 100 );
			$os['bs']['c']	= sprintf( "%0.1f", $os['bs']['c'] / $os['bs']['t'] * 100 );
			$os['bs']['nw']	= sprintf( "%0.1f", $os['bs']['nw'] / $os['bs']['t'] * 100 );
			$os['bs']['na']	= sprintf( "%0.1f", $os['bs']['na'] / $os['bs']['t'] * 100 );
			$os['bs']['pr']	= sprintf( "%0.1f", $os['bs']['pr'] / $os['bs']['t'] * 100 );
			$os['bs']['rc']	= sprintf( "%0.1f", $os['bs']['rc'] / $os['bs']['t'] * 100 );

			foreach ( $os['bt'] as $t => $c ) $os['bt'][$t] = ceil ( $c / $btmx * 100 );
			foreach ( $os['bd'] as $d => $c ) $os['bd'][$d] = ceil ( $c / $bdmx * 100 );
			foreach ( $os['br'] as $r => $c ) $os['br'][$r] = sprintf ( "%0.1f", $c / $os['bs']['cc'] * 100 );

		} else $os['valid'] = false;       */

		$os = array( 'valid' => $tm );
		$tt = $tm - 1296000;
		$orders = $core->db->data( "SELECT order_time, order_webstat, order_reason, order_count FROM ".DB_ORDER." WHERE offer_id = '$id' AND order_time > '$tt'" );

		if ( count( $orders ) > 10 ) {

			$os['bs'] = array( 'w' => 0, 'a' => 0, 't' => 0, 'c' => 0, 'u' => 0 );

           	foreach ( $orders as $o ) {

           		if ( $o['order_webstat'] > 5 && $o['order_webstat'] < 12 ) {
            		$os['bs']['t'] += 1; $os['bs']['a'] += 1;
					if ( $o['order_count'] > 1 ) $os['bs']['u'] += 1;
           		} elseif ( $o['order_webstat'] < 5 ) {
//	            		$os['bs']['t'] += 1; $os['bs']['w'] += 1;
				} elseif (!( $oo['order_webstat'] == 12 || $oo['order_reason'] == 5 || $oo['order_reason'] == 6 || $oo['order_reason'] == 7 )) {
            		$os['bs']['t'] += 1; $os['bs']['c'] += 1;
           		}

           	}

			$os['bs']['w']	= sprintf( "%0.1f", $os['bs']['w'] / $os['bs']['t'] * 100 );
			$os['bs']['a']	= sprintf( "%0.1f", $os['bs']['a'] / $os['bs']['t'] * 100 );
			$os['bs']['c']	= sprintf( "%0.1f", $os['bs']['c'] / $os['bs']['t'] * 100 );
			$os['bs']['u']	= $os['bs']['a'] ? sprintf( "%0.1f", $os['bs']['u'] / $os['bs']['a'] * 100 ) : 0;

		} else $os['valid'] = false;

		$core->cache->offer->$name = $os;

	}

	if ( $os['valid'] ) $core->tpl->block( 'body', 'stats', $os['bs'] );

	$core->tpl->output( 'body' );

	$core->footer();

}

function offerprice ( $core, $ofrid = false ) {

	$price = array();
	$wh = $ofrid ? " AND offer_id = '$ofrid' " : '';
	$ps = $core->db->data( "SELECT * FROM ".DB_PRICE." WHERE wmset = 1 AND price_out = 0 $wh ORDER BY price_sort ASC, price_id ASC" );
	$of = $core->db->data( "SELECT offer_id, offer_country, offer_prt FROM ".DB_OFFER." WHERE offer_active = 1 $wh" );

	foreach ( $of as $o ) {
		$prt = unserialize( $o['offer_prt'] );
		$cnt = $o['offer_country'] ? explode( ',', $o['offer_country'] ) : array( 'ru' );
		$oid = (int) $o['offer_id'];
		$price[$oid] = array();
		foreach ( $cnt as $c ) if ( $c = trim( $c ) ) {
			$cur = $core->lang['price_geocur'][$c];
			$price[$oid][$c] = array( 'code' => $c, 'name' => $core->lang['country'][$c], 'land' => $prt[$cur], 'cur' => $core->lang['price_curs'][$cur], 'dsk' => 0, 'dsku' => 0, 'mob' => 0, 'mobu' => 0 );
		}
	}

	$uw = $core->user->id;
	$ur = $core->user->ref;
	$isvip = $core->user->vip;
	$isext = $core->user->ext;
	$isrvp = $ur ? $core->user->get( $ur, 'user_vip' ) : false;
	foreach ( $ps as $p ) {

		if ( $p['price_in'] == 1 ) {
			if ( ! $isvip ) continue;
			if ( $p['price_inid'] && $uw != $p['price_inid'] ) continue;
		} elseif ( $p['price_in'] == 2 ) {
			if ( ! $isext ) continue;
			if ( $p['price_inid'] && $uw != $p['price_inid'] ) continue;
		} elseif ( $p['price_in'] == 3 ) {
			if ( ! $isrvp ) continue;
			if ( $p['price_inid'] && $ur != $p['price_inid'] ) continue;
		}

		$oid = (int) $p['offer_id'];
		$geo = $p['price_geo'] ? explode( ',', $p['price_geo'] ) : false;
		$wmp = $p['wm'];
		$wmu = $p['wmup'];

		if ( $price[$oid] ) foreach ( $price[$oid] as $cc => &$c ) {

			if ( $geo ) if (!in_array( $cc, $geo )) continue;
			if ( $p['price_mobile'] ) {

				if ( $p['price_mobile'] == 1 ) {
					$c['mob'] = $wmp;
					$c['mobu'] = $wmu;
				}

				if ( $p['price_mobile'] == 2 ) {
					$c['dsk'] = $wmp;
					$c['dsku'] = $wmu;
				}

			} else {
				$c['dsk'] = $c['mob'] = $wmp;
				$c['dsku'] = $c['mobu'] = $wmu;
			}

		}

	}

	return $ofrid ? $price[$ofrid] : $price;

}

// lib-end. =)