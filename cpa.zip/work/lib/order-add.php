<?php

/*******************************************************************************

 *
 * 	AlterVision Core Framework - CPA platform
 * 	Created by AlterVision - altervision.me
 *  Copyright © 2014-2017 Anton Reznichenko
 *

 *
 *  File: 			lib / order-add.php
 *  Description:	Order creator
 *  Author:			Anton 'AlterVision' Reznichenko - altervision13@gmail.com
 *

*******************************************************************************/

require_once PATH_LIB . 'ncl.php';

//
// New order
//

function neworder ( $core, $data, $file = false ) {

	$sid 	= (int) $data['site'];
	$spc 	= (int) $data['from'];
	$fid 	= (int) $data['flow'];
	$oid 	= (int) $data['offer'];
	$iptext	= $data['ip'];
	$ip		= ip2int( $iptext );
	$name	= $data['name'] ? $core->text->line( $data['name'] ) : 'Без Воображения';
	$ind	= (int) $data['index'];
	$area	= $core->text->line( $data['area'] );
	$city	= $core->text->line( $data['city'] );
	$street	= $core->text->line( $data['street'] );
	$addr	= $core->text->line( $data['addr'] );
	if ( $addr == 'Уточнить по телефону' ) $addr = '';
	if ( $addr == 'Адрес узнать по телефону' ) $addr = '';
	$comm	= $core->text->line( $data['comm'] );
	$phone 	= (string) trim(preg_replace( '#[^0-9]+#i', '', $data['phone'] ));
	$promo 	= (string) trim(preg_replace( '#[^0-9]+#i', '', $data['promo'] ));
	$cnt	= ( $data['count'] > 0 ) ? (int) $data['count'] : 1;
	$more	= ( $data['more'] > 0 ) ? (int) $data['more'] : 0;
	$dsc	= ( $data['discount'] > 0 && $data['discount'] < 100 ) ? (int) $data['discount'] : 0;
	$cntr	= $data['country'] ? strtolower(substr( $core->text->link( $data['country'] ), 0, 2 )) : false;
	$dlvr	= ( $data['delivery'] > 0 ) ? (int) $data['delivery'] : 1;
	$exti	= (int) $data['exti'];
	$extu	= $exti ? addslashes(preg_replace( '#[^0-9A-Za-z\_\-\.]+#i', '', stripslashes($data['extu']) )) : 0;
	$exts	= $exti ? addslashes(preg_replace( '#[^0-9A-Za-z\_\-\.]+#i', '', stripslashes($data['exts']) )) : 0;
	$us		= addslashes(mb_substr(filter_var( stripslashes($data['us']), FILTER_SANITIZE_STRING ), 0, 50));
	$uc		= addslashes(mb_substr(filter_var( stripslashes($data['uc']), FILTER_SANITIZE_STRING ), 0, 50));
	$un		= addslashes(mb_substr(filter_var( stripslashes($data['un']), FILTER_SANITIZE_STRING ), 0, 50));
	$ut		= addslashes(mb_substr(filter_var( stripslashes($data['ut']), FILTER_SANITIZE_STRING ), 0, 50));
	$um		= addslashes(mb_substr(filter_var( stripslashes($data['um']), FILTER_SANITIZE_STRING ), 0, 50));
	$curr	= (int) $data['currency'];
	$mobile	= $data['mobile'] ? 1 : 0;
	$bad	= $data['bad'] ? 1 : 0;
//	$items	= is_array( $data['items'] ) ? serialize( $data['items'] ) : '';
	$meta	= $data['meta'] ? addslashes(serialize(unserialize(stripslashes( $data['meta'] )))) : '';
	$base	= ( $data['base'] > 0 ) ? (int) $data['base'] : 0;
	$total	= ( $data['total'] > 0 ) ? (int) $data['total'] : 0;

	if (!( $oid && $offer = $core->wmsale->get( 'offer', $oid ) )) return 'offer';
	$site = $sid ? $core->wmsale->get( 'site', $sid ) : false;
	$flow = $fid ? $core->wmsale->get( 'flow', $fid ) : false;
	$ext = $exti ? $core->wmsale->get( 'ext', $exti ) : false;

	$accept = ( $data['accept'] || $data['status'] == 6 || $data['status'] == 10 ) ? true : false;
	$status = ( $offer['offer_payment'] == 1 ) ? 0 : 1;

	$userid = $flow ? $flow['user_id'] : ( $ext ? $ext['user_id'] : false );
	if ( $userid && $core->user->get( $userid, 'user_ban' ) ) return 'security';

	if ( $phone ) {

		// Name and address
		$name = mb_ucwords( $name );
		if ( ! $ind ) {
			if ( preg_match ( '#^([0-9]+)#i', $addr, $ind ) ) {
				$ind = $ind[1];
				$ad = preg_split( '#[\s,\.]+#i', $addr, 2 );
				$addr = trim( $ad[1], ' ,' );
			} else $ind = '';
		}

		// Price, presents and discounts
/*		if ( $data['items'] ) {
			$price = $cnt = $base = 0;
			$vars = $core->wmsale->get( 'vars', $offer['offer_id'] );
			foreach ( $vars as &$v ) if ( $data['items'][$v['var_id']] ) {
				$vpr = $v['var_price'] ?  unserialize( $v['var_price'] ) : array();
				$cnt += $data['items'][$v['var_id']];
				$price += $data['items'][$v['var_id']] * $vpr[$curr];
			} unset ( $v, $vpr, $vars );
		} else {
			$prt = $offer['offer_prt'] ? unserialize( $offer['offer_prt'] ) : array();
			$base = $prt[$curr];
			$price = $cnt * $base;
		} */
		if ( ! $base ) {
			$prt = $offer['offer_prt'] ? unserialize( $offer['offer_prt'] ) : array();
			$base = $prt[$curr];
		}
		$price = $cnt * $base;
		if ( $dsc ) $price = ceil( $price * ( ( 100 - $dsc ) / 100 ) );
		if ( $total ) {
			$more = $total - $price;
			if ( $offer['offer_delivery'] ) {
				$delpr = $more;
				$more = 0;
			} else $dlvr = $delpr = 0;
		} else {
			if ( $offer['offer_delivery'] ) {
				$delpr = $core->lang['deliverbase'][$curr];
				$price += $delpr;
			} else $dlvr = $delpr = 0;
		}
		if ( $more ) $price += $more;

		// Check phone
		if ( $phone{0} == '9' && strlen($phone) == 10 ) $phone = '7' . $phone;
		if ( $phone{0} == '8' && strlen($phone) == 11 ) $phone = '7' . substr( $phone, 1 );

		// Country by phone
		if ( ! $cntr ) {
			$pl = strlen( $phone );
			$p2 = (int) substr( $phone, 0, 2 );
			$p3 = (int) substr( $phone, 0, 3 );
			if ( $pl == 11 && ( $p2 == 73 || $p2 == 74 || $p2 == 75 || $p2 == 78 || $p2 == 79 ) ) $cntr = 'ru';
			if ( $pl == 11 && ( $p2 == 77 || $p2 == 76 ) ) $cntr = 'kz';
			if ( $pl == 12 && $p3 == 380 ) $cntr = 'ua';
			if ( $pl == 12 && $p3 == 375 ) $cntr = 'by';
			if ( $pl == 12 && $p3 == 374 ) $cntr = 'am';
			if ( $pl == 12 && $p3 == 995 ) $cntr = 'ge';
			if ( $pl == 12 && $p3 == 996 ) $cntr = 'kg';
			if ( $pl == 12 && $p3 == 373 ) $cntr = 'md';
		}

		// GeoIP data
		$geoipdata = geoip( $core, $iptext );
		if ( $geoipdata ) {
			$geoip = array(
				'geoip_country'		=> $geoipdata['country'],
				'geoip_city'		=> $geoipdata['city'],
				'geoip_region'		=> $geoipdata['region'],
				'geoip_district'	=> $geoipdata['district'],
				'geoip_lat'			=> $geoipdata['lat'],
				'geoip_lng'			=> $geoipdata['lng'],
			);
			$geocntr = $geoip['geoip_country'];
        	if ( !$cntr ) $cntr = $geoip['geoip_country'];
        	if ( !$addr && !$city ) $city = $geoip['geoip_city'];
        	if ( !$addr && !$area ) $area = $geoip['geoip_region'];
		} else $geoip = $geocntr = false;

		// Check for bans
		$phs = $core->db->field( "SELECT `status` FROM ".DB_BAN_PH." WHERE `phone` = '$phone' LIMIT 1" );
		$ips = $core->db->field( "SELECT `status` FROM ".DB_BAN_IP." WHERE `ip` = '$ip' LIMIT 1" );
		if ( $phs || $ips ) return 'ban';

		// Guess gender automatically
		$nc = new NCLNameCaseRu();
		$gender = ( $nc->genderDetect( $name ) != NCL::$MAN ) ? 2 : 1;
		unset ( $nc );

		// Script based company guess
		$comp = 0;
		if ( $offer['in_script'] ) {
			$tp = array( 'user' => $flow['user_id'], 'flow' => $fid, 'site' => $sid, 'space' => $spc, 'ext' => $exti, 'geo' => $cntr, 'geoip' => $geocntr, 'city' => mb_strtolower( $city, 'UTF-8' ) );
			$scr = explode( "\n", $offer['in_script'] );
			$hm = (int) date( 'Hi' );
			foreach ( $scr as $sc ) {

				// Prepare script line to process
				$iid = $iit = false;
				$sc = trim( $sc ); if ( ! $sc ) continue;

				// Timing
				if (preg_match( '/time\(([0-9]+)\-([0-9]+)\)/i', $sc, $ms )) {
					$tmf = ( strlen( $ms[1] ) < 3 ) ? 100 * ( (int) $ms[1] ) : (int) $ms[1];
					$tmt = ( strlen( $ms[2] ) < 3 ) ? 100 * ( (int) $ms[2] ) : (int) $ms[2];
                    if ( $tmf > $tmt ) {
						if ( $hm < $tmf && $hm > $tmt ) continue;
                    } elseif ( $hm < $tmf || $hm > $tmt ) continue;
				}

				// Get company for the script line
				if (preg_match( '/#([0-9]+)/si', $sc, $ms )) {
					$cms = $ms[1];
				} else continue;

				// Get possibility
				if (preg_match( '/([0-9]+)\%/si', $sc, $ms )) {
					$pos = $ms[1];
					$rnd = ceil(rand( 0, 100 ));
					if ( $rnd > $pos ) continue;
				} else $pos = false;

				// Make the tests array
				$tests = array();
				if (preg_match_all( '#([a-z]+)\:([0-9a-z]+)#si', $sc, $ms )) foreach ( $ms[1] as $mi => $mo ) if ( $mo && $ms[2][$mi] ) $tests[$mo] = $ms[2][$mi];
				if (preg_match_all( '#([a-z]+)\:\[(.+)\]#si', $sc, $ms )) foreach ( $ms[1] as $mi => $mo ) if ( $mo && $ms[2][$mi] ) $tests[$mo] = mb_strtolower( $ms[2][$mi], 'UTF-8' );

				// Walk through tests
				if (count( $tests )) {
					$isok = true;
					foreach ( $tests as $t => $v ) if ( $tp[$t] != $v ) $isok = false;
					if ( $isok ) $comp = $cms;
				} elseif ( $pos ) {
					$comp = $cms;
				} else continue;

				if ( $comp ) break; // If script worked OK

			} unset ( $sc, $scr );
		}

		// Default company
		if ( ! $comp ) {
			if ( $offer['in_default'] && ! $site['site_comp'] ) {
				$comp = $offer['in_default'];
			} else $comp = $site['comp_id'];
		}

		// What to add
		$data = array(
			'offer_id' 			=> $oid,
			'comp_id'			=> $comp,
			'wm_id'				=> $userid,
			'flow_id' 			=> $fid,
			'site_id' 			=> $sid,
			'space_id' 			=> $spc,
			'utms' 				=> $us,
			'utmc' 				=> $uc,
			'utmn' 				=> $un,
			'utmt' 				=> $ut,
			'utmm' 				=> $um,
			'ext_id'			=> $exti,
			'ext_uid' 			=> $extu,
			'ext_src' 			=> $exts,
			'order_time'		=> time(),
			'order_mobile'		=> $mobile,
			'order_bad'			=> $bad,
			'order_ip' 			=> $ip,
			'order_country'		=> $cntr,
			'order_name' 		=> $name,
			'order_gender'		=> $gender,
			'order_phone' 		=> $phone,
			'order_index' 		=> $ind,
			'order_area' 		=> $area,
			'order_city' 		=> $city,
			'order_street' 		=> $street,
			'order_addr' 		=> $addr,
			'order_comment' 	=> $comm,
//			'order_items' 		=> $items,
			'order_meta' 		=> $meta,
			'order_count' 		=> $cnt,
			'order_discount' 	=> $dsc,
			'order_delivery' 	=> $dlvr,
			'order_status' 		=> $status,
			'order_webstat' 	=> $status,
			'price_cur'			=> $curr,
			'price_base'		=> $base,
			'price_more'		=> $more,
			'price_delivery'	=> $delpr,
			'price_total'		=> $price,
			'promo_code'		=> $promo,
		);
		if ( $geoip ) $data += $geoip;

		// Payments
		if ( ! $accept ) {
			require_once PATH_LIB . 'order-cash.php';
			$mm = order_cash( $core, $data );
			$data['cash_wm'] = $mm['wmp'];
			$data['cash_pay'] = $mm['pay'];
		}

		// Adding the order
		if ( $core->db->add( DB_ORDER, $data ) ) {

			$id = $core->db->lastid();

			if ( $file ) {
				if ( is_uploaded_file( $file['tmp_name'] ) ) {
					$dot = strrpos( $file['name'], '.' );
					$ext = strtolower(substr( $file['name'], $dot + 1 ));
					$name = $id .'-'. substr( $core->text->link( substr( $file['name'], 0, $dot ) ), 0, 90 ) . '.' . $ext;
					$goodext = array( 'jpg', 'jpeg', 'gif', 'png', 'zip', 'rar', 'rar5', '7z', 'cdr', 'pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx' );
					if ( in_array( $ext, $goodext ) ) {
						move_uploaded_file( $file['tmp_name'], sprintf( FILENAME, $name ) );
						$core->db->edit( DB_ORDER, array( 'order_file' => $name ), "order_id = '$id'" );
					}
				}
			}

			// Changes processing
			$chd = array();
			$cfs = array( 'order_name', 'order_phone', 'comp_id', 'order_country', 'order_index', 'order_area', 'order_city', 'order_street', 'order_addr', 'order_comment', 'order_count', 'order_discount', 'order_delivery', 'price_cur', 'price_base', 'price_more', 'price_delivery' );
			foreach ( $cfs as $c ) if ( isset( $data[$c] ) && $data[$c] ) $chd[$c] = stripslashes( $data[$c] );
			if ( $chd ) $core->db->add( DB_CHANGE, array( 'order_id' => $id, 'change_time' => time(), 'change_data' => addslashes(serialize( $chd )) ) );

			if ( $accept ) {

				require_once PATH_LIB . 'order-edit.php';
				order_edit ( $core, $id, array( 'accept' => 1 ) );

			} else {

				if ( $exti && $url = $core->wmsale->get( 'ext', $exti, 'url_new' ) ) {
	            	if ( preg_match_all( '#\{eval:\[(.*?)\]\}#si', $url, $ems ) ) foreach ( $ems[0] as $k => $v ) $url = str_replace( $v, eval( $ems[1][$k] ), $url );
	            	$url = str_replace( '{id}', $id, $url );
	            	$url = str_replace( '{uid}', $extu, $url );
	            	$url = str_replace( '{src}', $exts, $url );
	            	$url = str_replace( '{time}', time(), $url );
	            	$url = str_replace( '{price}', $price, $url );
	            	$url = str_replace( '{count}', $cnt, $url );
					foreach ( $offer as $k => $v ) $url = str_replace( "{offer:$k}", $v, $url );
					$odata = $offer['offer_pars'] ? unserialize( $offer['offer_pars'] ) : false;
	            	if ( $odata ) foreach ( $odata as $k => $v ) $url = str_replace( "{data:$k}", $v, $url );
					curl( $url );
				}

				// PostBack processing
				if ( $userid && ( $pbu = $core->wmsale->get( 'flow', $flw, 'flow_pbu' ) ) ) {

					$pbu = html_entity_decode( $pbu );
					if ( substr( $pbu, 0, 5 ) == 'POST:' ) {
						$post = true;
						$pbu = substr( $pbu, 5 );
					} else $post = false;

					$pbd = array(
						'id'		=> $id,
						'offer'		=> $oid,
						'flow'		=> $flw,
						'target'	=> $tgt,
						'site'		=> $sid,
						'space'		=> $spc,
	            		'ip'		=> int2ip( $ip ),
						'geo'		=> $cntr,
						'count'		=> $cnt,
						'price'		=> $price,
						'status'	=> $status,
						'date'		=> time(),
						'utms'		=> $us,
						'utmc'		=> $uc,
						'utmn'		=> $un,
						'utmt'		=> $ut,
						'utmm'		=> $um,
					);

					if (preg_match_all( '#\{stage\:([^}]+)\}#', $pbu, $ms )) {
						foreach ( $ms[0] as $i => $m ) {
							$stl = explode( '|', $ms[1][$i] );
							$sti = $stl[$status-1];
							$pbu = str_replace( $m, $sti, $pbu );
						}
					}

					foreach ( $pbd as $pbk => $pbv ) $pbu = str_replace( '{'.$pbk.'}', $pbv, $pbu );
					if ( $post ) {
						curl( $pbu, $pbd );
					} else curl( $pbu );

				}

			}

			return (int) $id;

		} else return 'db';

	} else return 'data';

}

function makeneworder ( $core ) {

	$action = ( $core->get['neworder'] ) ? $core->text->link( $core->get['neworder'] ) : null;

	switch ( $action ) {

	  case 'add':

		// Get site key and ID
		$sid = (int) $core->post['site'];
		$key = $core->text->link( $core->get['key'] );

		// Check the site
		if (!( $sid && $site = $core->wmsale->get( 'site', $sid ) )) {
			echo 'e:site';
			$core->_die();
		}

		// Check securitu
		if ( $site['site_key'] != $key && hash_hmac( 'sha1', http_build_query( $core->post ), $site['site_key'] ) != $key ) {
			echo 'e:key';
			$core->_die();
		}

		// Process order
		unset ( $core->post['status'], $core->post['items'] );
		$oid = neworder( $core, $core->post, $core->files['file'] ? $core->files['file'] : false );
		echo is_numeric( $oid ) ? 'ok:'.$oid : 'e:' . $oid;
		$core->_die();

	  case 'ext':

/*		$postline = var_export( $core->post, true );
		$getline = $core->server['HTTP_HOST'] . $core->server['REQUEST_URI'];
		file_put_contents( PATH . 'data/logs/'.time().'-'.rand( 1, 10 ).'.txt', sprintf( "%s\r\n%s", $getline, str_replace( "\n", "\r\n", $postline ) ) ); */

		// Get request info
		$fields = array( 'offer', 'oid', 'site', 'space', 'key', 'exto', 'exti', 'extu', 'exts', 'country', 'name', 'phone', 'area', 'city', 'street', 'addr', 'addr1', 'addr2', 'addr3', 'ip', 'present', 'count', 'discount', 'status', 'comm', /*'items', 'counts',*/ 'more', 'promo', 'currency', 'mobile', 'bad' );
		$data = array(); foreach ( $fields as $f ) if ( $core->post[$f] || $core->get[$f] ) $data[$f] = $core->post[$f] ? $core->post[$f] : $core->get[$f];

		// Get external ID
		$exti = (int) $data['exti'];
		$ext = $core->wmsale->get( 'ext', $exti );

		// Check security
		if ( $data['key'] != $ext['ext_key'] ) {
			echo json_encode(array( 'status' => 'error', 'error_text' => 'key' ));
			$core->_die();
		}

		if ( isset( $data['currency'] ) && !is_numeric( $data['currency'] ) ) {
			$cur = strtolower( $data['currency'] );
			if ( $core->lang['price_codecur'][$cur] ) {
				$data['currency'] = $core->lang['price_codecur'][$cur];
			} else $data['currency'] = $core->lang['price_geocur'][$data['country']] ? $core->lang['price_geocur'][$data['country']] : 0;
		} elseif (!isset($data['currency'])) $data['currency'] = $core->lang['price_geocur'][$data['country']] ? $core->lang['price_geocur'][$data['country']] : 0;

		// Count items
	/*	if ( $data['items'] ) {
			$ii = explode( ',', $data['items'] );
			$cc = explode( ',', $data['counts'] );
			$data['items'] = array();
			foreach ( $ii as $q => $i ) if ( $i = (int) $i ) {
				if ( ! $data['items'][$i] ) {
					$data['items'][$i] = (int) $cc[$q];
				} else $data['items'][$i] += (int) $cc[$q];
			}
			$data['count'] = array_sum( $data['items'] );
			unset( $data['counts'] );
		} else unset( $data['items'], $data['counts'] ); */

		// Check offer ID
		if ( ! $data['offer'] ) {
			if ( ! $ext['code_offer'] ) {
				echo json_encode(array( 'status' => 'error', 'error_text' => 'no-offer-code' ));
				$core->_die();
	    	} else {
				$data['offer'] = eval( $ext['code_offer'] );
		    	if ( ! $data['offer'] ) {
					echo json_encode(array( 'status' => 'error', 'error_text' => 'offer' ));
					$core->_die();
		    	}
		  	}
		}

		// Check for status
		if ( $ext['code_accept'] ) {
			$isok = eval( $ext['code_accept'] );
			if ( ! $isok ) {
				echo json_encode(array( 'status' => 'error', 'error_text' => 'status' ));
				$core->_die();
			} else $data['status'] = $isok;
		} else unset( $data['status'] );

		// Process order
		$oid = neworder( $core, $data, $core->files['file'] ? $core->files['file'] : false );
		if ( is_numeric( $oid ) ) {
			echo json_encode(array( 'status' => 'ok', 'id' => $oid ));
		} else echo json_encode(array( 'status' => 'error', 'error_text' => $oid ));
		$core->_die();

	}

	if (defined( 'HACK_ADD' )) include PATH . HACK . 'hack/add.php';
	header( 'HTTP/1.0 404 Not Found' );

}

// end. =)