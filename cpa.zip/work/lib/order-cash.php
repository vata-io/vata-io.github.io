<?php

/*******************************************************************************

 *
 * 	AlterVision Core Framework - CPA platform
 * 	Created by AlterVision - altervision.me
 *  Copyright � 2014-2017 Anton Reznichenko
 *

 *
 *  File: 			lib / order-cash.php
 *  Description:	Cash counter for the order operations
 *  Author:			Anton 'AlterVision' Reznichenko - altervision13@gmail.com
 *

*******************************************************************************/

// Edit order info
function order_cash ( $core, $order ) {

	// Webmaster data
	$uw = $order['wm_id'];
	$ur = $uw ? $core->user->get( $uw, 'user_ref' ) : false;
	$isvip = $uw ? $core->user->get( $uw, 'user_vip' ) : false;
	$isext = $uw ? $core->user->get( $uw, 'user_ext' ) : false;
	$isrvp = $ur ? $core->user->get( $ur, 'user_vip' ) : false;

	// Company and call-center data
	$up = $core->wmsale->get( 'comp', $order['comp_id'], 'user_id' );
	if ( $order['cc_id'] ) {
		$uc = $core->wmsale->get( 'comp', $order['cc_id'], 'user_id' );
		$isclc = true;
	} else $uc = $isclc = false;

	// Payments
	$price = $core->wmsale->get( 'prices', $order['offer_id'] );
	$wmp = $wmu = $wml = $pay = $pyu = $pyl = $ccp = $ccu = $ccl = $rep = 0;
	$ocntr = strtolower( $order['order_country'] );

	// Processing
	foreach ( $price as $p ) {
		// Webmaster or external
		if ( $p['price_in'] == 1 ) {			if ( ! $isvip ) continue;
			if ( $p['price_inid'] && $uw != $p['price_inid'] ) continue;
		} elseif ( $p['price_in'] == 2 ) {			if ( ! $isext ) continue;
			if ( $p['price_inid'] && $uw != $p['price_inid'] ) continue;
		} elseif ( $p['price_in'] == 3 ) {
			if ( ! $isrvp ) continue;
			if ( $p['price_inid'] && $ur != $p['price_inid'] ) continue;
		}

		// Company and call-center
		if ( $p['price_out'] == 1 ) {			if ( ! $isclc ) continue;
			if ( $p['price_outid'] && $uc != $p['price_outid'] ) continue;
		} else if ( $p['price_outid'] && $up != $p['price_outid'] ) continue;

		// Checking geo
		if ( $p['price_geo'] ) {			$geo = explode( ',', $p['price_geo'] );
			if (!in_array( $ocntr, $geo )) continue;
		}

		// Checking promo code
		if ( $p['price_promo'] ) {
			if ( $p['price_promo'] == 1 && $order['promo_code'] == 0 ) continue;
			if ( $p['price_promo'] == 2 && $order['promo_code'] != 0 ) continue;
		}

		// Checking delivery
		if ( $p['price_deliv'] ) {
			if ( $p['price_deliv'] == 1 && $order['order_delivery'] == 0 ) continue;
			if ( $p['price_deliv'] == 2 && $order['order_delivery'] != 0 ) continue;
		}

		// Checking mobile traffic
		if ( $p['price_mobile'] ) {
			if ( $p['price_mobile'] == 1 && $order['order_mobile'] != 1 ) continue;
			if ( $p['price_mobile'] == 2 && $order['order_mobile'] == 1 ) continue;
		}

		// Checking bad traffic
		if ( $p['price_bad'] ) {
			if ( $p['price_bad'] == 1 && $order['order_bad'] != 1 ) continue;
			if ( $p['price_bad'] == 2 && $order['order_bad'] == 1 ) continue;
		}

		// Webmaster and call-center payments
		if ( $p['wmset'] ) {
			if ( $p['price_out'] ) {
				$ccp = $p['wm'];
				$ccu = $p['wmup'];
				$ccl = $p['wmlim'];
			} else {
				$wmp = $p['wm'];
				$wmu = $p['wmup'];
				$wml = $p['wmlim'];
			}
		}

		// Company and partner payments
		if ( $p['parset'] ) $rep = $p['partner'];
		if ( $p['payset'] ) {			$pay = $p['pay'];
			$pyu = $p['payup'];
			$pyl = $p['paylim'];
		}

		// Final price
		if ( $p['price_last'] ) break;

	}

	// UpSale
	$ocnts = $order['order_count'];
	if ( $ocnts > 1 ) {		if ( $wmu ) $wmp += $wmu * max( 0, ( $wml ? min( $ocnts, $wml ) : $ocnts ) - 1 );
		if ( $pyu ) $pay += $pyu * max( 0, ( $pyl ? min( $ocnts, $pyl ) : $ocnts ) - 1 );
		if ( $ccu ) $ccp += $ccu * max( 0, ( $ccl ? min( $ocnts, $ccl ) : $ocnts ) - 1 );
	}

	return array(
		'up' 	=> $up,		'uc' 	=> $uc,		'uw'	=> $uw,		'ur' 	=> $ur,		// Users
        'pay'	=> $pay,	'ccp'	=> $ccp,	'wmp'	=> $wmp,	'rep'	=> $rep,	// Payments
	);

}

// lib-end. =)