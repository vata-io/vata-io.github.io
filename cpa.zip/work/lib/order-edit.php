<?php

/*******************************************************************************

 *
 * 	AlterVision Core Framework - CPA platform
 * 	Created by AlterVision - altervision.me
 *  Copyright � 2014-2017 Anton Reznichenko
 *

 *
 *  File: 			lib / order-edit.php
 *  Description:	Order edit function
 *  Author:			Anton 'AlterVision' Reznichenko - altervision13@gmail.com
 *

*******************************************************************************/

// Edit order info
function order_edit ( $core, $id, $info, $order = null ) {

	// Loading order info for processing of changes
	if ( ! $order ) $order = $core->db->row( "SELECT * FROM ".DB_ORDER." WHERE order_id = '$id' LIMIT 1" );
	$offer = $core->wmsale->get( 'offer', $order['offer_id'] );
	$comp = $core->wmsale->get( 'comp', $order['comp_id'] );
	$cc = $comp['comp_type'] ? true : false;
	$changes = array();

	// Check order permissions
	if (!( defined( 'INTHEWORK' ) || $core->user->level )) {
		if ( $order['comp_id'] != $core->user->comp ) return false;
		if ( ! $core->wmsale->team( 'mod' ) ) {			if ( $order['order_status'] == 5 ) return false;
			if ( $order['order_status'] > 9 ) return false;
			if ( $order['order_status'] < 5 && !$core->wmsale->team('call') ) return false;
			if ( $order['order_status'] == 6 && !$core->wmsale->team('pack') ) return false;
			if ( $order['order_status'] == 7 && !$core->wmsale->team('send') ) return false;
			if ( $order['order_status'] > 7 && !$core->wmsale->team('delivery') ) return false;
		}
	}

	// Basic info
	if (isset($info['status'])	&& $info['status']!= $order['order_status'] )	$changes['order_status']= $info['status'];
	if (isset($info['reason'])	&& $info['reason']!= $order['order_reason'] )	$changes['order_reason']= $info['reason'];
	if (isset($info['user'])	&& $info['user'] != $order['user_id'] )			$changes['user_id']		= $info['user'];
	if (isset($info['comp'])	&& $info['comp'] != $order['comp_id'] )			$changes['comp_id']		= $info['comp'];
	if (isset($info['name'])	&& $info['name'] != $order['order_name'] )		$changes['order_name']	= $info['name'];
	if (isset($info['addr'])	&& $info['addr'] != $order['order_addr'] )		$changes['order_addr'] 	= $info['addr'];
	if (isset($info['country'])	&& $info['country'] != $order['order_country'])	$changes['order_country']= $info['country'];
	if (isset($info['area'])	&& $info['area'] != $order['order_area'] )		$changes['order_area'] 	= $info['area'];
	if (isset($info['city'])	&& $info['city'] != $order['order_city'] )		$changes['order_city'] 	= $info['city'];
	if (isset($info['street'])	&& $info['street'] != $order['order_street'] )	$changes['order_street']= $info['street'];
	if (isset($info['index'])	&& $info['index'] != $order['order_index'] )	$changes['order_index']	= $info['index'];
	if (isset($info['phone'])	&& $info['phone'] != $order['order_phone'] )	$changes['order_phone']	= $info['phone'];
	if (isset($info['track'])	&& $info['track'] != $order['track_code'] )		$changes['track_code']	= $info['track'];
	if (isset($info['rec'])		&& $info['rec'] != $order['order_recall'] )		$changes['order_recall']= $info['rec'];
	if (isset($info['curr'])	&& $info['curr'] != $order['price_cur'] )		$changes['price_cur']	= $info['curr'];
	if (isset($info['comment'])	&& $info['comment'] != $order['order_comment'] )$changes['order_comment']= $info['comment'];
	if (isset($info['exto'])	&& $info['exto'] != $order['ext_oid'] )			$changes['ext_oid'] 	= $info['exto'];
	if (isset($info['check']) 	&& $info['check'] != $order['order_check'] )	$changes['order_check']	= $info['check'];

	// Order Metadata
	if (isset( $info['meta'] )) {
		ksort( $info['meta'] );
		$mm = serialize( $info['meta'] );
		$ometa = $info['meta'];
		if ( $mm != $order['order_meta'] ) $changes['order_meta'] = $mm;
	} else $ometa = $order['order_meta'] ? unserialize( $order['order_meta'] ) : array();

	// SPSR track info
	if (isset( $info['spsr'] )) {
		$spsr = $info['spsr'];
		$sd = serialize( $spsr );
		if ( $sd != $order['track_spsr'] ) $changes['track_spsr'] = $sd;
	} else $spsr = false;

	// Order Accepting
	if ( $info['accept'] ) {
		if ( $cc ) {
			// Manual setting the company
			$changes['cc_id'] = $order['comp_id'];
			if ( $changes['comp_id'] ) {				$acmp = preg_split( '/[\s\,]+/', $offer['out_comps'], -1, PREG_SPLIT_NO_EMPTY );
				if (!in_array( $changes['comp_id'], $acmp )) unset( $changes['comp_id'] );
			}

			// Script for setting the company
			if ( ! $changes['comp_id'] ) {
				// Script based company guess
				$cts = 0;
				if ( $offer['out_script'] ) {					$tp = array( 'user' => $order['wm_id'], 'flow' => $order['flow_id'], 'site' => $order['site_id'], 'space' => $order['space_id'], 'ext' => $order['ext_id'], 'geo' => $changes['order_country'] ? $changes['order_country'] : $order['order_country'], 'geoip' => $order['geoip_country'], 'city' => mb_strtolower( $changes['order_city'] ? $changes['order_city'] : $order['order_city'], 'UTF-8' ) );
					$scr = explode( "\n", $offer['out_script'] );
					$hm = (int) date( 'Hi' );
					foreach ( $scr as $sc ) {

						// Prepare script line to process
						$iid = $iit = false;
						$sc = trim( $sc ); if ( ! $sc ) continue;

						// Timing
						if (preg_match( '/time\(([0-9]+)\-([0-9]+)\)/i', $sc, $ms )) {
							$tmf = ( strlen( $ms[1] ) < 3 ) ? 100 * ( (int) $ms[1] ) : (int) $ms[1];
							$tmt = ( strlen( $ms[2] ) < 3 ) ? 100 * ( (int) $ms[2] ) : (int) $ms[2];
		                    if ( $tmf > $tmt ) {
								if ( $hm < $tmf && $hm > $tmt ) continue;
		                    } elseif ( $hm < $tmf || $hm > $tmt ) continue;
						}

						// Get company for the script line
						if (preg_match( '/#([0-9]+)/si', $sc, $ms )) {
							$cms = $ms[1];
						} else continue;

						// Get possibility
						if (preg_match( '/([0-9]+)\%/si', $sc, $ms )) {
							$pos = $ms[1];
							$rnd = ceil(rand( 0, 100 ));
							if ( $rnd > $pos ) continue;
						} else $pos = false;

						// Make the tests array
						$tests = array();
						if (preg_match_all( '#([a-z]+)\:([0-9a-z]+)#si', $sc, $ms )) foreach ( $ms[1] as $mi => $mo ) if ( $mo && $ms[2][$mi] ) $tests[$mo] = $ms[2][$mi];
						if (preg_match_all( '#([a-z]+)\:\[(.+)\]#si', $sc, $ms )) foreach ( $ms[1] as $mi => $mo ) if ( $mo && $ms[2][$mi] ) $tests[$mo] = mb_strtolower( $ms[2][$mi], 'UTF-8' );

						// Walk through tests
						if (count( $tests )) {
							$isok = true;
							foreach ( $tests as $t => $v ) if ( $tp[$t] != $v ) $isok = false;
							if ( $isok ) $cts = $cms;
						} elseif ( $pos ) {
							$cts = $cms;
						} else continue;

						if ( $cts ) break; // If script worked OK

					} unset ( $sc, $scr );
				}

				$changes['comp_id'] = $cts ? $cts : $offer['out_default'];
				if ( ! $changes['comp_id'] ) return false;

			}

		}

		$newcomp = $changes['comp_id'] ? $core->wmsale->get( 'comp', $changes['comp_id'] ) : $comp;
     	$changes['order_status'] = $newcomp['autoaccept'] ? 10 : 6;
     	if ( ! $info['shave'] ) {
     		$sh = (int) $core->wmsale->get( 'ofp', $order['offer_id'], 'shave'.$newcomp['comp_id'] );
     		if ( !$sh ) $sh = (int) $core->wmsale->get( 'ofp', $order['offer_id'], 'shave' );
     		if ( $sh ) $info['shave'] = ( rand( 0, 100 ) <= $sh ) ? 1 : 0;
     	}

	} else {		if ( ( $order['order_status'] == 5 || $order['order_status'] > 7 ) && ( $changes['order_status'] < 6 && $changes['order_status'] != 2 ) ) unset( $changes['order_status'] );
		if ( $order['order_status'] > 5 && $order['order_status'] < 8 && $changes['order_status'] < 5 ) unset( $changes['order_status'] );
	}

	// WebStatus and OrderStatus can be different
	if ( $changes['order_status'] ) {
		$shave = $info['shave'] ? 1 : 0;
		if ( $changes['order_status'] > 4 ) {
			if ( $shave ) {
				$changes['order_webstat'] = 5;
				$changes['order_reason'] = rand( 0, 7 ) ? 3 : 2;
				$changes['order_shave'] = $shave;
			} elseif ( $order['order_status'] == $order['order_webstat'] ) $changes['order_webstat'] = $changes['order_status'];
		} else $changes['order_webstat'] = $changes['order_status'];
	}

	// Calls are incremental
	if ( $info['calls']	) $changes['order_calls'] = ( (int) $order['order_calls'] ) + $info['calls'];

	// Check the phone to be russian mobile +79etc
	if ( $changes['order_phone'] ) $changes['order_phone_ok'] = ( substr( $changes['order_phone'], 0, 2 ) == '79' ) ? 1 : 0;

	// Track code changes will null tracking status
	if ( $changes['track_code'] ) {
		$changes['track_on']		= $info['track_on'] ? $info['track_on'] : 0;
		$changes['track_check']		= $info['track_check'] ? $info['track_check'] : 0;
		$changes['track_date']		= '';
		$changes['track_status']	= '';
	}

	// Checking items and delivery
	if ( isset($info['base']) || isset($info['counts']) || isset($info['delivery']) || isset($info['delpr']) || isset($info['discount']) || isset($info['more']) ) {

		// Process variants or a single offer
		if ( $offer['offer_vars'] ) {

			// Make new items list
			$items = $order['order_items'] ? unserialize( $order['order_items'] ) : array();
			if ( isset( $info['base'] ) || isset( $info['counts'] ) ) {				if ( isset( $info['base'] ) && isset( $info['counts'] ) ) {					$items = array();
					foreach ( $info['counts'] as $i => $c ) if ( ( $i = (int) $i ) && ( $c = (int) $c ) ) $items[$i] = array( $c, (int) $info['base'][$i] );
				} elseif ( isset( $info['counts'] ) ) {					$oi = $items;
					$items = array();
					foreach ( $info['counts'] as $i => $c ) if ( ( $i = (int) $i ) && ( $c = (int) $c ) ) $items[$i] = array( $c, $oi[$i][1] );
				} else foreach ( $items as $i => $c ) $items[$i][1] = (int) $info['base'][$i];			}

			// Count items and price
			$counts = $price = 0;
			foreach ( $items as $it ) {
				$counts += $it[0];
				$price += $it[0] * $it[1];
			} unset ( $it );
			$changes['order_items'] = serialize( $items );
			$changes['price_base'] = 0;

		} else {

			// Simply take base price and total count
	     	$changes['price_base'] = $base = isset( $info['base'] ) ? $info['base'] : $order['price_base'];
			$counts	= isset( $info['counts'] ) ? $info['counts'] : $order['order_count'];
			$price	= $base * $counts;

		}

		// Process discounts and presents
     	$changes['order_discount'] = $discount = isset( $info['discount'] ) ? $info['discount'] : $order['order_discount'];
     	$changes['price_more'] = $more = isset( $info['more'] ) ? $info['more'] : $order['price_more'];
   		if ( $discount > 0 && $discount < 100 ) $price = ceil( $price * ( ( 100 - $discount ) / 100 ) );
   		if ( $more != 0 ) $price += $more;

		// Process delivery
		if ( $offer['offer_delivery'] ) {
       		$changes['order_delivery'] = $delivery = isset( $info['delivery'] ) ? $info['delivery'] : $order['order_delivery'];
	     	$changes['price_delivery'] = $delpr = isset( $info['delpr'] ) ? $info['delpr'] : $order['price_delivery'];
       		$price += $delpr;
		}

		// Finally set order changes
		$changes['order_count'] = $counts;
		$changes['price_total'] = $price;

	}

	// UnReCall and UnTrack
	if ( ( $changes['order_status'] > 4 || $order['order_status'] > 4 ) && $order['order_recall'] ) $changes['order_recall'] = 0;
	if ( ( $changes['order_status'] > 9 || $order['order_status'] > 9 ) && $order['track_on'] ) {
		$changes['track_on'] = $changes['track_check'] = $changes['track_call'] = $changes['track_result'] = $changes['track_notify'] = 0;
		$changes['track_date'] = $changes['track_status'] = '';
	}

	// Order completion
	if ( $changes['order_status'] == 5 || $changes['order_status'] > 9 ) $changes['order_check'] = 0;
	if ( $order['order_check'] && $changes['order_status'] > 10 ) {
		if (!( $order['ext_id'] || $order['order_shave'] )) {
			require_once ( PATH_LIB . 'finance.php' );
			$f = new Finance( $core );
			$fins = $core->db->col( "SELECT cash_id FROM ".DB_CASH." WHERE order_id = '$id'" );
			foreach ( $fins as $fn ) $f->del( $fn );
			unset ( $f );
		}
		$changes['order_status'] = 12;
		if ( $order['order_status'] == $order['order_webstat'] ) $changes['order_webstat'] = 12;
	} elseif ( $order['order_status'] > 5 && $order['order_status'] < 8 && $changes['order_status'] == 5 ) {		if (!( $order['ext_id'] || $order['order_shave'] )) {
			require_once ( PATH_LIB . 'finance.php' );
			$f = new Finance( $core );
			$fins = $core->db->col( "SELECT cash_id FROM ".DB_CASH." WHERE order_id = '$id'" );
			foreach ( $fins as $fn ) $f->del( $fn );
			unset ( $f );
		}
		$changes['order_reason'] = 2;
		if ( $order['order_status'] == $order['order_webstat'] ) $changes['order_webstat'] = 5;
	}

	// Marks and order last users
	if ( $changes['order_status'] && $core->user->id && $order['comp_id'] == $core->user->comp ) {		if ( $order['mark_time'] ) $changes['mark_time'] = 0;
		if ( $order['user_id'] != $core->user->id ) $changes['user_id'] = $core->user->id;
	}

	// Need to recount price
	if ( $info['accept'] || $changes['order_count'] || $changes['order_delivery'] || $changes['comp_id'] || $changes['order_country']  ) {		require_once PATH_LIB . 'order-cash.php';
		$od = array_merge( $order, $changes );
		$mm = order_cash( $core, $od );
		extract( $mm );
		$changes['cash_wm'] = $wmp;
		$changes['cash_pay'] = $pay;
	} else $uc = $uw = $ur = $up = $wmp = $wmu = $wml = $pay = $pyu = $pyl = $ccp = $ccu = $ccl = $rep = 0;

	// Update order in database
	if (count( $changes )) {
		$sqls = array();
		foreach ( $changes as $k => &$v ) $sqls[] = " $k = '$v' ";
		$commonsql = "UPDATE ".DB_ORDER." SET ".implode( ',', $sqls )." WHERE order_id = '$id' LIMIT 1";
		$result = $core->db->query( $commonsql );
		unset ( $sql, $k, $v );
	} else return false;

	// Post processing
	if ( $result ) {

		// Changes processing
		$chd = array();
		$cfs = array( 'order_name', 'order_phone', 'comp_id', 'order_country', 'order_index', 'order_area', 'order_city', 'order_street', 'order_addr', 'order_comment', 'order_count', 'order_discount', 'order_delivery', 'price_cur', 'price_base', 'price_more', 'price_delivery' );
		foreach ( $cfs as $c ) if ( isset( $changes[$c] ) && $changes[$c] != $order[$c] ) $chd[$c] = stripslashes( $changes[$c] );
		if ( $chd ) $core->db->add( DB_CHANGE, array( 'order_id' => $id, 'user_id' => $core->user->id, 'change_warn' => $chd['order_phone'] ? 1 : 0, 'change_time' => time(), 'change_data' => addslashes(serialize( $chd )) ) );

		// Order confirmation
		if ( $info['accept'] ) {

			// Process payments
			require_once ( PATH_LIB . 'finance.php' );
			$f = new Finance( $core );
			$comment = sprintf ( "%s - %s", $offer['offer_name'], $id );
			if ( $up && $pay ) $f->add( $up, $id, -$pay, 2, $comment );
			if ( $uc && $ccp ) $f->add( $uc, $id, $ccp, 8, $comment );
			if ( $uw && $wmp && !$shave ) {
				$f->add( $uw, $id, $wmp, 3, $comment );
				$core->db->query( "UPDATE ".DB_FLOW." SET flow_total = flow_total + ".$wmp." WHERE flow_id = '".$order['flow_id']."' LIMIT 1" );
				if ( $ur && $rep ) {
					$f->add( $ur, $id, $rep, 7, $comment );
					$core->db->query( "UPDATE ".DB_USER." SET user_got = user_got + '$rep' WHERE user_id = '$uw' LIMIT 1" );
				}
			}

			// Store processing
/*			$items = $changes['order_items'] ? $items : ( $order['order_items'] ? unserialize( $order['order_items'] ) : false );
			$cmpid = $changes['comp_id'] ? $changes['comp_id'] : $order['comp_id'];
			if ( ! $items ) {
				$counts = $changes['order_count'] ? $changes['order_count'] : $order['order_count'];
				$core->db->query( "UPDATE ".DB_STORE." SET store_count = store_count - $counts WHERE offer_id = '".$order['offer_id']."' AND comp_id = '$cmpid' AND var_id = '0' LIMIT 1" );
			} else foreach ( $items as $i => $c ) $core->db->query( "UPDATE ".DB_STORE." SET store_count = store_count - ".$c[0]." WHERE offer_id = '".$order['offer_id']."' AND comp_id = '$cmpid' AND var_id = '$i' LIMIT 1" );*/

		} else $pay = $ccp = $rep = $wmp = 0;

		// Write to call log
		$st = $changes['order_status'];
		if ( $st || $changes['order_recall'] ) {
			$core->db->add( DB_CALL, array(
				'order_id'		=> $id,
				'offer_id'		=> $order['offer_id'],
				'comp_id'		=> $changes['comp_id'] ? $changes['comp_id'] : $order['comp_id'],
				'cc_id'			=> $changes['cc_id'],
				'user_id'		=> $core->user->id,
				'wm_id'			=> $order['wm_id'],
				'call_status'	=> $st ? $st : $order['order_status'],
				'call_reason'	=> $changes['order_reason'],
				'call_time'		=> time(),
				'call_next'		=> $changes['order_recall'],
				'call_length'	=> (int) $info['length'],
				'call_count'	=> $info['accept'] ? ( $changes['order_count'] ? $changes['order_count'] : $order['order_count'] ) : 0,
				'call_accept'	=> $info['accept'] ? 1 : 0,
				'call_price'	=> $info['accept'] ? ( $changes['price_total'] ? $changes['price_total'] : $order['price_total'] ) : 0,
				'call_cur'		=> $info['accept'] ? ( $changes['price_cur'] ? $changes['price_cur'] : $order['price_cur'] ) : 0,
				'call_in'		=> $pay,
				'call_out'		=> $wmp + $ccp + $rep,
			));
		}

		// Sending SMS
		$pok = isset( $changes['order_phone_ok'] ) ? $changes['order_phone_ok'] : $order['order_phone_ok'];
		if ( $pok ) {
			$phone = isset( $changes['order_phone'] ) ? $changes['order_phone'] : $order['order_phone'];
			if ( $comp['sms_post'] && $changes['track_code'] ) sms( SMS_SIGN, $phone, sprintf( $core->lang['sms_send'], $id, $changes['track_code'] ) );
			if ( $st >= $order['order_status'] ) {
				if ( $comp['sms_accept'] && $st == 6 ) sms( SMS_SIGN, $phone, sprintf( $core->lang['sms_accept'], $id ) );
				if ( $comp['sms_spsr'] && $order['order_delivery'] == 2 && $st == 9 ) sms( SMS_SIGN, $phone, sprintf( $core->lang['sms_spsr'], $id, $order['track_code'] ) );
				if ( $comp['sms_rupo'] && $order['order_delivery'] == 1 && $st == 9 ) sms( SMS_SIGN, $phone, sprintf( $core->lang['sms_rupo'], $id, $order['track_code'] ) );
			}
		}

		// External processing
		if ( $order['ext_id'] && $changes['order_webstat'] && $order['order_webstat'] < 5 ) {

        	$ext = $core->wmsale->get( 'ext', $order['ext_id'] );
        	switch ( $changes['order_webstat'] ) {
        		case 3: $url = $ext['url_rc'] ? $ext['url_rc'] : false; break;
        		case 4: $url = $ext['url_nc'] ? $ext['url_nc'] : false; break;
        		case 5: $url = $ext['url_dec'] ? $ext['url_dec'] : false; break;
        		case 6: $url = $ext['url_acc'] ? $ext['url_acc'] : false; break;
        		case 10: $url = $ext['url_pay'] ? $ext['url_pay'] : false; break;
        		case 11: $url = $ext['url_ret'] ? $ext['url_ret'] : false; break;
        		case 12: $url = $ext['url_del'] ? $ext['url_del'] : false; break;
        		default: $url = false;
        	}

        	if ( $url ) {
				if ( ! $offer ) $offer = $core->wmsale->get( 'offer', $order['offer_id'] );
				$odata = $offer['offer_pars'] ? unserialize( $offer['offer_pars'] ) : false;
            	if ( preg_match_all( '#\{eval:\[(.*?)\]\}#si', $url, $ems ) ) foreach ( $ems[0] as $k => $v ) $url = str_replace( $v, eval( $ems[1][$k] ), $url );
            	$url = str_replace( '{id}', $order['order_id'], $url );
            	$url = str_replace( '{uid}', $order['ext_uid'], $url );
            	$url = str_replace( '{src}', $order['ext_src'], $url );
            	$url = str_replace( '{time}', time(), $url );
            	$url = str_replace( '{now}', date( 'd.m.Y H:i' ), $url );
            	$url = str_replace( '{reason}', rawurlencode( $core->lang['reasono'][ $changes['order_reason'] ? $changes['order_reason'] : $order['order_reason'] ] ), $url );
            	$url = str_replace( '{rcode}', $changes['order_reason'] ? $changes['order_reason'] : $order['order_reason'], $url );
            	$url = str_replace( '{price}', $changes['price_total'] ? $changes['price_total'] : $order['price_total'], $url );
            	$url = str_replace( '{count}', $changes['order_count'] ? $changes['order_count'] : $order['order_count'], $url );
            	$url = str_replace( '{cash}', $wmp ? $wmp : '', $url );
            	$url = str_replace( '{mobile}', $order['order_mobile'], $url );
            	$url = str_replace( '{ip}', int2ip( $o['order_ip'] ), $url );
            	foreach ( $offer as $k => $v ) $url = str_replace( "{offer:$k}", $v, $url );
            	if ( $odata ) foreach ( $odata as $k => $v ) $url = str_replace( "{data:$k}", $v, $url );
            	if ( $ometa ) foreach ( $ometa as $k => $v ) $url = str_replace( "{meta:$k}", $v, $url );
              	file_get_contents( $url );
        	}

		}

		// PostBack processing
		if ( $order['flow_id'] && $changes['order_webstat'] && $order['order_webstat'] < 5 ) {			if ( $pbu = $core->wmsale->get( 'flow', $order['flow_id'], 'flow_pbu' ) ) {

				$pbu = html_entity_decode( $pbu );
				if ( substr( $pbu, 0, 5 ) == 'POST:' ) {					$post = true;
					$pbu = substr( $pbu, 5 );
				} else $post = false;

				$stp = $changes['order_webstat'] ? $changes['order_webstat'] : $order['order_webstat'];
				if (preg_match_all( '#\{stage\:([^}]+)\}#', $pbu, $ms )) {
					foreach ( $ms[0] as $i => $m ) {
						$stl = explode( '|', $ms[1][$i] );
						$sti = $stl[$stp-1];
						$pbu = str_replace( $m, $sti, $pbu );
					}
				}

				$pbd = array(
					'id'		=> $order['order_id'],
					'offer'		=> $order['offer_id'],
					'flow'		=> $order['flow_id'],
					'target'	=> $order['target_id'],
					'site'		=> $order['site_id'],
					'space'		=> $order['space_id'],
            		'mobile'	=> $order['order_mobile'],
					'date'		=> $order['order_time'],
            		'ip'		=> int2ip( $o['order_ip'] ),
					'geo'		=> $changes['order_country'] ? $changes['order_country'] : $order['order_country'],
					'count'		=> $changes['order_count'] ? $changes['order_count'] : $order['order_count'],
					'price'		=> $changes['price_total'] ? $changes['price_total'] : $order['price_total'],
	            	'cash'		=> $wmp ? $wmp : '',
					'status'	=> $stp,
					'reason'	=> $changes['order_reason'] ? $changes['order_reason'] : $order['order_reason'],
					'utms'		=> $order['utms'],
					'utmc'		=> $order['utmc'],
					'utmn'		=> $order['utmn'],
					'utmt'		=> $order['utmt'],
					'utmm'		=> $order['utmm'],
				);

				foreach ( $pbd as $pbk => $pbv ) $pbu = str_replace( '{'.$pbk.'}', $pbv, $pbu );
				if ( $post ) {
					curl( $pbu, $pbd );
				} else curl( $pbu );

			}
		}

		return true;

	} else return false;

}

// lib-end. =)