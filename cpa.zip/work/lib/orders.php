<?php

/*******************************************************************************

 *
 * 	AlterVision Core Framework - CPA platform
 * 	Created by AlterVision - altervision.me
 *  Copyright © 2014-2017 Anton Reznichenko
 *

 *
 *  File: 			lib / orders.php
 *  Description:	Order processing
 *  Author:			Anton 'AlterVision' Reznichenko - altervision13@gmail.com
 *

*******************************************************************************/

// Load common library
require_once PATH_LIB . 'order-edit.php';

//
// Orders control
//

// Take order
function order_take ( $core, $id = 0 ) {
	$id = (int) $id;
	if ( ! $id ) {

    	// Can't take orders without company or team
		if ( ! $core->user->comp ) return false;
		$tm = time();
		$mt = $tm - 60;
		$u = $core->user->id;
		$c = $core->user->comp;

		// Take my order already in process
    	$id = $core->db->field( "SELECT order_id FROM ".DB_ORDER." WHERE comp_id = '$c' AND user_id = '$u' AND order_status = 2 AND ( mark_time < '$mt' OR mark_id = '$u' ) LIMIT 1" );
    	if ( $id ) return $id;

    	// Take new order
    	$id = $core->db->field( "SELECT order_id FROM ".DB_ORDER." WHERE comp_id = '$c' AND user_id = 0 AND order_status = 1 AND ( mark_time < '$mt' OR mark_id = '$u' ) LIMIT 1" );
		if ( $id ) order_edit( $core, $id, array( 'user' => $u, 'status' => 2 ) );
    	if ( $id ) return $id;

		// Take my order in recalls
    	$id = $core->db->field( "SELECT order_id FROM ".DB_ORDER." WHERE comp_id = '$c' AND user_id = '$u' AND order_status IN ( 3, 4 ) AND order_recall < '$tm' AND ( mark_time < '$mt' OR mark_id = '$u' ) ORDER BY RAND() LIMIT 1" );
    	if ( $id ) return $id;

		// Take any order in recalls
    	$id = $core->db->field( "SELECT order_id FROM ".DB_ORDER." WHERE comp_id = '$c' AND order_status IN ( 3, 4 ) AND order_recall < '$tm' AND ( mark_time < '$mt' OR mark_id = '$u' ) ORDER BY RAND() LIMIT 1" );
    	if ( $id ) return $id;

    	// Take any order in process
    	$id = $core->db->field( "SELECT order_id FROM ".DB_ORDER." WHERE comp_id = '$c' AND order_status = 2 AND ( mark_time < '$mt' OR mark_id = '$u' ) ORDER BY RAND() LIMIT 1" );
		return $id ? $id : false;

	} else {
		// Take the order by ID
     	$uid = $core->db->field( "SELECT user_id FROM ".DB_ORDER." WHERE order_id = '$id' LIMIT 1" );
     	if ( $uid ) return false;
		order_edit( $core, $id, array( 'user' => $core->user->id, 'status' => 2 ) );
		return $id;

	}

}

// Takable order counts
function order_counts ( $core ) {
   	// Can't take orders without company or team
	$c = $core->user->comp;
	if ( ! $c ) return false;
	$tm = time();
	$mt = $tm - 60;
	$u = $core->user->id;

	$oc = array(
		1 => $core->db->field("SELECT COUNT(*) FROM ".DB_ORDER." WHERE comp_id = '$c' AND order_status = 1 AND ( mark_time < '$mt' OR mark_id = '$u' )"),
		2 => $core->db->field("SELECT COUNT(*) FROM ".DB_ORDER." WHERE comp_id = '$c' AND order_status = 2 AND ( mark_time < '$mt' OR mark_id = '$u' )"),
		3 => $core->db->field("SELECT COUNT(*) FROM ".DB_ORDER." WHERE comp_id = '$c' AND order_status IN ( 3, 4 ) AND order_recall < '$tm' AND ( mark_time < '$mt' OR mark_id = '$u' )"),
	);

	$ot = array_sum( $oc );
	if ( $ot ) {
        $os = array();
		if ( $oc[1] ) $os[] = numinf( $core->lang['ordercount1'], $oc[1] );
		if ( $oc[2] ) $os[] = numinf( $core->lang['ordercount2'], $oc[2] );
		if ( $oc[3] ) $os[] = numinf( $core->lang['ordercount3'], $oc[3] );
		$os = implode( ' ', $os );
	} else $os = $core->lang['ordercount0'];

	return array(
		'counts'	=> $oc,
		'line'		=> $os,
		'total'		=> $ot,
	);

}

// Notification processing
function order_footer ( $core ) {
	$core->tpl->load( 'notify', 'notify' );
	$core->tpl->vars( 'notify', array(
		'url'	=> $core->url( 'a', 'order-notify', 0 ) . '?prev=',
		'ourl'	=> $core->url( 'm', 'orders' ),
		'prev'	=> time(),
		'text'	=> $core->lang['order_notify'],
		'text2'	=> $core->lang['order_notify2'],
	));
	$core->tpl->output( 'notify' );

}

//
// Public processing functions
//

// Menu
function order_menu ( $core, $menu ) {
	if ( $core->user->work == 1 ) {		$core->enque_css( 'notifIt' );
		$core->enque_js( 'jquery' );
		$core->enque_js( 'notifIt' );
		$core->handle( 'footer', 'order_footer' );
	}

	$menu[] = 'order';
	if ( $core->user->work == 1 ) $menu[] = 'offers';
	return $menu;

}

// Actions processing
function order_action ( $core ) {
	$action = ( $core->get['a'] ) ? $core->get['a'] : null;
	$id		= ( $core->post['id'] ) ? (int) $core->post['id'] : ( ($core->get['id']) ? (int) $core->get['id'] : 0 );

	switch ( $action ) {

	  case 'order-notify':

		$tm = time();
		$prev = (int) $core->get['prev'];
		if ( $core->user->comp ) {
			echo json_encode(array(
				'previous'	=> $tm,
				'ords'		=> $core->db->field( "SELECT COUNT(*) FROM ".DB_ORDER." WHERE order_status = 1 AND order_time >= '$prev' AND comp_id = '".$core->user->comp."'" ),
				'recs'		=> $core->db->field( "SELECT COUNT(*) FROM ".DB_ORDER." WHERE order_status IN ( 3, 4 ) AND order_recall BETWEEN '$prev' AND '$tm' AND comp_id = '".$core->user->comp."'" ),
			));
		} else echo 'false';
	  	$core->_die();

	  case 'order-callcount':

		echo json_encode(order_counts( $core ));
	  	$core->_die();

	  case 'order-dp':

		if ( $dc = $core->lang['deliverc'][$id] ) {
			include PATH . 'lib/delivery/'.$dc.'.php';
			$dcn = $dc . '_delivery';
			$dco = new $dcn ( $core );

			$info = $dco->calc(array(
				'comp'		=> (int) $core->post['comp'],
				'price'		=> (int) $core->post['price'],
				'country'	=> $core->text->link( $core->post['country'] ),
				'index'		=> (int) $core->post['index'],
				'area'		=> $core->text->line( $core->post['area'] ),
				'city'		=> $core->text->line( $core->post['city'] )
			));

			unset( $dco );

		} else $info = array( 'status' => 'error' );

	  	echo json_decode( $info );
	  	$core->_die();

	  case 'order-addr':

		require_once PATH_LIB . 'addr.php';
		$addr = $core->post['addr'] ? $core->text->line( $core->post['addr'] ) : $core->text->line( $core->get['addr'] );
		echo checkaddr( $addr );
	  	$core->_die();

	  case 'order-vkarea':

		$c = $core->text->link( $core->get['c'] );
		$q = $core->text->line( $core->get['q'] );

		$result = '';
		if ( mb_strlen( $q ) > 1 && $ci = $core->lang['vkcid'][$c] ) {			$data = json_decode( file_get_contents( "https://api.vk.com/method/database.getRegions?count=10&country_id=$ci&q=$q" ), true );
			if ( $data['response'] ) foreach ( $data['response'] as $r ) $result .= '<a href="#" onclick="return sr(this);">'.$r['title'].'</a>';
		}

		echo $result;
		$core->_die();

	  case 'order-vkcity':

		$c = $core->text->link( $core->get['c'] );
		$q = $core->text->line( $core->get['q'] );

		$result = '';
		if ( mb_strlen( $q ) > 1 && $ci = $core->lang['vkcid'][$c] ) {			$data = json_decode( file_get_contents( "https://api.vk.com/method/database.getCities?count=10&country_id=$ci&q=$q" ), true );
			if ( $data['response'] ) foreach ( $data['response'] as $r ) {				$region = trim( $r['region'] );
				$city = $pcity = trim( $r['title'] );
				if ( $r['area'] ) {					$pcity = trim( $r['area'] ) . ', ' . $city;
					$city .= ', ' . trim( $r['area'] );
				}
				if ( $region ) $city .= ', ' . $region;
				$region = addslashes( $region );
				$pcity = addslashes( $pcity );
				$result .= '<a href="#" onclick="return sc(\''.$pcity.'\',\''.$region.'\');">'.$city.'</a>'."\n";
			}
		}

		echo $result;
	  	$core->_die();

	  case 'order-phone':

		$phone = preg_replace( '#([^0-9]+)#', '', $core->get['phone'] );
		$ptc = substr( $phone, 1, 6 );
		$data = $core->db->row( "SELECT * FROM ".DB_PDB." WHERE `phone` = '$ptc' LIMIT 1" );
		if ( $data ) {
			$place = $data['region'];
			if ( $data['city'] ) $place .= ', ' . $data['city'];			printf( '%s (%s)', $data['operator'], $place  );
		}

	  	$core->_die();

	  case 'order-move':
	  	$comp = (int) $core->post['comp'];
		if ( $core->user->level && $comp && order_edit( $core, $id, array( 'comp' => $comp ) )) {
			msgo( $core, 'move' );
		} else msgo( $core, 'nomove' );

	  case 'order-pickup':
		if ( $oid = order_take( $core, $id ) ) {			$core->go($core->url( 'i', 'order', $oid ));
		} else $core->go($core->url( 'm', 'order', 'pickup' ));

	  case 'order-send':
		$code = $core->text->line( $core->post['code'] );
		if (order_edit( $core, $id, array( 'status' => 8, 'track' => $code ) )) {
			msgo( $core, 'send' );
		} else msgo( $core, 'nocode' );

	  case 'order-packed':
		if (order_edit( $core, $id, array( 'status' => 7 ) )) {
			msgo( $core, 'pack' );
		} else msgo( $core, 'error' );

	  case 'order-arrive':
		if (order_edit( $core, $id, array( 'status' => 9 ) )) {
			msgo( $core, 'arrive' );
		} else msgo( $core, 'error' );

	  case 'order-done':
		if (order_edit( $core, $id, array( 'status' => 10 ) )) {
			msgo( $core, 'done' );
		} else msgo( $core, 'error' );

	  case 'order-return':
		if (order_edit( $core, $id, array( 'status' => 11 ) )) {
			msgo( $core, 'done' );
		} else msgo( $core, 'error' );

	  case 'order-reset':
		if (order_edit( $core, $id, array( 'status' => 12 ) )) {
			msgo( $core, 'done' );
		} else msgo( $core, 'error' );

	  case 'order-promo-acc':
		if ( $core->db->query( "UPDATE ".DB_ORDER." SET promo_status = 1 WHERE order_id = '$id' LIMIT 1" ) ) {
			msgo( $core, 'done' );
		} else msgo( $core, 'error' );

	  case 'order-promo-dec':
		if ( $core->db->query( "UPDATE ".DB_ORDER." SET promo_status = 2 WHERE order_id = '$id' LIMIT 1" ) ) {
			msgo( $core, 'done' );
		} else msgo( $core, 'error' );

	  case 'order-edit':

		$changes = array();
		$order = $core->db->row( "SELECT * FROM ".DB_ORDER." WHERE order_id = '$id' LIMIT 1" );
		$status = $order['order_status'];
		$ct = $core->wmsale->get( 'comp', $order['comp_id'], 'comp_type' );

		// Basic order info
		if (isset( $core->post['name'] ))	$changes['name']	= $core->text->line( $core->post['name'] );
		if (isset( $core->post['phone'] ))	$changes['phone']	= preg_replace( '#([^0-9]+)#', '', $core->post['phone'] );
		if (isset( $core->post['comment'] )) $changes['comment'] = $core->text->line( $core->post['comment'] );

		// Address info
		if (isset( $core->post['country'] ))$changes['country']	= $core->text->link( $core->post['country'] );
		if (isset( $core->post['addr'] ))	$changes['addr']	= $core->text->line( $core->post['addr'] );
		if (isset( $core->post['area'] ))	$changes['area']	= $core->text->line( $core->post['area'] );
		if (isset( $core->post['city'] ))	$changes['city']	= $core->text->line( $core->post['city'] );
		if (isset( $core->post['street'] ))	$changes['street']	= $core->text->line( $core->post['street'] );
		if (isset( $core->post['index'] ))	$changes['index']	= (int) $core->post['index'];
		if (isset( $core->post['track'] ))	$changes['track']	= $core->text->line( $core->post['track'] );

		// Item delivery and counts
		if (isset( $core->post['curr'] )) 	  $changes['curr'] = 	 (int) $core->post['curr'];
		if (isset( $core->post['discount'] )) $changes['discount'] = (int) $core->post['discount'];
		if (isset( $core->post['delivery'] )) $changes['delivery'] = (int) $core->post['delivery'];
		if (isset( $core->post['delpr'] )) 	  $changes['delpr'] = 	 (int) $core->post['delpr'];
		if (isset( $core->post['more'] )) 	  $changes['more'] = 	 (int) $core->post['more'];
		if (isset( $core->post['base'] )) {
			if (is_array( $core->post['base'] )) {
				$changes['base'] = array();
				foreach ( $core->post['base'] as $i => $c ) if ( $c = (int) $c ) $changes['base'][ (int) $i ] = $c;
			} else $changes['base'] = (int) $core->post['base'];
		}
		if (isset( $core->post['counts'] )) {
			if (is_array( $core->post['counts'] )) {
				$changes['counts'] = array();
				foreach ( $core->post['counts'] as $i => $c ) if ( $c = (int) $c ) $changes['counts'][ (int) $i ] = $c;
			} else $changes['counts'] = (int) $core->post['counts'];
		}

		// Meta data
		if ( isset( $core->post['meta'] ) && is_array( $core->post['meta'] ) ) {			$changes['meta'] = array();
			foreach ( $core->post['meta'] as $k => $v ) $changes['meta'][$k] = stripslashes( $v );
		}

		// Call length
		if ( isset( $core->post['start'] ) && $st = (int) $core->post['start'] ) {			$ln = time() - $st;
			if ( $ln < 3600 ) $changes['length'] = $ln;
		}

		// Check for status
		$act = $core->text->link( $core->post['act'] );
		switch ( $status ) {
		  case 2: case 3: case 4: // Order accept progress
			if ( $act ) $changes['calls'] = 1;
    		if ( $act == 'accept' ) {    			$changes['accept'] = 1;
    			if ( $ct ) $changes['comp'] = (int) $core->post['comp'];
			}
    		if ( $act == 'cancel' ) {				$changes['status'] = 5;
				$changes['reason'] = (int) $core->post['reason'];
    		}
    		if ( $act == 'recall' || $act == 'nocall' ) {
    			$changes['status'] = ( $act == 'recall' ) ? 3 : 4;
    			$rcd = date2form(form2date( $core->post['rcdate'] ));
				$changes['rec'] = $rcd ? strtotime(sprintf( '%s %02d:%02d', $rcd, (int) $core->post['rchour'], (int) $core->post['rcmins'] )) : strtotime( '+15 minutes' );
    		}
    		break;

		  case 5:
			if ( $act == 'accept' ) $changes['accept'] = 1;
			if ( $act == 'process' ) $changes['status'] = 2;
			break;

		  case 6: // Packing
			if ( $act == 'done' )		$changes['status'] = 7;
			if ( $act == 'cancel' ) {
				$changes['status'] = 5;
				$changes['reason'] = (int) $core->post['reason'];
    		}
		  	break;

		  case 7: // Sending
			if ( $act == 'done' )		$changes['status'] = 8;
			if ( $act == 'back' )		$changes['status'] = 6;
			if ( $act == 'cancel' ) {
				$changes['status'] = 5;
				$changes['reason'] = (int) $core->post['reason'];
    		}
		  	break;

		  case 8: case 9: // Delivery and payment
			if ( $act == 'done' )		$changes['status'] = $status + 1;
			if ( $act == 'return' )		$changes['status'] = 11;
			if ( $act == 'back' )		$changes['status'] = $status - 1;
		  	break;

		}

		// Checks and controls of orders
		if ( $core->post['check'] ) $changes['check'] = 1;
		if ( $core->post['uncheck'] ) $changes['check'] = 0;

		// Saving order data
		if ( order_edit ( $core, $id, $changes, $order ) ) {

			// Processing bans
			if ( $core->post['banip'] || $core->post['banphone'] ) {				require_once PATH . 'lib/ban.php';
				if ( $core->post['banip'] ) ban_ip( $core, $order['order_ip'], true );
				if ( $core->post['banphone'] ) ban_phone( $core, $order['order_phone'] );
			}

			// Processing order cancels
			if ( $core->post['delip'] || $core->post['delphone'] ) {				$sql = "SELECT order_id FROM ".DB_ORDER." WHERE order_id != '".$order['order_id']."' AND order_status < 5 AND comp_id = '".$order['comp_id']."'";
				if ( $core->post['delip'] ) $sql .= " AND order_ip = '".$order['order_ip']."'";
				if ( $core->post['delphone'] ) $sql .= " AND order_phone = '".$order['order_phone']."'";
				$ids = $core->db->col( $sql );
				foreach ( $ids as $i ) order_edit( $core, $i, array( 'status' => 5, 'reason' => 7 ) );
			}

			// Order save competed, returning back
			if ( $core->post['next'] ) {
				$core->go($core->url( 'a', 'order-pickup', '' ));
			} else $core->go( $core->post['r'] ? $core->post['r'] : $core->url( 'mm', 'order', 'save' ) );

		} else $core->go($core->url( 'im', 'order', $id, 'oerror' ));

	  case 'order-prices':

		$c = (int) $core->get['curr'];
		$o = $core->wmsale->get( 'offer', $id );
		$p = $o['offer_prt'] ? unserialize( $o['offer_prt'] ) : array();

		$price = array(
			'base'	=> (int) $p[$c],
			'delpr'	=> (int) $core->lang['deliverbase'][$c],
			'vars'	=> array(),
		);

		if ( $o['offer_vars'] ) {			$v = $core->wmsale->get( 'vars', $id );
			foreach ( $v as $vv ) {				$vp = $vv['var_price'] ? unserialize( $vv['var_price'] ) : array();
				$price['vars'][] = array( (int) $vv['var_id'], (int) $vp[$c] );
			}
		}

		echo json_encode( $price );
		$core->_die();

	  case 'order-bulk':

		$st = $core->text->link( $_POST['status'] );
		if ( $st == 'accept' ) {			$ch = array( 'accept' => 1 );
		} elseif ( substr( $st, 0, 6 ) == 'status' ) {
			$st = (int) substr( $st, 6 );
			$ch = array( 'status' => $st );
		} elseif ( substr( $st, 0, 6 ) == 'cancel' ) {
			$st = (int) substr( $st, 6 );
			$ch = array( 'status' => 5, 'reason' => $st );
		} else msgo( $core, 'error' );

		foreach ( $_POST['ids'] as $i ) if ( $i = (int) $i ) order_edit ( $core, $i, $ch );
		msgo( $core, 'save' );

	  case 'order-script':

		$o = $core->wmsale->get( 'offer', $id, 'offer_call' );
		$o = preg_replace( '#\[block\=\"(.*?)\"\]#si', '<div class="callscript-block"><a href="#" class="plusi" onclick="$(this).next().toggle(); return false;">$1</a><div class="csbin" style="display:none;">', $o );
		$o = str_replace( '[/block]', '</div></div>', $o );
		echo '<div class="callscript">'.$o.'</div>';
	  	$core->_die();

	  case 'order-mark':

		$o = $core->db->row( "SELECT order_status, order_ip, order_phone FROM ".DB_ORDER." WHERE order_id = '$id' LIMIT 1" );
		switch ( $o['order_status'] ) {			case 1: case 2: case 3: case 4:
				$st = '1,2,3,4'; break;
			case 6: case 7:
				$st = '6,7'; break;
			default: $st = $o['order_status'];
		}
		$core->db->query( "UPDATE ".DB_ORDER." SET mark_id = '".$core->user->id."', mark_time = '".time()."' WHERE order_status IN ( $st ) AND order_phone = '".$o['order_phone']."'" );
	  	$core->_die();

	  case 'track-info':

		$order = $core->db->row( "SELECT * FROM ".DB_ORDER." WHERE order_id = '$id' LIMIT 1" );
		if ( $order['track_code'] ) {

			$core->tpl->load( 'track', 'track' );
			$core->tpl->vars( 'track', array( 'id' => $id ) );

			if ( $dc = $core->lang['deliverc'][$order['order_delivery']] ) {
				include PATH . 'lib/delivery/'.$dc.'.php';
				$dcn = $dc . '_delivery';
				$dco = new $dcn ( $core );
				$info = $dco->info( $order['track_code'] );
				unset ( $dco );
			} else $info = array();

			foreach ( $info as $i ) {
				$core->tpl->block( 'track', 'place', array(
                   	'date'		=> $i['date'] . ( $i['time'] ? ' ' . $i['time'] : '' ),
                   	'status'	=> $i['status'],
                   	'city'		=> $i['city'],
				));
			}

			$core->tpl->output( 'track' );

		}
	  	$core->_die();

	}

	return false;

}

// Module processing
function order_module ( $core ) {
	$module	= ( $core->get['m'] ) ? $core->get['m'] : null;
	$id		= ( $core->post['id'] ) ? (int) $core->post['id'] : ( ($core->get['id']) ? (int) $core->get['id'] : 0 );
	$page	= ( $core->get['page'] > 0 ) ? (int) $core->get['page'] : 1;
	$message = ( $core->get['message'] ) ? $core->get['message'] : null;

	if ( $module == 'offers' ) {
		require_once PATH_LIB . 'offers.php';
		offers ( $core );
	}

	if ( $module && $module != 'order' ) return false;

	switch ( $message ) {
    	case 'save':		$core->info( 'info', 'done_order_save' ); break;
    	case 'send':		$core->info( 'info', 'done_order_send' ); break;
    	case 'pack':		$core->info( 'info', 'done_order_pack' ); break;
    	case 'done':		$core->info( 'info', 'done_order_done' ); break;
    	case 'arrive':		$core->info( 'info', 'done_order_arrive' ); break;
    	case 'del':			$core->info( 'info', 'done_order_del' ); break;
    	case 'pickup':		$core->info( 'error', 'error_order_pickup' ); break;
    	case 'nocode':		$core->info( 'error', 'error_order_nocode' ); break;
    	case 'error':		$core->info( 'error', 'error_order_smth' ); break;
    	case 'oerror':		$core->info( 'error', 'error_order_save' ); break;
    	case 'access':		$core->info( 'error', 'access_denied' ); break;
	}

	// Edit order
	if ( $id ) {
		order_module_one( $core, $id );
	} else order_module_list( $core, $page );

    $core->_die();

}

function order_module_list( $core, $page ) {
	$where = $param = array();

	// Company filter
	if ( $core->user->level ) {
		if ( $c = (int) $core->get['c'] ) {
			$param['c'] = $c;
			$where[] = "comp_id = '$c'";
		} else $c = false;
	} else {
		if ( $core->wmsale->get( 'comp', $core->user->comp, 'comp_type' ) ) {
			$where[] = "( comp_id = '".$core->user->comp."' OR cc_id = '".$core->user->comp."' )";
		} else $where[] = "comp_id = '".$core->user->comp."'";
		$manager = $core->wmsale->get( 'mans', $core->user->comp );
	}

	// WebMaster
	if ( $wm = (int) $core->get['wm'] ) {
		$param['wm'] = $wm;
		$where[] = "wm_id = '$wm'";
	}

	// Source
	if ( $src = $core->text->link( $core->get['src'] ) ) {
		$param['src'] = $src;
		$where[] = "ext_src = '$src'";
	}

	// Search
	if ( isset( $core->get['s'] ) && $core->get['s'] ) {
		$s = $core->text->line( $core->get['s'] );
		if ( preg_match( '#^([0-9]+)\.([0-9]+)\.([0-9]+)\.([0-9]+)$#i', $s ) && $ips = ip2int( $s ) ) {
           	$where[] = " order_ip = '$ips' ";
		} elseif ( preg_match( '#^[0-9]{11}$#i', $s ) ) {
           	$where[] = " order_phone = '$s' ";
		} else {

			// Search by ID
			if ( is_numeric( $core->get['s'] ) && $oid = (int) $core->get['s'] ) {
				$oid = $core->db->field( "SELECT order_id FROM ".DB_ORDER." WHERE order_id = '$oid' LIMIT 1" );
				if ( $oid ) $core->go($core->url( 'i', 'order', $oid ));
			}

			// Basic search
			require_once PATH_CORE . 'search.php';
			$search = new SearchWords( $core->get['s'] );
			if ( $s = $search->get() ) {
				$where[] = $search->field(array( 'order_name', 'order_phone', 'order_addr', 'order_street', 'order_city', 'order_area', 'ext_uid', 'ext_oid' ));
			} else $s = false;

		}
		$param['s'] = $s;
	} else $s = false;

	// Offer filtering
	if ( $o = (int) $core->get['o'] ) {
		$param['o'] = $o;
		$where[] = "offer_id = '$o'";
	}

	// Date filtering
	if ( $from = $core->get['from'] ) {
		$dd = explode( '-', $from );
		$ds = mktime( 0, 0, 0, $dd[1], $dd[2], $dd[0] );
		$param['from'] = $from;
		$where[] = "order_time > '$ds'";
	} else $from = false;
	if ( $to = $core->get['to'] ) {
		$dd = explode( '-', $to );
		$de = mktime( 23, 59, 59, $dd[1], $dd[2], $dd[0] );
		$param['to'] = $to;
		$where[] = "order_time < '$de'";
	} else $to = false;

	// Status current ID
	if ( isset( $core->get['f'] ) && $core->get['f'] != '' ) {
		$f = (int) $core->get['f'];
		$param['f'] = $f;
	} else {
		$fs = array();
		if ( $core->wmsale->team( 'call' ) ) $fs[] = 100;
		if ( $core->wmsale->team( 'pack' ) ) $fs[] = 6;
		if ( $core->wmsale->team( 'send' ) ) $fs[] = 7;
		if ( $core->wmsale->team( 'delivery' ) ) $fs[] = 101;
		$f = ( count( $fs ) == 1 ) ? $fs[0] : -1;
	}

	// Status filtering
	if ( $f != '' ) {
		if ( $f > 99 || $f < 0 ) {
			switch ( $f ) {
				case 100:	$where[] = "order_status > 0 AND order_status < 6"; break;
				case 101:	$where[] = "order_status IN ( 8, 9 )"; break;
				case 102:	$where[] = "order_check = 1"; break;
				case 103:	$where[] = "order_status = 10 AND promo_code != 0 AND promo_status = 0"; break;
			}
		} else $where[] = "order_status = '$f'";
	}

	$where = count( $where ) ? ' WHERE ' . implode( ' AND ', $where ) : '';

	$csv = ( $core->get['mode'] == 'csv' ) ? 1 : 0;
	if ( ! $csv ) {
		$sh = 20; $st = $sh * ( $page - 1 );
		$orders = $core->db->field( "SELECT COUNT(*) FROM ".DB_ORDER.$where );
		$order = $orders ? $core->db->data( "SELECT * FROM ".DB_ORDER." $where ORDER BY order_status ASC, order_id DESC LIMIT $st, $sh" ) : false;
	} else $order = $core->db->data( "SELECT * FROM ".DB_ORDER." $where ORDER BY order_status ASC, order_time DESC" );

	$company = $core->user->comp ? $core->wmsale->get( 'comp', $core->user->comp ) : false;
	$offer = $core->wmsale->get( 'offers' );
	$vars = array();

	$core->mainline->add( $core->lang['orders_h'], $core->url( 'm', 'order' ) );
    if ( ! $csv ) $core->header ();

	$core->tpl->load( 'body', $csv ? 'csv-orders' : 'orders', defined('HACK_TPL_ORDERS') ? HACK : false );

    $core->tpl->vars ('body', array (

		'offer'			=> $core->lang['offer'],
		'phone'			=> $core->lang['phone'],
		'name'			=> $core->lang['username'],
		'company'		=> $core->lang['company'],
		'address'		=> $core->lang['address'],
		'time'			=> $core->lang['time'],
		'price'			=> $core->lang['price'],
		'status'		=> $core->lang['status'],
		'action'		=> $core->lang['action'],
		'pay'			=> $core->lang['pay'],
		'edit'			=> $core->lang['edit'],
		'del'			=> $core->lang['del'],
		'date'			=> $core->lang['date'],
		'save'			=> $core->lang['save'],
		'confirm'		=> $core->lang['confirma'],
		'call_confirm'	=> $core->lang['order_call_confirm'],
		'call_default'	=> $core->lang['order_call_action'],
		'call_ok'		=> $core->lang['order_call_ok'],
		'call_re'		=> $core->lang['order_call_re'],
		'call_no'		=> $core->lang['order_call_no'],
		'packed'		=> $core->lang['order_packed'],
		'packdocs'		=> $core->lang['order_pack_docs'],
		'pack_confirm'	=> $core->lang['order_pack_confirm'],
		'track_code'	=> $core->lang['track_code'],
		'track_send'	=> $core->lang['track_send'],
		'track_confirm'	=> $core->lang['track_confirm'],
		'info'			=> $core->lang['inf'],
		'work'			=> $core->lang['order_work'],
		'pack'			=> $core->lang['order_pack'],
		'cancel'		=> $core->lang['order_cancel'],
		'later'			=> $core->lang['order_later'],
		'showall'		=> $core->lang['order_showall'],

		// Pick order up
		'pickup'		=> $core->lang['order_pick_up'],
		'pickupany'		=> $core->lang['order_pick_smth'],
		'pick_confirm'	=> $core->lang['order_pick_confirm'],
		'o_pickup'		=> $core->lang['order_pick_up_smth'],

		// Promo Codes
		'promo_accept'		=> $core->lang['promo_accept'],
		'promo_decline'		=> $core->lang['promo_decline'],
		'promo_confirma'	=> $core->lang['promo_confirma'],
		'promo_confirmd'	=> $core->lang['promo_confirmd'],

		// Links
		'u_check'		=> $core->url( 'a', 'order-callcount', '' ),
		'u_pickup'		=> $core->url( 'a', 'order-pickup', '' ),
		'u_csv'			=> $core->url( 'm', '?' ) . parset( $param, 'mode', 'csv' ),
		'u_bulk'		=> $core->url( 'a', 'order-bulk', '' ),

		// Search, filters and pages
		'filter'		=> $core->lang['filter'],
		'search'		=> $core->lang['search'],
		'find'			=> $core->lang['find'],
		'from'			=> $from,
		'to'			=> $to,
		's'				=> $search ? $search->get() : $s,
		'wm'			=> $wm,
		'src'			=> $src,
		'pages'			=> pages ( $core->url( 'm', '?' ) . http_build_query( $param ), $orders, $sh, $page ),
		'shown'			=> sprintf( $core->lang['shown'], $st+1, min( $st+$sh, $orders ), $orders ),

    ));

    if ( $core->user->work < 2 ) $core->tpl->block( 'body', 'pickitup', order_counts( $core ) );

	// Status simple list
	foreach ( $core->lang['statuso'] as $i => $st ) {
		$core->tpl->block( 'body', 'status', array(
			'name'		=> $st,
			'value'		=> $i,
			'select'	=> ( $f != '' && $f == $i ) ? 'selected="selected"' : '',
		));
	}

	// Status large list
	foreach ( $core->lang['statusl'] as $i => $st ) {
		$core->tpl->block( 'body', 'statuslist', array(
			'id'		=> $i,
			'name'		=> $st,
			'url'		=> $core->url( 'm', 'order?' ) . parset( $param, 'f', $i ),
			'cls'		=> ( $f == $i ) ? 'fat' : '',
		));
	}

	// Decline reasons
	foreach ( $core->lang['reasono'] as $i => $st ) {
		$core->tpl->block( 'body', 'reason', array(
			'name'		=> $st,
			'value'		=> $i,
		));
	}

	$comp = $core->wmsale->get( 'comps' );
	if ( $ccss = $core->wmsale->get( 'ccs' ) ) $comp += $ccss;
	if ( $core->user->level ) {
		$core->tpl->block( 'body', 'comps' );
		foreach ( $comp as $ci => $cn ) {
			$core->tpl->block( 'body', 'comps.c', array(
				'name'		=> $cn,
				'value'		=> $ci,
				'select'	=> ( $c == $ci ) ? 'selected="selected"' : '',
			));
		}
	}

	foreach ( $offer as $i => $of) {
		$core->tpl->block( 'body', 'offer', array(
			'name'		=> $of,
			'value'		=> $i,
			'select'	=> ( $o == $i ) ? 'selected="selected"' : '',
		));
	}

	$mxmt = time() - 60;
	$callscheme = ( $callscheme = $core->wmsale->get( 'comp', $core->user->comp, 'callscheme' ) ) ? $callscheme : 'tel:+%s';
	if ( $order ) foreach ( $order as &$r ) {

		// Delivery address
		$addr = $r['order_addr'];
		if ( $r['order_street'] ) $addr = $r['order_street'] . ', ' . $addr;
		if ( $r['order_city'] ) $addr = $r['order_city'] . ', ' . $addr;
		if ( $r['order_area'] ) $addr = $r['order_area'] . ', ' . $addr;
		if ( $r['order_index'] ) $addr = $r['order_index'] . ', ' . $addr;
		$addr = trim( $addr, ', ' );

		// User ID
		$uid = $r['wm_id'];
		$user = $uid ? $core->user->get( $uid ) : array();

		// User name or info
		if ( $core->user->work == 2 ) {
			$uname = $user['user_name'];
			if (!($r['ext_id'] || $user['user_vip'] )) $uname = $core->text->cut( $user['user_mail'], 20 );
		} else $uname = $r['wm_id'];

		// User marks and manager
		if ( $r['mark_time'] > $mxmt ) {
			$mngr = $manager[$r['mark_id']];
			$mrcl = 'order-boss';
			$mrkr = ( $r['mark_id'] == $core->user->id ) ? '<abbr title="'.date( 'd.m.Y H:i:s', $r['mark_time'] ).'" class="accept green">Моё!</abbr>' : '<abbr title="'.date( 'd.m.Y H:i:s', $r['mark_time'] ).'" class="warn red">Занят</abbr>';
		} else {
			$mrkr = false;
			$mrcl = 'order-user';
			$mngr = $manager[$r['user_id']];
		}

		// Basic order block
		$core->tpl->block( 'body', 'ord', array(

			'oid'			=> $r['offer_id'],
			'offer'			=> $offer[$r['offer_id']],
			'id'			=> $r['order_id'],
			'ip'			=> int2ip( $r['order_ip'] ),
			'country'		=> $r['order_country'] ? $r['order_country'] : ( $r['geoip_country'] ? $r['geoip_country'] : 'zz' ),
			'name'			=> $search ? $search->highlight( $r['order_name'] ) : $r['order_name'] ,
			'addr'			=> $search ? $search->highlight( $addr ) : $addr,
			'comment'		=> $r['order_comment'],
			'phone'			=> $search ? $search->highlight( $r['order_phone'] ) : $r['order_phone'],
			'phone_call'	=> sprintf( $callscheme, $r['order_phone'] ),
			'count'			=> $r['order_count'],
			'price'			=> cur( $r['price_total'], $r['price_cur'] ),
			'price_csv'		=> (int) $r['price_total'],
			'time'			=> smartdate( $r['order_time'] ),
			'stid'			=> $r['order_status'],
			'status'		=> $core->lang['statuso'][$r['order_status']],
			'mrkr'			=> $mrkr,
			'edit'			=> $core->url ( 'i', 'order', $r['order_id'] ),
			'actcls'		=> ( $r['order_status'] == 1 || $r['order_status'] == 7 ) ? 'fld' : '',
			'manager'		=> $mngr,
			'mrcl'			=> $mrcl,
			'paid'			=> $r['paid_ok'],
			'paidinfo'		=> $core->lang['order_paid'][$r['paid_ok']] . ( $r['paid_time'] ? ' - '.smartdate( $r['paid_time'] ) : '' ),
			'calls'			=> ( $r['order_calls'] ) ? sprintf( ' <small title="%s" class="red">(%s)</small>', $core->lang['order_calls'], $r['order_calls'] ) : '',
			'delivery'		=> $r['order_delivery'],
			'delivern'		=> $core->lang['delivers'][$r['order_delivery']],
			'uid'			=> $uid,
			'uname'			=> $uid ? ( $user['user_level'] ? '<b>'.$uname.'</b>' : $uname ) : $core->lang['order_src_sh'],
			'uclass'		=> $r['order_check'] ? 'warn' : ( $uid ? ( $r['ext_id'] ? 'ext' : ( $user['user_vip'] ? 'vip' : 'user' ) ) : 'search' ),
			'extu'			=> $r['ext_uid'],
			'exts'			=> $r['ext_src'],

		));

		// Order picking up
		if ( $r['order_status'] == 1 ) {
			$core->tpl->block( 'body', 'ord.pickup', array( 'u' => $core->url( 'a', 'order-pickup', $r['order_id'] ) ) );
			if ( $core->user->level ) {
               	$core->tpl->block( 'body', 'ord.pickup.move', array( 'u' => $core->url( 'a', 'order-move', $r['order_id'] ) ) );
				foreach ( $comp as $v => $n )  $core->tpl->block( 'body', 'ord.pickup.move.comp', array( 'val' => $v, 'name' => $n ));
			}
		}

		// Order call-center
		if ( $r['order_status'] > 1 && $r['order_status'] < 5 ) {
			$ncls = 'grey';
			if ( $r['order_recall'] ) {
				$ncls = 'fat red';
				if ( $next = $core->text->timeleft( $r['order_recall'] ) ) {
					$next = sprintf( $core->lang['call_next_in'], $next );
					$tl = $r['order_recall'] - time();
					$ncls = ( $tl > 600 ) ? 'green' : 'yellow';
				} else $next = $core->text->smartdate( $r['order_recall'] );
			} else $next = $core->lang['call_next_no'];
			$core->tpl->block( 'body', 'ord.next', array( 'cls' => $ncls, 'text' => $next ) );
		}

		// Cancel reason and comments
		if ( $r['order_status'] == 5 ) {			$core->tpl->block( 'body', 'ord.cancel', array(
				'reason' => $r['order_reason'] ? $core->lang['reasono'][$r['order_reason']] : (
					$r['order_comment'] ? sprintf( $core->lang['noreason_comment'], $r['order_comment']
				) : $core->lang['noreason'] )
			));
		}

		if ( $r['order_status'] == 6 ) {
			$items = $r['order_items'] ? unserialize( $r['order_items'] ) : false;
			$iline = '';
			if ( $items ) {
				if (!count( $vars[$r['offer_id']] )) {
					$vrs = $core->wmsale->get( 'vars', $r['offer_id'] );
					$vars[$r['offer_id']] = array(); foreach ( $vrs as $w ) $vars[$r['offer_id']][ $w['var_id'] ] = $w['var_short'];
				}
				foreach ( $items as $k => $x ) $iline .= ' ' . $vars[$r['offer_id']][$k] . ': ' . $x[0] . ' ';
			}
			$core->tpl->block( 'body', 'ord.pack', array( 'docs' => $core->url( 'a', 'order-docs', $r['order_id'] ), 'done' => $core->url( 'a', 'order-packed', $r['order_id'] ), 'items' => $iline ));
			if ( $r['order_delivery'] == 1 ) $core->tpl->block( 'body', 'ord.pack.doc' );
		}

		if ( $r['order_status'] == 7 ) {
			$core->tpl->block( 'body', 'ord.send', array(
				'u' => $core->url( 'a', 'order-send', $r['order_id'] )
			));
		}

		// Delivery processing
		if ( $r['order_status'] == 8 || $r['order_status'] == 9 || $r['order_status'] == 11 ) {
			$core->tpl->block( 'body', 'ord.track', array(
				'cls'		=> $r['track_status'] ? ( ($r['order_status'] == 9) ? 'green' : 'blue' ) : 'red',
				'check'		=> sprintf( $core->lang['track_check'], smartdate( $r['track_check'] ) ),
				'info'		=> ( $r['track_status'] ) ? sprintf( "%s: %s", $r['track_date'], $r['track_status'] ) : $core->lang['track_wait'],
				'url'		=> sprintf( $core->lang['deliveru'][$r['order_delivery']], $r['track_code'] ),
			));
			if ( $r['order_status'] == 8 ) $core->tpl->block( 'body', 'ord.track.confirm', array( 'c' => $core->lang['order_arrive_conf'], 't' => $core->lang['order_arrived'], 'u' => $core->url( 'a', 'order-arrive', $r['order_id'] ) ) );
			if ( $r['order_status'] == 9 ) $core->tpl->block( 'body', 'ord.track.confirm', array( 'c' => $core->lang['order_payd_conf'], 't' => $core->lang['order_payd'], 'u' => $core->url( 'a', 'order-done', $r['order_id'] ) ) );
		}

		// Promo codes
		if ( $r['order_status'] == 10 && $r['promo_code'] && $r['promo_status'] == 0 ) {			$core->tpl->block( 'body', 'ord.promo', array(
				'accept'	=> $core->url( 'a', 'order-promo-acc', $r['order_id'] ),
				'decline'	=> $core->url( 'a', 'order-promo-dec', $r['order_id'] ),
				'code'		=> $r['promo_code'],
				'phone'		=> depromo( $r['promo_code'] ),
			));
		}

		if ( $core->user->level ) {
			$core->tpl->block( 'body', 'ord.comp', array( 'id' => $r['comp_id'], 'name' => $comp[$r['comp_id']] ));
		} else $core->tpl->block( 'body', 'ord.ip' );

	} else $core->tpl->block( 'body', 'noord' );
	unset ( $r, $order );

	if ( $csv ) {
   		header( 'Content-type: text/csv; charset=windows-1251' );
   		header( 'Content-disposition: attachment; filename=orders.csv' );
		$core->tpl->output( 'body', 'windows-1251//IGNORE' );
	} else {
		$core->tpl->output( 'body' );
		$core->footer ();
	}


}

function order_module_one ( $core, $id ) {
	// Order, offer and variants
	$order = $core->db->row( "SELECT * FROM ".DB_ORDER." WHERE order_id = '$id' LIMIT 1" );
	if ( $core->user->level < 1 ) if ( $order['comp_id'] != $core->user->comp && $order['cc_id'] != $core->user->comp ) $core->go($core->url( 'mm', '', 'access' ));
	$offer = $core->wmsale->get( 'offer', $order['offer_id'] );
	$comp = $core->wmsale->get( 'comp', $order['comp_id'] );
	$site = $order['site_id'] ? $core->wmsale->get( 'site', $order['site_id'], 'site_url' ) : false;
	$space = $order['space_id'] ? $core->wmsale->get( 'site', $order['space_id'], 'site_url' ) : false;
	$vars = $offer['offer_vars'] ? $core->wmsale->get( 'vars', $offer['offer_id'] ) : false;
	$oips = $core->db->field( "SELECT COUNT(*) FROM ".DB_ORDER." WHERE order_ip = '".$order['order_ip']."'" . ( $core->user->level ? '' : " AND comp_id = '".$order['comp_id']."'" ) );
	$ophs = $core->db->field( "SELECT COUNT(*) FROM ".DB_ORDER." WHERE order_phone = '".$order['order_phone']."'" . ( $core->user->level ? '' : " AND comp_id = '".$order['comp_id']."'" ) );
	$order['items'] = $order['order_items'] ? unserialize( $order['order_items'] ) : array();
	$user = $order['wm_id'] ? $core->user->get( $order['wm_id'] ) : array();
	$callscheme = ( $callscheme = $core->wmsale->get( 'comp', $core->user->comp, 'callscheme' ) ) ? $callscheme : 'tel:+%s';

	$ophone = $core->db->row( "SELECT * FROM ".DB_PDB." WHERE `phone` = '".substr( $order['order_phone'], 1, 6 )."' LIMIT 1" );
	if ( $ophone ) {
		$ophone['type'] = $ophone['operator'];
		$ophone['place'] = $ophone['region'];
		if ( $ophone['city'] ) $ophone['place'] .= ', ' . $ophone['city'];
	}

	$addr = $order['order_addr'];
	if ( $order['order_street'] ) $addr = $order['order_street'] . ', ' . $addr;
	if ( $order['order_city'] ) $addr = $order['order_city'] . ', ' . $addr;
	if ( $order['order_area'] ) $addr = $order['order_area'] . ', ' . $addr;

	// Store
/*	if ( $vars ) {
       	$store = array();
       	$stores = $core->db->data( "SELECT var_id, store_count FROM ".DB_STORE." WHERE offer_id = '".$order['offer_id']."' AND comp_id = '".$order['comp_id']."'" );
       	foreach ( $stores as $s ) $store[$s['var_id']] = $s['store_count'];
	} else $store = (int) $core->db->field( "SELECT store_count FROM ".DB_STORE." WHERE offer_id = '".$order['offer_id']."' AND comp_id = '".$order['comp_id']."' LIMIT 1" );  */

	// Parameters
	if ( $offer['offer_paramurl'] && $order['order_meta'] ) {
		$cache = sprintf( PATH_CACHE, md5( $order['order_meta'] ) );
		if ( !file_exists( $cache ) ) {
			$post = unserialize( $order['order_meta'] );
			$form = curl( $offer['offer_paramurl'], $post );
			file_put_contents( $cache, $form );
		} else $form = file_get_contents( $cache );
	} else $form = null;

	// GeoIP
	if ( $order['geoip_country'] ) {
		$geoip = $order['geoip_city'] ? $order['geoip_city'] : '';
		if ( $order['geoip_region'] ) $geoip .= ', ' . $order['geoip_region'];
		if ( $order['geoip_district'] ) $geoip .= ', ' . $order['geoip_district'];
		$geoip = trim( $geoip, ', ' );
       	if ( $geoip && $order['geoip_lat'] && $order['geoip_lng'] ) $geoip = '<a target="_blank" href="http://maps.yandex.ru/?ll='.$order['geoip_lng'].'%2C'.$order['geoip_lat'].'">'.$geoip.'</a>';
	}

	// Bans and complains
	require_once PATH . 'lib/ban.php';
	$banip = check_ip_bans( $core, array( $order['order_ip'] ) );
	$banip = $banip ? end( $banip ) : false;
	$banph = check_phone_bans( $core, array( $order['order_phone'] ) );
	$banph = $banph ? end( $banph ) : false;

	// Contents ability
	if ( $order['order_status'] > 1 && $order['order_status'] < 5 ) {
		$canedit = $core->wmsale->team( 'call' ) || $core->wmsale->team( 'mod' );
	} elseif ( $order['order_status'] == 6 ) {
		$canedit = $core->wmsale->team( 'pack' ) || $core->wmsale->team( 'mod' );
	} else $canedit = false;

	// Info ability
	if ( $order['order_status'] > 1 && $order['order_status'] < 5 ) {
		$caninfo = $core->wmsale->team( 'call' ) || $core->wmsale->team( 'mod' );
	} elseif ( $order['order_status'] == 5 ) {
		$caninfo = $core->wmsale->team( 'admin' ) || $core->wmsale->team( 'mod' );
	} elseif ( $order['order_status'] == 6 ) {
		$caninfo = $core->wmsale->team( 'pack' ) || $core->wmsale->team( 'mod' );
	} elseif ( $order['order_status'] == 7 ) {
		$caninfo = $core->wmsale->team( 'send' ) || $core->wmsale->team( 'mod' );
	} elseif ( $order['order_status'] > 7 && $order['order_status'] < 10 ) {
		$caninfo = $core->wmsale->team( 'delivery' ) || $core->wmsale->team( 'mod' );
	} else $caninfo = false;

	// Callcenter readonly
	if ( $core->wmsale->get( 'comp', $core->user->comp, 'comp_type' ) ) {
		if ( $order['comp_id'] != $core->user->comp ) $canedit = $caninfo = false;
	}

	// Markings
	$mxmt = time() - 60;
	if ( $order['mark_time'] > $mxmt && $order['mark_id'] != $core->user->id ) {
		$core->info( 'error', sprintf ( $core->lang['order_marked'], $core->user->get( $order['mark_id'], 'user_name' ), date( 'H:i:s', $order['mark_time'] ) ) );
	} elseif ( $core->user->work == 1 && $caninfo ) $core->tpl->block( 'body', 'marker' );

	// Page Header
	$core->mainline->add( $core->lang['orders_h'], $core->url( 'm', 'order' ) );
	$core->mainline->add( $offer['offer_name'] );
	$core->mainline->add( $order['order_name'] );
    $core->header ();

	$core->tpl->load( 'body', 'order', defined('HACK_TPL_ORDER') ? HACK : false );
	$core->tpl->vars( 'body', $offer );
	$core->tpl->vars( 'body', $order );

	if ( $core->user->work == 2 ) {
		$uname = $user['user_name'];
		if (!($order['ext_id'] || $user['user_vip'] )) $uname = $core->text->cut( $user['user_mail'], 20 );
	} else $uname = $order['wm_id'];

	$core->tpl->vars( 'body', array(

		'u_edit'			=> $core->url( 'a', 'order-edit', $id ),
		'u_addr'			=> $core->url( 'a', 'order-addr', 0 ),
		'u_phone'			=> $core->url( 'a', 'order-phone', 0 ) . '?phone=',
		'u_price'			=> $core->url( 'a', 'order-prices', $order['offer_id'] ) . '?curr=',
		'u_script'			=> $core->url( 'a', 'order-script', $order['offer_id'] ),
		'u_mark'			=> $core->url( 'a', 'order-mark', $id ),

		'start'				=> time(),
		'order'				=> $core->lang['order'],
		'save'				=> $core->lang['order_save'],
		'next'				=> $core->lang['order_save_next'],
		'action'			=> $core->lang['order_work_action'],
		'mark'				=> $core->lang['order_marks'],
		'source'            => $core->lang['source'],
		'comp'				=> $core->lang['company'],
		'site'            	=> $core->lang['site'],
		'space'            	=> $core->lang['stat_spaces'],
		'store'				=> $core->lang['store'],
		'count'				=> $core->lang['count'],
		'price'				=> $core->lang['price'],
		'more_price'		=> $core->lang['order_more'],
		'total'				=> $core->lang['total'],
		'name'				=> $core->lang['name'],
		'fio'				=> $core->lang['username'],
		'address'			=> $core->lang['address'],
		'address_d'			=> $core->lang['order_addr_d'],
		'street'			=> $core->lang['street'],
		'city'				=> $core->lang['city'],
		'area'				=> $core->lang['area'],
		'phone'				=> $core->lang['phone'],
		'index'				=> $core->lang['index'],
		'call'				=> $core->lang['call'],
		'track'				=> $core->lang['track'],
		'checkaddr'			=> $core->lang['order_checkaddr'],
		'delivery'			=> $core->lang['deliver'],
		'discount'			=> $core->lang['discount'],
		'promo_code'		=> $core->lang['promo_code'],
		'promo_code_d'		=> $core->lang['promo_code_d'],
		'promo_status'		=> $core->lang['promo_code_s'],

		'country'			=> $order['order_country'] ? $order['order_country'] : ( $order['geoip_country'] ? $order['geoip_country'] : 'zz' ),
		'vkcid'				=> json_encode( $core->lang['vkcid'] ),
		'geoip'				=> $geoip,
		'geoip_cname'		=> $core->lang['country'][$order['geoip_country']],
		'form'				=> $form,
		'status'			=> $core->lang['statuso'][$order['order_status']],
		'date'				=> smartdate( $order['order_time'] ),
		'fulladdr'			=> $addr,
		'r'					=> $core->server['HTTP_REFERER'],
		'site_url'			=> $site,
		'space_url'			=> $space,
		'comp_name'			=> $comp['comp_name'],

		'callscheme'		=> $callscheme,
		'phone_call'		=> sprintf( $callscheme, $order['order_phone'] ),
		'phone_info'		=> $ophone ? sprintf( "%s (%s)", $ophone['type'], $ophone['place'] ) : '',

		'paid_type'			=> $core->lang['order_paid'][$order['paid_ok']],
		'paid_date'			=> smartdate( $order['paid_time'] ),
		'paid_info'			=> $core->text->lines( $order['paid_from'] ),

		'order_ip'			=> int2ip( $order['order_ip'] ),
		'order_mobile'		=> $order['order_mobile'] ? $core->lang['order_mobile'] : false,
		'order_bad'			=> $order['order_bad'] ? $core->lang['order_bad'] : false,
		'ipwarn'			=> ( $oips > 1 ) ? numinf( $core->lang['order_others'], $oips ) : false,
		'ipwarnu'			=> $core->url( 'm', 'order?s=' ) . int2ip( $order['order_ip'] ),
		'ipban'				=> $banip ? numinf( $core->lang['order_warns'], $banip ) : false,
		'phwarn'			=> ( $ophs > 1 ) ? numinf( $core->lang['order_others'], $ophs ) : false,
		'phwarnu'			=> $core->url( 'm', 'order?s=' ) . $order['order_phone'],
		'phban'				=> $banph ? numinf( $core->lang['order_warns'], $banph ) : false,

		'wm_name'			=> $order['wm_id'] ? ( $user['user_level'] ? '<b>'.$uname.'</b>' : $uname ) : $core->lang['order_src_sh'],
		'wm_class'			=> $order['wm_id'] ? ( $order['ext_id'] ? 'ext' : ( $user['user_ban'] ? 'warn' : ( $user['user_warn'] ? 'ua' : ( $user['user_vip'] ? 'vip' : 'user' )) ) ) : 'search',

		// Promo Codes
		'promo_accept'		=> $core->lang['promo_accept'],
		'promo_decline'		=> $core->lang['promo_decline'],
		'promo_confirma'	=> $core->lang['promo_confirma'],
		'promo_confirmd'	=> $core->lang['promo_confirmd'],

	));

	// Spacer landing
	if ( $site ) $core->tpl->block( 'body', 'site' );
	if ( $space ) $core->tpl->block( 'body', 'space' );
	if ( $form ) $core->tpl->block( 'body', 'form' );
	if ( $order['paid_ok'] ) $core->tpl->block( 'body', 'paid' );
	if ( $order['order_file'] ) $core->tpl->block( 'body', 'file' );

	foreach ( $core->lang['country'] as $cc => $cn ) {
		$core->tpl->block( 'body', 'cosel', array(
			'code'	=> $cc,
			'vk'	=> $core->lang['vkcid'][$cc],
			'name'	=> $cn,
			'sel'	=> ( $cc == $order['order_country'] ) ? 'selected="selected"' : '',
		));
	}

	// Promo codes
	if (defined( 'PROMO' )) {
		$core->tpl->block( 'body', 'promocode', array( 'text' => enpromo( $order['order_phone'] ) ) );
		if ( $order['promo_code'] ) {
			$core->tpl->block( 'body', 'promostatus', array(
				'code'		=> $order['promo_code'],
				'phone'		=> depromo( $order['promo_code'] ),
				'stid'		=> $order['promo_status'],
				'status'	=> $core->lang['promo_status'][$order['promo_status']],
				'accept'	=> $core->url( 'a', 'order-promo-acc', $order['order_id'] ),
				'decline'	=> $core->url( 'a', 'order-promo-dec', $order['order_id'] ),
			));
			if ( $order['order_status'] == 10 && $order['promo_status'] == 0 ) $core->tpl->block( 'body', 'promostatus.action' );
		}
	}

	// Abilities
	if ( $canedit ) {
		$core->tpl->block( 'body', 'edit' );
		if ( $offer['offer_delivery'] ) $core->tpl->block( 'body', 'edit.delivery' );
		if ( $offer['offer_line'] ) $core->tpl->vars( 'body', array( 'line' => $offer['offer_line'] ) );
	} else $core->tpl->block( 'body', 'view' );
	$core->tpl->block( 'body', $caninfo ? 'editinfo' : 'viewinfo' );

	// Variants of offer
	if ( $vars ) {
		$ndprice = 0;
		$vtype = 3;
		$items = $order['order_items'] ? unserialize( $order['order_items'] ) : array();
		foreach ( $vars as $v ) {

			if ( $vtype != $v['var_type'] ) {
				$core->tpl->block( 'body', 'items', array( 'name' => $core->lang['varstype'][$v['var_type']] ) );
				$vtype = $v['var_type'];
			}

			$vpr = $v['var_price'] ? unserialize( $v['var_price'] ) : array();
			$ipr = isset( $items[$v['var_id']][1] ) ? $items[$v['var_id']][1] : $vpr[$order['price_cur']];

           	$core->tpl->block( 'body', 'items.item', array(
				'id'		=> $v['var_id'],
				'name'		=> $v['var_name'],
				'single'	=> $v['var_single'],
				'base'		=> $ipr,
				'count'		=> (int) $items[$v['var_id']][0],
				'total'		=> $ipr * (int) $items[$v['var_id']][0],
           	));

           	if ( $canedit ) $core->tpl->block( 'body', 'items.item.edit' ); else $core->tpl->block( 'body', 'items.item.view' );
			$ndprice += $ipr * (int) $items[$v['var_id']][0];

		}
	} else {
		$core->tpl->block( 'body', 'single', array(
			'name'		=> $offer['offer_name'],
			'total'		=> $order['price_base'] * (int) $order['order_count'],
		));
		if ( $canedit ) $core->tpl->block( 'body', 'single.edit' ); else $core->tpl->block( 'body', 'single.view' );
		$ndprice = $order['price_base'] * (int) $order['order_count'];
	}

	// Discounts
	if ( $canedit ) {
		$core->tpl->block( 'body', 'dcedit', array( 'total'	=> $ndprice * ( (100 - $order['order_discount']) / 100 ) ) );
		foreach ( $core->lang['discounts'] as $i => $n ) {
			$core->tpl->block( 'body', 'dcedit.line', array(
				'id'	=> $i,
            	'name'	=> $n,
            	'check'	=> ( $i == $order['order_discount'] ) ? 'selected="selected"' : '',
			));
		}
	} else $core->tpl->block( 'body', 'dcview', array(
		'name'	=> $core->lang['discounts'][$order['order_discount']],
		'total'	=> $ndprice * ( (100 - $order['order_discount']) / 100 ),
	));

	// Delivery
	if ( $offer['offer_delivery'] ) {
		$core->tpl->block( 'body', 'delivery', array( 'name' => $core->lang['delivery'][$order['order_delivery']] ) );
		if ( $canedit ) {
			$core->tpl->block( 'body', 'delivery.edit' );
			foreach ( $core->lang['delivery'] as $i => $n ) {
				$core->tpl->block( 'body', 'delivery.edit.line', array(
					'id'	=> $i,
	            	'name'	=> $n,
	            	'price'	=> $core->lang['deliverp'][$i],
	            	'check'	=> ( $i == $order['order_delivery'] ) ? 'selected="selected"' : '',
				));
			}
		} else $core->tpl->block( 'body', 'delivery.view' );
	}

	// Currency
	if ( $canedit ) {
		foreach ( $core->lang['price_cur'] as $i => $n ) {
           	$core->tpl->block( 'body', 'edit.curr', array(
           		'id'	=> $i,
           		'name'	=> $n,
           		'check'	=> ( $i == $order['price_cur'] ) ? 'selected="selected"' : ''
           	));
		}
	}

	// Tracking code
	if ( $caninfo && ( $order['order_status'] == 7 || $order['order_status'] == 8 ) ) $core->tpl->block( 'body', 'track' );
	if ( ( $order['order_status'] > 7 && $order['order_status'] < 10 ) || $order['order_status'] == 11 ) $core->tpl->block( 'body', 'delpro', array(
		'cls'		=> $order['track_status'] ? ( ($order['order_status'] == 9) ? 'green' : 'blue' ) : 'red',
		'check'		=> sprintf( $core->lang['track_check'], smartdate( $order['track_check'] ) ),
		'info'		=> ( $order['track_status'] ) ? sprintf( "%s: %s", $order['track_date'], $order['track_status'] ) : $core->lang['track_wait'],
		'url'		=> sprintf( $core->lang['deliveru'][$order['order_delivery']], $order['track_code'] ),
	));

	// Actions
	$actns = false;
	if ( $caninfo ) {

		if ( $order['order_status'] > 1 && $order['order_status'] < 5 ) {

			// Accept order
			$core->tpl->block( 'body', 'accept', array( 'text' => $core->lang['order_accept'], 'to' => $core->lang['order_accept_to'] ));
			if ( $comp['comp_type'] ) {
				$ocmp = preg_split( '/[\s\,]+/', $offer['out_comps'], -1, PREG_SPLIT_NO_EMPTY );
				if ( $ocmp ) {
					$cmps = $core->wmsale->get( 'comps' );
					$core->tpl->block( 'body', 'accept.move' );
					foreach ( $cmps as $c => $n ) if (in_array( $c, $ocmp )) $core->tpl->block( 'body', 'accept.move.comp', array( 'v' => $c, 'n' => $n ));
				}
			}

			// Recall the order
			$rctime = strtotime( '+15 minutes' );
			$rcdate = date( 'Y-m-d', $rctime );
			$rchour = (int) date( 'H', $rctime );
			$rcmins = round( (int) date( 'i', $rctime ) / 5 ) * 5;
			$core->tpl->block( 'body', 'recall', array( 'next' => $core->lang['order_nextcall'], 'date' => $rcdate ) );
			$core->tpl->block( 'body', 'recall.type', array( 'v' => 'recall', 'n' => $core->lang['order_recall'] ) );
			$core->tpl->block( 'body', 'recall.type', array( 'v' => 'nocall', 'n' => $core->lang['order_nocall'] ) );
			for ( $a = 0; $a < 24; $a++ ) $core->tpl->block( 'body', 'recall.hour', array( 't' => sprintf( '%02d', $a ), 's' => $a == $rchour ) );
			for ( $a = 0; $a < 60; $a+=5 ) $core->tpl->block( 'body', 'recall.min', array( 't' => sprintf( '%02d', $a ), 's' => $a == $rcmins ) );

		} elseif ( $order['order_status'] == 5 ) {
			$actns = $core->lang['cancelo'];
		} elseif ( $order['order_status'] == 6 ) {
			$actns = $core->lang['packingo'];
		} elseif ( $order['order_status'] == 7 ) {
			$actns = $core->lang['sendingo'];
		} elseif ( $order['order_status'] == 8 ) {
			$actns = $core->lang['delivero'];
		} elseif ( $order['order_status'] == 9 ) {
			$actns = $core->lang['payo'];
		}

		// Cancel the order
		if ( $order['order_status'] > 1 && $order['order_status'] < 8 && $order['order_status'] != 5 ) {
			$core->tpl->block( 'body', 'cancel', array( 'text' => $core->lang['order_cancel_l'], 'reason' => $core->lang['order_reason'] ));
			foreach ( $core->lang['reasono'] as $v => $n ) $core->tpl->block( 'body', 'cancel.reason', array( 'v' => $v, 'n' => $n ) );
		}

		// Marks
		if ( $order['order_status'] > 1 && $order['order_status'] < 5 ) {

			$marks = array(
				'banip'		=> sprintf( $core->lang['order_ban_ip'], int2ip( $order['order_ip'] ) ),
				'banphone'	=> sprintf( $core->lang['order_ban_phone'], $order['order_phone'] ),
			);

			if ( $oips > 1 ) {
				$ooips = $core->db->field( "SELECT COUNT(*) FROM ".DB_ORDER." WHERE order_id != '$id' AND order_ip = '".$order['order_ip']."' AND order_status < 5 AND comp_id = '".$order['comp_id']."'" );
				if ( $ooips ) $marks['delip'] = sprintf( $core->lang['order_del_ip'], $ooips );
			}

			if ( $ophs > 1 ) {
				$oophs = $core->db->field( "SELECT COUNT(*) FROM ".DB_ORDER." WHERE order_id != '$id' AND order_phone = '".$order['order_phone']."' AND order_status < 5 AND comp_id = '".$order['comp_id']."'" );
				if ( $oophs ) $marks['delphone'] = sprintf( $core->lang['order_del_phone'], $oophs );
			}

		} else $marks = array();

		// Checking marks
		if ( $order['order_status'] > 1 && $order['order_status'] < 10 && $order['order_status'] != 5 ) {
			if ( $order['order_check'] ) {
				$marks['uncheck'] = $core->lang['order_uncheck'];
			} else $marks['check'] = $core->lang['order_tocheck'];
		}

		// Marks and actions block
		if ( $actns ) foreach ( $actns as $v => $n ) $core->tpl->block( 'body', 'action', array( 'n' => $n, 'v' => $v ) );
		if ( $marks ) foreach ( $marks as $v => $n ) $core->tpl->block( 'body', 'mark', array( 'n' => $n, 'v' => $v ) );
		$core->tpl->block( 'body', 'buttons' );

	}

	// Pick order button
	if ( $order['order_status'] == 1 ) $core->tpl->block( 'body', 'pickup', array(
		'u' => $core->url( 'a', 'order-pickup', $id ),
		't'	=> $core->lang['order_pick_up'],
		'c'	=> $core->lang['order_pick_confirm'],
	));

	// Order working log
	$log = $core->db->data( "SELECT * FROM ".DB_CALL." WHERE order_id = '$id' ORDER BY call_id ASC" );
	if ( $log ) {

		rsort( $log );
		$core->tpl->block( 'body', 'log', array(
			'title'		=> $core->lang['order_log'],
			'user'		=> $core->lang['user'],
			'status'	=> $core->lang['status'],
			'time'		=> $core->lang['date'],
			'next'		=> $core->lang['log_next'],
			'length'	=> $core->lang['log_length'],
		));

		foreach ( $log as $l ) {

			$u = $l['user_id'] ? $core->user->get( $l['user_id'], 'user_name' ) : false;
			if ( $l['call_length'] ) {
				if ( $l['call_length'] > 60 ) {
					$mm = floor( $l['call_length'] / 60 );
					$ss = $l['call_length'] % 60;
					$cl = sprintf( $core->lang['log_ms'], $mm, $ss );
				} else $cl = sprintf( $core->lang['log_sec'], $l['call_length'] );
			} else $cl = false;

			$core->tpl->block( 'body', 'log.row', array(
				'user'		=> $u ? $u : $core->lang['log_robot'],
				'type'		=> $u ? 'boss' : 'robot',
				'time'		=> smartdate( $l['call_time'] ),
				'next'		=> $l['call_next'] ? smartdate( $l['call_next'] ) : false,
				'status'	=> $core->lang['statuso'][$l['call_status']],
				'sclass'	=> $l['call_status'],
				'length'	=> $cl,
			));

		} unset ( $log, $l );

	}

	// Order changes log
	$chl = $core->db->data( "SELECT * FROM ".DB_CHANGE." WHERE order_id = '$id' ORDER BY change_id ASC" );
	if ( $chl ) {

       	rsort( $chl );
       	$core->tpl->block( 'body', 'chl', array(
			'title'		=> $core->lang['order_chl'],
			'user'		=> $core->lang['user'],
			'time'		=> $core->lang['time'],
			'changes'	=> $core->lang['order_changes'],
       	));

       	foreach ( $chl as $l ) {

			$u = $l['user_id'] ? $core->user->get( $l['user_id'], 'user_name' ) : false;
			$dd = unserialize( $l['change_data'] );

			$core->tpl->block( 'body', 'chl.row', array(
				'user'		=> $u ? $u : $core->lang['log_robot'],
				'type'		=> $u ? ( $l['change_warn'] ? 'warn red' : 'boss' ) : 'robot',
				'time'		=> smartdate( $l['change_time'] ),
			));

			foreach ( $dd as $n => $d ) {

				if ( $d != '' ) {
				if ( $n == 'comp_id' ) $d = $core->wmsale->get( 'comp', $d, 'comp_name' );
				if ( $n == 'order_country' ) $d = $core->lang['country'][$d];
				if ( $n == 'price_cur' ) $d = $core->lang['price_cur'][$d];
				if ( $n == 'order_delivery' ) $d = $core->lang['delivery'][$d];
				} else $d = $core->lang['no'];

				$core->tpl->block( 'body', 'chl.row.line', array( 'n' => $core->lang['changelogs'][$n], 'd' => $d ) );

			}

       	} unset ( $log, $l );

	}

	$core->tpl->output( 'body' );

	$core->footer ();

}