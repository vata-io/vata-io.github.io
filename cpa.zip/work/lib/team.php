<?php

/*******************************************************************************

 *
 * 	AlterVision Core Framework - CPA platform
 * 	Created by AlterVision - altervision.me
 *  Copyright � 2014-2015 Anton Reznichenko
 *

 *
 *  File: 			lib / team.php
 *  Description:	Team control panel
 *  Author:			Anton 'AlterVision' Reznichenko - altervision13@gmail.com
 *

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 2 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.

*******************************************************************************/

//
// Module functions
//

// Menu
function team_menu ( $core, $menu ) {	$menu['team'] = array( 'team', 'teambuild' );
	return $menu;
}

// Actions
function team_action ( $core ) {
	$action = ( $core->get['a'] ) ? $core->get['a'] : null;
	$id		= ( $core->post['id'] ) ? (int) $core->post['id'] : ( ($core->get['id']) ? (int) $core->get['id'] : 0 );
	$ci		= $core->user->comp;
	$ti		= $core->user->team;

	switch ( $action ) {

	  // Add new manager
	  case 'team-user-add':

		$name 	= $core->text->line ( $core->post['name'] );
		$email	= $core->text->email ( $core->post['email'] );
		$pass	= $core->text->pass ( trim( $core->post['pass'] ) );

		$uid = $core->db->field( "SELECT user_id FROM ".DB_USER." WHERE user_mail = '$email' LIMIT 1" );
		if ( ! $uid ) {

		    $sql = "INSERT INTO ".DB_USER." SET user_name = '$name', user_mail = '$email', user_pass = '$pass', user_work = 1, user_comp = '$ci', user_team = '$ti'";
		    if ( $name && $email && trim($core->post['pass']) && $core->db->query( $sql ) ) {
				$uid = $core->db->lastid();
				$core->wmsale->clear( 'mans', $core->user->comp );
				$core->wmsale->clear( 'allman' );
		        $core->go($core->url( 'im', 'teambuild', $uid, 'ok' ));
		    } else $core->go($core->url( 'mm', 'teambuild', 'error' ));

		} else $core->go($core->url( 'mm', 'teambuild', 'exists' ));

	  // Edit manager data
	  case 'team-user-edit':

		$user = $core->db->row( "SELECT * FROM ".DB_USER." WHERE user_id = '$id' LIMIT 1" );
		if ( $user['user_comp'] && $user['user_comp'] == $ci && $user['user_team'] == $ti ) {

			$email	= $core->text->email ( $core->post['email'] );
			if ( $email != $user['user_mail'] ) {
				$uid = $core->db->field( "SELECT user_id FROM ".DB_USER." WHERE user_mail = '$email' LIMIT 1" );
				if ( $uid ) $core->go($core->url( 'mm', 'teambuild', 'exists' ));
			}

			$data = array(
				'user_name'		=> $core->text->line ( $core->post['name'] ),
				'user_mail'		=> $email,
				'user_ban'		=> $core->post['ban'] ? 1 : 0,
				'user_teamlead'	=> $core->post['teamlead'] ? 1 : 0,
			);
			if ( $pass = trim( $core->post['pass'] ) ) $data['user_pass'] = $core->text->pass( $pass );
			if ( $data['user_ban'] && ( $id == $core->user->id || $user['user_compad'] ) ) $core->go($core->url( 'mm', 'teambuild', 'access' ));

		    if ( $core->user->set ( $id, $data ) ) {
				$core->wmsale->clear( 'mans', $core->user->comp );
				$core->wmsale->clear( 'allman' );
				$core->go($core->url( 'mm', 'teambuild', 'ok' ));
		    } else $core->go($core->url( 'mm', 'teambuild', 'error' ));

		} else $core->go($core->url( 'mm', 'teambuild', 'access' ));

	  // Deleting manager
	  case 'team-user-del':

		$user = $core->db->row( "SELECT * FROM ".DB_USER." WHERE user_id = '$id' LIMIT 1" );
		if ( $id != 1 && $id != $core->user->id && $user['user_comp'] == $ci && $user['user_team'] == $ti ) {
			$core->db->query( "DELETE FROM ".DB_CASH." WHERE user_id = '$id'" );
			if ( $core->db->query ( "DELETE FROM ".DB_USER." WHERE user_id = '$id'" ) ) {
				$core->wmsale->clear( 'mans', $core->user->comp );
				$core->wmsale->clear( 'allman' );
				$core->go($core->url( 'mm', 'teambuild', 'ok' ));
			} else $core->go($core->url( 'mm', 'teambuild', 'error' ));
		} else $core->go($core->url( 'mm', 'teambuild', 'access' ));

	}

	return false;

}

// Processing
function team_module ( $core ) {
	$module	= ( $core->get['m'] ) ? $core->get['m'] : null;
	$id		= ( $core->post['id'] ) ? (int) $core->post['id'] : ( ($core->get['id']) ? (int) $core->get['id'] : 0 );
	$page	= ( $core->get['page'] > 0 ) ? (int) $core->get['page'] : 1;
	$message = ( $core->get['message'] ) ? $core->get['message'] : null;

	$ci		= $core->user->comp;
	$ti		= $core->user->team;
	$comp 	= $core->wmsale->get( 'comp', $core->user->comp );

	switch ( $module ) {

	  // Team statictics
	  case 'team':

		require_once PATH_LIB . 'callstat.php';
		callstat ( $core, 'team', $ti );

	  // Team personel
	  case 'teambuild':

		switch ( $message ) {
	    	case 'ok':		$core->info( 'info', 'done_basic' ); break;
	    	case 'error':	$core->info( 'info', 'error_basic' ); break;
	    	case 'exists':	$core->info( 'error', 'error_user_exist' ); break;
	    	case 'access':	$core->info( 'error', 'access_denied' ); break;
		}

		if ( $id ) {

			$user = $core->db->row ( "SELECT * FROM ".DB_USER." WHERE user_id = '$id' LIMIT 1" );
			if ( $user['user_comp'] != $ci && $user['user_team'] != $ti ) $core->go($core->url( 'mm', 'teambuild', 'access' ));

		    $core->mainline->add ( $core->lang['team'], $core->url('m', 'team') );
		    $core->mainline->add ( $core->lang['personel'], $core->url('m', 'teambuild') );
			$core->mainline->add ( $user['user_name'] );
			$core->header ();

			$field 	= array(
				array( 'type' => 'text', 'length' => 100, 'name' => 'name', 'head' => $core->lang['user_name'], 'descr' => $core->lang['user_name_d'], 'value' => $user['user_name']),
				array( 'type' => 'text', 'length' => 100, 'name' => 'email', 'head' => $core->lang['user_email'], 'descr' => $core->lang['user_email_d'], 'value' => $user['user_mail']),
				array( 'type' => 'pass', 'length' => 32, 'name' => 'pass', 'head' => $core->lang['user_pass'], 'descr' => $core->lang['user_pass_d'] ),
				array( 'type' => 'checkbox', 'name' => 'teamlead', 'head' => $core->lang['user_teamlead'], 'descr' => $core->lang['user_teamlead_d'], 'checked' => $user['user_teamlead'] ),
				array( 'type' => 'checkbox', 'name' => 'ban', 'head' => $core->lang['user_ban'], 'descr' => $core->lang['user_ban_d'], 'checked' => $user['user_ban'] ),
			);
			$button = array(array('type' => 'submit', 'value' => $core->lang['save']));
			$core->form ('useredit', $core->url ( 'a', 'team-user-edit', $id ), 'post', $core->lang['user_edit'], $field, $button);

			$core->footer ();

		} else {

			$mans = $core->db->data( "SELECT * FROM ".DB_USER." WHERE user_team = '$ti' ORDER BY user_name ASC" );

		    $core->mainline->add ( $core->lang['team'], $core->url('m', 'team') );
		    $core->mainline->add ( $core->lang['personel'] );
		    $core->header ();

			$core->tpl->load( 'body', 'list', defined('HACK_TPL_LIST') ? HACK : false );

			$core->tpl->vars( 'body', array(
				'title'			=> $core->lang['team_personel_h'],
				'text'			=> $core->text->lines( $core->lang['team_personel_t'] ),
				'name'			=> $core->lang['name'],
				'info'			=> $core->lang['access'],
				'action'		=> $core->lang['action'],
				'level'			=> $core->lang['level'],
				'edit'			=> $core->lang['edit'],
				'del'			=> $core->lang['del'],
				'confirm'		=> $core->lang['confirm'],
			));

		    foreach ( $mans as &$i ) {

				if ( $i['user_ban'] ) {
					$level = '<b class="warn red">'.$core->lang['ban'].'</b>';
				} elseif ( $i['user_teamlead'] ) {
					$level = '<span class="boss">'.$core->lang['admin'].'</span>';
				} else $level = $core->lang['user_works'][1];

		        $core->tpl->block ( 'body', 'item', array (
		        	'id'		=> $i['user_id'],
		            'name'		=> $i['user_name'],
		            'more' 		=> '<a href="mailto:'.$i['user_mail'].'" class="small grey">'.$i['user_mail'].'</a>',
		            'info'		=> $level,
		            'url'		=> $core->url ( 'i', 'teambuild', $i['user_id'] ),
		            'edit'		=> $core->url ( 'i', 'teambuild', $i['user_id'] ),
		            'del'		=> $core->url ( 'a', 'team-user-del', $i['user_id'] ),
		        ));

		    } unset ( $i, $mans );

			$core->tpl->output( 'body' );

		    $title	= $core->lang['comp_user_add'];
		    $action	= $core->url ( 'a', 'team-user-add', '' );
		    $field 	= array(
	            array('type' => 'text', 'length' => 100, 'name' => 'name', 'head' => $core->lang['user_name'], 'descr' => $core->lang['user_name_d'] ),
	            array('type' => 'text', 'length' => 100, 'name' => 'email', 'head' => $core->lang['user_email'], 'descr' => $core->lang['user_email_d'] ),
	            array('type' => 'pass', 'length' => 32, 'name' => 'pass', 'head' => $core->lang['user_pass'], 'descr' => $core->lang['user_pass_d'] ),
		    );
		    $button = array(array('type' => 'submit', 'value' => $core->lang['create']));
		    $core->form ( 'useradd', $action, 'post', $title, $field, $button );

			$core->footer ();

		}

	  	$core->_die();

	}

	return false;

}

// lib-end. =)