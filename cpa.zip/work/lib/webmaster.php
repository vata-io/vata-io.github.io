<?php

/*******************************************************************************

 *
 * 	AlterVision Core Framework - CPA platform
 * 	Created by AlterVision - altervision.me
 *  Copyright © 2014-2017 Anton Reznichenko
 *

 *
 *  File: 			lib / webmaster.php
 *  Description:	WebMaster interface
 *  Author:			Anton 'AlterVision' Reznichenko - altervision13@gmail.com
 *

*******************************************************************************/

//
// Generic functions
//

// Adding new flow
function webmaster_flow_add ( $core, $user, $id, $name = '' ) {
	$offer = $core->wmsale->get( 'offer', $id );
	$lands = $core->wmsale->get( 'lands', $id );
	if ( $offer['offer_active'] ) {
       	if ( $core->db->add( DB_FLOW, array( 'user_id' => $user, 'offer_id' => $id, 'flow_name' => $name, 'flow_site' => $lands[0]['site_id'] ) ) ) {
			$oid = $core->db->lastid();
			if ( ! $name ) $core->db->edit( DB_FLOW, array( 'flow_name' => sprintf( "%s - %s", $offer['offer_name'], $oid ) ), "flow_id = '$oid'" );
			$core->wmsale->clear( 'flows', $user );
			return $oid;
       	} else return false;
	} else return -1;
}

// Edit flow data
function webmaster_flow_edit ( $core, $user, $id, $data ) {

	$edit = array();
	if (isset( $data['name'] ))		$edit['flow_name'] 	= $data['name'];
	if (isset( $data['site'] ))		$edit['flow_site'] 	= $data['site'];
	if (isset( $data['space'] ))	$edit['flow_space'] = $data['space'];
	if (isset( $data['cb'] ))		$edit['flow_cb'] 	= $data['cb'];
	if (isset( $data['param'] ))	$edit['flow_param'] = $data['param'];
	if (isset( $data['url'] ))		$edit['flow_url'] 	= $data['url'];
	if (isset( $data['pbu'] ))		$edit['flow_pbu'] 	= $data['pbu'];

	$fuser = $core->db->field( "SELECT user_id FROM ".DB_FLOW." WHERE flow_id = '$id' LIMIT 1" );
	if ( $user == $fuser ) {
		if ( $core->db->edit( DB_FLOW, $edit, "flow_id = '$id'" ) ) {
			$core->wmsale->clear( 'flow', $id );
			$core->wmsale->clear( 'flows', $user );
			return 1;
		} else return 0;
	} else return -1;

}

// Delete flow
function webmaster_flow_del ( $core, $user, $id ) {

	$fuser = $core->db->field( "SELECT user_id FROM ".DB_FLOW." WHERE flow_id = '$id' LIMIT 1" );
	if ( $user == $fuser ) {
		if ( $core->db->del( DB_FLOW, "flow_id = '$id'" ) ) {
			$core->db->edit( DB_ORDER, array( 'flow_id' => 0 ), "flow_id = '$id'" );
			$core->db->edit( DB_CLICK, array( 'flow_id' => 0 ), "flow_id = '$id'" );
			$core->db->del( DB_STATS, "flow_id = '$id'" );
			$core->wmsale->clear( 'flow', $id );
			$core->wmsale->clear( 'flows', $user );
			return 1;
		} else return 0;
	} else return -1;

}

// Clicks Statistics
function webmaster_clicks ( $core, $user, $from, $to, $f, $o ) {
	$today = date( 'Ymd' );
	$week1 = date( 'Ymd', strtotime( '-1 week' ) );
	$vip = $core->user->get( $user, 'user_vip' );

	$oids = $core->db->col( "SELECT DISTINCT offer_id FROM ".DB_FLOW." WHERE user_id = '$user'" );
	$oids = implode( ',', $oids );
	$price = array();
	if ( $core->user->level == 1 && $user == -1 ) {		$offer = $core->db->icol( "SELECT offer_id, offer_name FROM ".DB_OFFER." ORDER BY offer_name ASC" );
		$flow = $core->db->icol( "SELECT flow_id, flow_name FROM ".DB_FLOW.( $o ? " WHERE offer_id = '$o' " : '' )." ORDER BY flow_name ASC" );
	} else {		$offer = $oids ? $core->db->icol( "SELECT offer_id, offer_name FROM ".DB_OFFER." WHERE offer_id IN ( $oids ) ORDER BY offer_name ASC" ) : array();
		$flow = $core->db->icol( "SELECT flow_id, flow_name FROM ".DB_FLOW." WHERE user_id = '".$user."' ".( $o ? " AND offer_id = '$o' " : '' )." ORDER BY flow_name ASC" );
	}
	$flows = $f ? $f : implode( ', ', array_keys( $flow ) );

	$stats = array();
	if ( $flows ) {

		// Today statistics of clicks
		if ( $to == $today ) {
			$stats[$today] = $core->db->row( "SELECT COUNT(*) AS `clicks`, SUM(click_unique) AS `unique`, AVG(click_good) AS `time` FROM ".DB_CLICK." WHERE flow_id IN ( $flows ) AND click_date = '$today' AND click_space = 0" );
			$stats[$today]['good'] = $core->db->field( "SELECT COUNT(*) FROM ".DB_CLICK." WHERE flow_id IN ( $flows ) AND click_date = '$today' AND click_space = 0 AND click_good >= ".GOODCLICK );
			$stats[$today]['spaces'] = $core->db->field( "SELECT COUNT(*) FROM ".DB_CLICK." WHERE flow_id IN ( $flows ) AND click_date = '$today' AND click_space = 1" );
			$stats[$today]['suni'] = $core->db->field( "SELECT COUNT(*) FROM ".DB_CLICK." WHERE flow_id IN ( $flows ) AND click_date = '$today' AND click_space = 1 AND click_unique = 1" );
			$stats[$today]['sgood'] = $core->db->field( "SELECT COUNT(*) FROM ".DB_CLICK." WHERE flow_id IN ( $flows ) AND click_date = '$today' AND click_space = 1 AND click_good >= ".GOODCLICK );
			$stats[$today]['stime'] = $core->db->field( "SELECT AVG(click_good) FROM ".DB_CLICK." WHERE flow_id IN ( $flows ) AND click_date = '$today' AND click_space = 1" );
		}

		// Earlier statistics of clicks
		if ( $from < $today ) {
        	$sts = $core->db->data( "SELECT stat_date, SUM(stat_space) AS `spaces`, SUM(stat_suni) AS `suni`, SUM(stat_sgood) AS `sgood`, AVG(stat_stime) AS `stime`, SUM(stat_click) AS `clicks`, SUM(stat_unique) AS `unique`, SUM(stat_good) AS `good`, AVG(stat_time) AS `time` FROM ".DB_STATS." WHERE flow_id IN ( $flows ) AND stat_date BETWEEN '$from' AND '$to' GROUP BY stat_date" );
        	foreach ( $sts as $s ) $stats[$s['stat_date']] = $s;
			unset ( $sts, $s );
		}

		$ff = strtotime( date2form( $from ) . ' 00:00:00' );
		$tt = strtotime( date2form( $to ) . ' 23:59:59' );

		$orders = $core->db->start( "SELECT order_id, order_webstat, order_reason, order_time, offer_id, cash_wm FROM ".DB_ORDER." WHERE flow_id IN ( $flows ) AND order_time BETWEEN '$ff' AND '$tt'" );
		while ( $oo = $core->db->one( $orders ) ) {

           	if ( $oo['order_webstat'] < 5 ) {
           		$l = 'w';
           	} elseif ( $oo['order_webstat'] > 5 && $oo['order_webstat'] < 11 ) {
           		$l = 'a';
           	} elseif ( $oo['order_webstat'] == 12 || $oo['order_reason'] == 5 || $oo['order_reason'] == 6 || $oo['order_reason'] == 7 ) {				$l = 'x';
           	} else $l = 'c';
			$d = date( 'Ymd', $oo['order_time'] );

			if ( $stats[$d]['c'.$l] ) $stats[$d]['c'.$l] += 1; else $stats[$d]['c'.$l] = 1;
			if ( $stats[$d]['m'.$l] ) $stats[$d]['m'.$l] += $oo['cash_wm']; else $stats[$d]['m'.$l] = $oo['cash_wm'];
			if ( $l != 'x' ) {
				if ( $stats[$d]['ct'] ) $stats[$d]['ct'] += 1; else $stats[$d]['ct'] = 1;
				if ( $stats[$d]['mt'] ) $stats[$d]['mt'] += $oo['cash_wm']; else $stats[$d]['mt'] = $oo['cash_wm'];
			}

		} $core->db->stop( $orders );

		krsort( $stats );
		foreach ( $stats as $d => &$s ) $s['stat_date'] = $d;

	}

	return array( $offer, $flow, $stats );

}
// FlowStats Statistics
function webmaster_flowstat ( $core, $user, $from, $to ) {

	$offer = $core->wmsale->get( 'offers' );
	$flow = $core->wmsale->get( 'flows', $user );
	$flows = implode( ', ', array_keys( $flow ) );
	if ( ! $flow ) return false;

	// Counting spacing clicks
	$spaces = $core->db->icol( "SELECT flow_id, COUNT(*) FROM ".DB_CLICK." WHERE ( click_date BETWEEN '$from' AND '$to' ) AND flow_id IN ( $flows ) AND click_space = 1 GROUP BY flow_id" );
	$suni = $core->db->icol( "SELECT flow_id, COUNT(*) FROM ".DB_CLICK." WHERE ( click_date BETWEEN '$from' AND '$to' ) AND flow_id IN ( $flows ) AND click_space = 1 AND click_unique = 1 GROUP BY flow_id" );
	$sgood = $core->db->icol( "SELECT flow_id, COUNT(*) FROM ".DB_CLICK." WHERE ( click_date BETWEEN '$from' AND '$to' ) AND flow_id IN ( $flows ) AND click_space = 1 AND click_good >= ".GOODCLICK." GROUP BY flow_id" );
	$stm = $core->db->icol( "SELECT flow_id, AVG(click_good) FROM ".DB_CLICK." WHERE ( click_date BETWEEN '$from' AND '$to' ) AND flow_id IN ( $flows ) AND click_space = 1 GROUP BY flow_id" );

	// Counting landing clicks
	$clicks = $core->db->icol( "SELECT flow_id, COUNT(*) FROM ".DB_CLICK." WHERE ( click_date BETWEEN '$from' AND '$to' ) AND flow_id IN ( $flows ) AND click_space = 0 GROUP BY flow_id" );
	$unique = $core->db->icol( "SELECT flow_id, COUNT(*) FROM ".DB_CLICK." WHERE ( click_date BETWEEN '$from' AND '$to' ) AND flow_id IN ( $flows ) AND click_space = 0 AND click_unique = 1 GROUP BY flow_id" );
	$good = $core->db->icol( "SELECT flow_id, COUNT(*) FROM ".DB_CLICK." WHERE ( click_date BETWEEN '$from' AND '$to' ) AND flow_id IN ( $flows ) AND click_space = 0 AND click_good >= ".GOODCLICK." GROUP BY flow_id" );
	$tm = $core->db->icol( "SELECT flow_id, AVG(click_good) FROM ".DB_CLICK." WHERE ( click_date BETWEEN '$from' AND '$to' ) AND flow_id IN ( $flows ) AND click_space = 0 GROUP BY flow_id" );

	// Processing
	$stats = array();
	foreach ( $flow as $i => $f ) {
		$oid = $core->wmsale->get( 'flow', $i, 'offer_id' );
		$stats[$i] = array(
			'id' => $i, 'flow' => $f, 'offer' => $offer[$oid], 'oid' => $oid,
			'space' => $spaces[$i], 'suni'  => $suni[$i], 'sgood'  => $sgood[$i], 'stime'  => $stm[$i],
			'clicks' => $clicks[$i], 'unique'  => $unique[$i], 'good'  => $good[$i], 'time'  => $tm[$i]
		);
	}

	// Counting orders
	$ff = strtotime( date2form( $from ) . ' 00:00:00' );
	$tt = strtotime( date2form( $to ) . ' 23:59:59' );

	$orders = $core->db->start( "SELECT order_id, order_webstat, order_reason, flow_id, cash_wm FROM ".DB_ORDER." WHERE order_time BETWEEN '$ff' AND '$tt' AND flow_id IN ( $flows )" );
	while ( $oo = $core->db->one( $orders ) ) {

		if ( $oo['order_webstat'] < 5 ) {
			$l = 'w';
		} elseif ( $oo['order_webstat'] > 5 && $oo['order_webstat'] < 11 ) {
			$l = 'a';
		} elseif ( $oo['order_webstat'] == 12 || $oo['order_reason'] == 5 || $oo['order_reason'] == 6 || $oo['order_reason'] == 7 ) {
			$l = 'x';
		} else $l = 'c';

		if ( $stats[$oo['flow_id']]['c'.$l] ) $stats[$oo['flow_id']]['c'.$l] += 1; else $stats[$oo['flow_id']]['c'.$l] = 1;
		if ( $stats[$oo['flow_id']]['m'.$l] ) $stats[$oo['flow_id']]['m'.$l] += $oo['cash_wm']; else $stats[$oo['flow_id']]['m'.$l] = $oo['cash_wm'];
		if ( $l != 'x' ) {
			if ( $stats[$oo['flow_id']]['ct'] ) $stats[$oo['flow_id']]['ct'] += 1; else $stats[$oo['flow_id']]['ct'] = 1;
			if ( $stats[$oo['flow_id']]['mt'] ) $stats[$oo['flow_id']]['mt'] += $oo['cash_wm']; else $stats[$oo['flow_id']]['mt'] = $oo['cash_wm'];
		}

	} $core->db->stop( $orders );

	return $stats;

}

//
// Module functions
//

function webmaster_menu ( $core, $menu ) {

	if ( $core->user->work == 2 ) {
		array_push( $menu, 'flow', 'offers' );
		$menu['stats'] = array( 'stats', 'lead', 'flowstat', 'utm' );
	} else {		array_push( $menu, 'flow', 'offers', 'lead' );
		$menu['stats'] = array( 'stats', 'flowstat', 'utm' );
	}
	if (!defined( 'HACK_NOREF' )) array_push( $menu, 'referal' );
	return $menu;

}

function webmaster_action ( $core ) {
	$action = ( $core->get['a'] ) ? $core->get['a'] : null;
	$id		= ( $core->post['id'] ) ? (int) $core->post['id'] : ( ($core->get['id']) ? (int) $core->get['id'] : 0 );

	switch ( $action ) {

	  case 'flow-add':

	  	$oid = webmaster_flow_add ( $core, $core->user->id, $id );
	  	if ( $oid ) {        	if ( $oid > 0 ) {	            $core->go($core->url( 'im', 'flow', $oid, 'ok' ));
        	} else $core->go($core->url( 'mm', 'offers', 'inactive' ));
	  	} else $core->go($core->url( 'mm', 'offers', 'error' ));

	  case 'flow-edit':

		$data = array(
			'name'	=> $core->text->line( $core->post['name'] ),
			'site'	=> (int) $core->post['site'],
			'space'	=> (int) $core->post['space'],
			'cb'	=> $core->post['cb'] ? 1 : 0,
			'param'	=> $core->post['param'] ? 1 : 0,
			'url'	=> $core->text->url( $core->post['url'] ),
			'pbu'	=> $core->text->line( $core->post['pbu'] ),
		);

		$result = webmaster_flow_edit( $core, $core->user->id, $id, $data );
	  	if ( $result ) {
        	if ( $result > 0 ) {
	            $core->go($core->url( 'mm', 'flow', 'save' ));
        	} else $core->go($core->url( 'mm', '', 'access' ));
	  	} else $core->go($core->url( 'mm', 'flow', 'error' ));

	  case 'flow-ajax':

		$data = array();
		if (isset( $core->get['site'] ))	$data['site'] 	= (int) $core->get['site'];
		if (isset( $core->get['space'] )) 	$data['space'] 	= (int) $core->get['space'];
		if (isset( $core->get['cb'] )) 		$data['cb'] 	= $core->get['cb'] ? 1 : 0;
		if (isset( $core->get['param'] )) 	$data['param'] 	= $core->get['param'] ? 1 : 0;
		if (isset( $core->get['url'] ))		$data['url'] 	= $core->text->url( $core->get['url'] );
		if (isset( $core->get['pbu'] ))		$data['pbu'] 	= $core->text->url( $core->get['pbu'] );
		$result = webmaster_flow_edit( $core, $core->user->id, $id, $data );
	  	echo ( $result > 0 ) ? 'ok' : error;
	  	$core->_die();

	  case 'flow-del':

		$result = webmaster_flow_del( $core, $core->user->id, $id );
	  	if ( $result ) {
        	if ( $result > 0 ) {
	            $core->go($core->url( 'mm', 'flow', 'del' ));
        	} else $core->go($core->url( 'mm', '', 'access' ));
	  	} else $core->go($core->url( 'mm', 'flow', 'error' ));

	  //
	  // Domains
	  //

	  // New parked domain
	  case 'dmn-add':

		$url = $core->text->link($core->post['url']);
		$core->db->add( DB_DOMAIN, array( 'user_id' => $core->user->id, 'dom_url' => $url ) );
		$core->wmsale->clear( 'domain', $core->user->id );
  		$core->go($core->url( 'mm', 'domain', 'ok' ));

	  // Delete parked domain
	  case 'dmn-del':

		$dd = $core->db->field( "SELECT user_id FROM ".DB_DOMAIN." WHERE dom_id = '$id' LIMIT 1" );
		if ( $dd == $core->user->id ) {
			$core->db->del( DB_DOMAIN, "dom_id = '$id'" );
			$core->wmsale->clear( 'domain', $core->user->id );
	  		$core->go($core->url( 'mm', 'domain', 'del' ));
	  	} else $core->go($core->url( 'mm', 'domain', 'access' ));

	  // Check domain for working
	  case 'dmn-check':

	  	$dom = $core->db->field( "SELECT dom_url FROM ".DB_DOMAIN." WHERE dom_id = '$id' LIMIT 1" );
	  	$data = @file_get_contents( 'http://' . $dom . '/ok' );
	  	if ( $data == 'ok' ) {
	  		$core->go($core->url( 'mm', 'domain', 'check' ));
	  	} else $core->go($core->url( 'mm', 'domain', 'error' ));

	}

	return false;

}

function webmaster_module ( $core ) {
	$module	= ( $core->get['m'] ) ? $core->get['m'] : null;
	$id		= ( $core->post['id'] ) ? (int) $core->post['id'] : ( ($core->get['id']) ? (int) $core->get['id'] : 0 );
	$page	= ( $core->get['page'] > 0 ) ? (int) $core->get['page'] : 1;
	$message = ( $core->get['message'] ) ? $core->get['message'] : null;

	switch ( $module ) {

	  case 'offers':

		require_once PATH_LIB . 'offers.php';
		offers ( $core );

	  case 'referal':

		if (defined( 'HACK_NOREF' )) $core->go('/');
	    $sh = 30; $st = $sh * ( $page - 1 );
    	$users	= $core->db->field ( "SELECT COUNT(*) FROM ".DB_USER." WHERE user_ref = '".$core->user->id."'");
    	$user	= $users ? $core->db->data ( "SELECT * FROM ".DB_USER." WHERE user_ref = '".$core->user->id."' ORDER BY user_name ASC LIMIT $st, $sh" ) : array();

	    $core->mainline->add ( $core->lang['referal_h'], $core->url( 'm', 'referal' ) );
	    $core->header ();

	    $core->tpl->load( 'body', 'referal', defined('HACK_TPL_REFERAL') ? HACK : false );

	    $core->tpl->vars ('body', array (
	        'title'		    => $core->lang['referal_h'],
            'text'			=> $core->text->lines( sprintf( $core->lang['referal_t'], $core->user->id ) ),
	        'nousers'		=> $core->lang['referal_no'],
	        'name'  	    => $core->lang['user'],
            'pages'			=> pages ( $core->url('m', 'referal'), $users, $sh, $page ),
            'shown'			=> $users ? sprintf( $core->lang['shown'], $st+1, min( $st+$sh, $users ), $users ) : '',
	    ));

	    if (count( $user )) foreach ( $user as &$i ) {
	        $core->tpl->block ('body', 'user', array (
	            'name'		=> $i['user_name'],
	            'cash'      => rur( $i['user_got'] ),
	            'flwa'		=> (int) $i['user_flwa'],
	        ));
	    } else $core->tpl->block( 'body', 'nouser' );

		$core->tpl->output ('body');

		$core->footer();
		$core->_die();

	  case 'lead':

		$where = array( "wm_id = '".$core->user->id."'" );
		$param = array();

		if ( isset( $core->get['from'] ) && $core->get['from'] ) {
			$from = $param['from'] = date2form(form2date( $core->get['from'] ));
			$ds = strtotime( $from . ' 00:00:00' );
			$where[] = " order_time >= '$ds'";
		} else $from = false;

		if ( isset( $core->get['to'] ) && $core->get['to'] ) {
			$to = $param['to'] = date2form(form2date( $core->get['to'] ));
			$dt = strtotime( $to . ' 23:59:59' );
			$where[] = " order_time <= '$dt'";
		} else $to = false;

		if ( isset( $core->get['o'] ) && $core->get['o'] ) {
			$o = $param['o'] = (int) $core->get['o'];
			$where[] = " offer_id = '$o' ";
		} else $o = false;

		if ( isset( $core->get['f'] ) && $core->get['f'] ) {
			$f = $param['f'] = (int) $core->get['f'];
			$where[] = " flow_id = '$f' ";
		} else $f = false;

		if ( isset( $core->get['w'] ) && $core->get['w'] ) {
			$w = $param['w'] = (int) $core->get['w'];
			$where[] = " site_id = '$w' ";
		} else $w = false;

		// UTM
		if (isset( $core->get['us'] )) {
			$param['us'] = $core->text->line( $core->get['us'] );
			$where[] = "utms = '".$param['us']."'";
		}
		if (isset( $core->get['uc'] )) {
			$param['uc'] = $core->text->line( $core->get['uc'] );
			$where[] = "utmc = '".$param['uc']."'";
		}
		if (isset( $core->get['un'] )) {
			$param['un'] = $core->text->line( $core->get['un'] );
			$where[] = "utmn = '".$param['un']."'";
		}
		if (isset( $core->get['ut'] )) {
			$param['ut'] = $core->text->line( $core->get['ut'] );
			$where[] = "utmt = '".$param['ut']."'";
		}
		if (isset( $core->get['um'] )) {
			$param['um'] = $core->text->line( $core->get['um'] );
			$where[] = "utmm = '".$param['um']."'";
		}

		if ( isset( $core->get['s'] ) && $s = $core->get['s'] ) {
			switch ( $s ) {				case 'w':	$where[] = " order_webstat < 5 "; break;
				case 'c':	$where[] = " order_webstat IN ( 5, 12 ) "; break;
				case 'a':	$where[] = " order_webstat BETWEEN 6 AND 11 "; break;
				default:	$s = false;
			}
		} else $s = false;
		if ( $s ) $param['s'] = $s;

		$where = implode( ' AND ', $where );
		$sh = 30; $st = ( $page - 1 ) * $sh;
		$orders = $core->db->field( "SELECT COUNT(*) FROM ".DB_ORDER." WHERE $where" );
		$order = $orders ? $core->db->data( "SELECT * FROM ".DB_ORDER." WHERE $where ORDER BY order_id DESC LIMIT $st, $sh" ) : array();

		$flow = $core->db->icol( "SELECT flow_id, flow_name FROM ".DB_FLOW." WHERE user_id = '".$core->user->id."' ".( $o ? " AND offer_id = '$o' " : '' )." ORDER BY flow_name ASC" );
		$offer = $core->wmsale->get( 'offers' );
		$sids = $core->db->col( "SELECT DISTINCT site_id FROM ".DB_ORDER." WHERE wm_id = '".$core->user->id."'" );
		$site = array(); foreach ( $sids as $ss ) $site[$ss] = $core->wmsale->get( 'site', $ss, 'site_url' );

		$core->mainline->add( $core->lang['stats_lead'] );
		$core->header();

		$core->tpl->load( 'body', 'lead', defined('HACK_TPL_LEAD') ? HACK : false );

		$core->tpl->vars( 'body', array(
			'nostats'		=> $core->lang['nostats'],
			'date'			=> $core->lang['date'],
			'flow'			=> $core->lang['flow'],
			'offer'			=> $core->lang['offer'],
			'status'		=> $core->lang['status'],
			'show'			=> $core->lang['show'],
			'site'			=> $core->lang['site'],
			'space'			=> $core->lang['stat_spaces'],
			'price'			=> $core->lang['cash'],
			'reason'		=> $core->lang['comment'],
			'from'			=> $from,
			'to'			=> $to,
			'u_stat'		=> $core->url( 'm', 'stats' ),
			'stat'			=> $core->lang['stats_date'],
			'pages'			=> pages ( $core->url( 'm', 'lead?' ) . http_build_query( $param ), $orders, $sh, $page ),
			'shown'			=> sprintf( $core->lang['shown'], $st+1, min( $st+$sh, $orders ), $orders ),
		));

		foreach ( $offer as $of => $n ) {
			$core->tpl->block( 'body', 'offer', array( 'name' => $n, 'value' => $of, 'select' => ($of==$o) ? 'selected="selected"' : '' ) );
		}

		foreach ( $flow as $fl => $n ) {
			$core->tpl->block( 'body', 'flow', array( 'name' => $n, 'value' => $fl, 'select' => ($fl==$f) ? 'selected="selected"' : '' ) );
		}

		foreach ( $site as $sl => $n ) {
			$core->tpl->block( 'body', 'site', array( 'name' => $n, 'value' => $sl, 'select' => ($sl==$w) ? 'selected="selected"' : '' ) );
		}

		foreach ( $core->lang['stat_status'] as $st => $n ) {
			$core->tpl->block( 'body', 'status', array( 'name' => $n, 'value' => $st, 'select' => ($st==$s) ? 'selected="selected"' : '' ) );
		}

		if ( $orders ) foreach ( $order as $r ) {
			if ( $r['order_webstat'] == 5 ) {				if ( $r['order_reason'] ) {					$reason = $core->lang['reasono'][$r['order_reason']];
				} else $reason = $r['order_comment'] ? sprintf( $core->lang['noreason_comment'], $r['order_comment'] ) :  $core->lang['noreason'];
			} elseif ( $r['order_webstat'] == 12 ) {				$reason = $core->lang['noreasonfraud'];
			} elseif ( $r['order_check'] ) {				$reason = $core->lang['stat_check'];
			} else $reason = false;

			$core->tpl->block( 'body', 'order', array(
				'id'			=> $r['order_id'],
				'offer'			=> $offer[$r['offer_id']],
				'site'			=> $core->wmsale->get( 'site', $r['site_id'], 'site_url' ),
				'space'			=> $core->wmsale->get( 'site', $r['space_id'], 'site_url' ),
				'flow'			=> $flow[$r['flow_id']],
				'ip'			=> int2ip( $r['order_ip'] ),
				'country'		=> $r['order_country'] ? $r['order_country'] : 'zz',
				'time'			=> smartdate( $r['order_time'] ),
				'stid'			=> ( $r['order_webstat'] < 6 || $r['order_webstat'] == 12 ) ? $r['order_webstat'] : 10,
				'status'		=> ( $r['order_webstat'] < 6 || $r['order_webstat'] == 12 ) ? $core->lang['statuso'][$r['order_webstat']] : $core->lang['statusok'],
				'price'			=> $r['cash_wm'] ? rur( $r['cash_wm'] ) : '',
				'reason'		=> $reason,
				'us'			=> $r['utms'],
				'uus'			=> $core->url( 'm', 'lead?' ) . parset( $param, 'us', $r['utms'] ),
				'uc'			=> $r['utmc'],
				'uuc'			=> $core->url( 'm', 'lead?' ) . parset( $param, 'uc', $r['utmc'] ),
				'un'			=> $r['utmn'],
				'uun'			=> $core->url( 'm', 'lead?' ) . parset( $param, 'un', $r['utmn'] ),
				'ut'			=> $r['utmt'],
				'uut'			=> $core->url( 'm', 'lead?' ) . parset( $param, 'ut', $r['utmt'] ),
				'um'			=> $r['utmm'],
				'uum'			=> $core->url( 'm', 'lead?' ) . parset( $param, 'um', $r['utmm'] ),

			));

		} else $core->tpl->block( 'body', 'nostat' );

		$core->tpl->output( 'body' );

		$core->footer();
	  	$core->_die();

	  case 'stats':

        $today = date( 'Ymd' );
        $week1 = date( 'Ymd', strtotime( '-1 week' ) );
        $yest = strtotime( '-1 day' );

		extract(params( $core, array( 'to' => 'date', 'from' => 'date', 'o', 'f' ) ));
		if ( ! $to || $to > $today ) $to = $today;
        if ( $from > $to ) $from = $to;
        if ( ! $from ) $from = $week1;

		if ( $core->user->level ) {
			$user = $core->get['all'] ? -1 : $core->user->id;
		} else $user = $core->user->id;

		list( $offer, $flow, $stats ) = webmaster_clicks( $core, $user, $from, $to, $f, $o );
		$csv = ( $core->get['show'] == 'csv' ) ? 1 : 0;

		$core->mainline->add( $core->lang['stats_h'] );
		if ( $csv ) {
			header('Content-type: text/csv');
			header('Content-disposition: attachment;filename=stats.csv');
		} else $core->header();

		if ( $csv ) {
			$core->tpl->load( 'body', 'csv-stats' );
		} else $core->tpl->load( 'body', 'stats', defined('HACK_TPL_STATS') ? HACK : false );

		$core->tpl->vars( 'body', array(
			'nostats'		=> $core->lang['nostats'],
			'date'			=> $core->lang['date'],
			'wait'			=> $core->lang['stat_wait'],
			'accept'		=> $core->lang['stat_accept'],
			'cancel'		=> $core->lang['stat_cancel'],
			'spaces'		=> $core->lang['stat_spaces'],
			'clicks'		=> $core->lang['stat_clicks'],
			'unique'		=> $core->lang['stat_unique'],
			'flow'			=> $core->lang['flow'],
			'offer'			=> $core->lang['offer'],
			'show'			=> $core->lang['show'],
			'from'			=> date2form( $from ),
			'to'			=> date2form( $to ),
			'u_csv'			=> $core->url( 'm', 'stats?show=csv&from=' ) . date2form( $from ) . '&to=' . date2form( $to ) . ( $o ? '&o='.$o : '' ) . ( $f ? '&f='.$f : '' ),
			'u_today'		=> $core->url( 'm', 'stats?from=' ) . date( 'Y-m-d' ) . '&to=' . date( 'Y-m-d' ) . ( $o ? '&o='.$o : '' ) . ( $f ? '&f='.$f : '' ),
			'u_yesterday'	=> $core->url( 'm', 'stats?from=' ) . date( 'Y-m-d', $yest ) . '&to=' . date( 'Y-m-d', $yest ) . ( $o ? '&o='.$o : '' ) . ( $f ? '&f='.$f : '' ),

		));

		foreach ( $offer as $of => $n ) {
			$core->tpl->block( 'body', 'offer', array( 'name' => $n, 'value' => $of, 'select' => ($of==$o) ? 'selected="selected"' : '' ) );
		}

		foreach ( $flow as $fl => $n ) {
			$core->tpl->block( 'body', 'flow', array( 'name' => $n, 'value' => $fl, 'select' => ($fl==$f) ? 'selected="selected"' : '' ) );
		}

		$sc = count( $stats );
		$t = array( 'space' => 0, 'suni' => 0, 'sgood' => 0, 'stime' => 0, 'clicks' => 0, 'unique' => 0, 'good' => 0, 'time' => 0, 'ca' => 0, 'cw' => 0, 'cc' => 0, 'ct' => 0, 'cx' => 0, 'ma' => 0, 'mw' => 0, 'mc' => 0, 'mt' => 0 );
		$tk = array_keys( $t );
		if ( $stats ) {
			foreach ( $stats as $d => &$s ) {
				foreach ( $tk as $k ) if ( $s[$k] ) $t[$k] += $s[$k];
				$core->tpl->block( 'body', 'stat', array(
	            	'date'		=> date2form( $d ),
					'cr'		=> $cl ? sprintf( "%0.2f", ( $s['ca'] / $cl ) * 100 ) : 0,
					'epc'		=> $cl ? rur ( $s['ma'] / $cl ) : '-',
					'epcr'		=> $cl ? sprintf ( "%0.2f", $s['ma'] / $cl ) : '-',
					'app'		=> $s['ct'] ? sprintf( '%d', $s['ca'] * 100 / $s['ct'] ) : 0,
	                'spaces'	=> (int) $s['spaces'],
	                'suni'		=> (int) $s['suni'],
	                'sbad'		=> sprintf( '%d', $s['spaces'] ? ( ( $s['spaces'] - $s['sgood'] ) / $s['spaces'] * 100 ) : 0  ),
					'stime'		=> sprintf( '%d', $s['stime'] * 5 ),
            	    'per'		=> $s['suni'] ? sprintf( '%d', $s['unique'] / $s['suni'] * 100 ) : 0,
	                'clicks'	=> (int) $s['clicks'],
	                'unique'	=> (int) $s['unique'],
	                'bad'		=> sprintf( '%d', $s['clicks'] ? ( ( $s['clicks'] - $s['good'] ) / $s['clicks'] * 100 ) : 0  ),
					'time'		=> sprintf( '%d', $s['time'] * 5 ),
					'ua'		=> $core->url( 'm', 'lead' ) . '?from=' . date2form( $d ) . '&to=' . date2form( $d ) . '&s=a',
					'uw'		=> $core->url( 'm', 'lead' ) . '?from=' . date2form( $d ) . '&to=' . date2form( $d ) . '&s=w',
					'uc'		=> $core->url( 'm', 'lead' ) . '?from=' . date2form( $d ) . '&to=' . date2form( $d ) . '&s=c',
					'ut'		=> $core->url( 'm', 'lead' ) . '?from=' . date2form( $d ) . '&to=' . date2form( $d ),
	                'ca'		=> (int) $s['ca'],
					'cw'		=> (int) $s['cw'],
	                'cc'		=> (int) $s['cc'],
	                'cx'		=> (int) $s['cx'],
	                'ct'		=> (int) $s['ct'],
	                'ma'		=> rur( $s['ma'] ),
	                'mw'		=> rur( $s['mw'] ),
	                'mc'		=> rur( $s['mc'] ),
	                'mt'		=> rur( $s['mt'] ),
	                'mar'		=> (int) $s['ma'],
	                'mwr'		=> (int) $s['mw'],
	                'mcr'		=> (int) $s['mc'],
	                'mtr'		=> (int) $s['mt'],
				));
			} unset ( $d, $s, $stats );
		} else $core->tpl->block( 'body', 'nostat' );

		if ( $sc > 1 ) {        	$cl = max( $t['suni'], $t['unique'] );
			$core->tpl->block( 'body', 'total', array(
				'cr'		=> $cl ? sprintf( "%0.2f", $t['ct'] / $cl * 100 ) : 0,
				'epc'		=> $cl ? rur ( $t['ma'] / $cl ) : '-',
				'app'		=> $t['ct'] ? sprintf( '%d', $t['ca'] * 100 / $t['ct'] ) : 0,
                'spaces'	=> (int) $t['spaces'],
                'suni'		=> (int) $t['suni'],
                'per'		=> $t['suni'] ? sprintf( '%d', $t['unique'] / $t['suni'] * 100 ) : 0,
                'sbad'		=> sprintf( '%d', $t['spaces'] ? ( ( $t['spaces'] - $t['sgood'] ) / $t['spaces'] * 100 ) : 0  ),
                'stime'		=> sprintf( '%d', $t['stime'] * 5 / $sc ),
                'clicks'	=> (int) $t['clicks'],
                'unique'	=> (int) $t['unique'],
                'bad'		=> sprintf( '%d', $t['clicks'] ? ( ( $t['clicks'] - $t['good'] ) / $t['clicks'] * 100 ) : 0  ),
                'time'		=> sprintf( '%d', $t['time'] * 5 / $sc ),
                'ca'		=> (int) $t['ca'],
				'cw'		=> (int) $t['cw'],
                'cc'		=> (int) $t['cc'],
                'cx'		=> (int) $t['cx'],
                'ct'		=> (int) $t['ct'],
                'ma'		=> rur( $t['ma'] ),
                'mw'		=> rur( $t['mw'] ),
                'mc'		=> rur( $t['mc'] ),
                'mt'		=> rur( $t['mt'] ),
			));
		}

		$core->tpl->output( 'body', $csv ? 'windows-1251' : false  );

		if ( ! $csv ) $core->footer();
	  	$core->_die();

	  case 'utm':

        $today = date( 'Ymd' );
        $week1 = date( 'Ymd', strtotime( '-1 week' ) );

		extract(params( $core, array( 'to' => 'date', 'from' => 'date', 'o', 'f', 'a' ) ));
		if ( ! $to || $to > $today ) $to = $today;
        if ( $from > $to ) $from = $to;
        if ( ! $from ) $from = $today;

		if ( $core->user->level ) {
			$all = $a ? true : false;
		} else $all = false;

		$us = isset( $core->get['us'] ) ? $core->text->line( $core->get['us'] ) : null;
		$uc = isset( $core->get['uc'] ) ? $core->text->line( $core->get['uc'] ) : null;
		$un = isset( $core->get['un'] ) ? $core->text->line( $core->get['un'] ) : null;
		$ut = isset( $core->get['ut'] ) ? $core->text->line( $core->get['ut'] ) : null;
		$um = isset( $core->get['um'] ) ? $core->text->line( $core->get['um'] ) : null;

		$u = $core->text->link( $core->get['u'] );
		if ( ! $u ) {			$u = $core->session_get( 'utm' );
			if ( ! $u ) $u = 'snctm';
		} else $core->session_set( 'utm', $u );

		for ( $i = 0; $i < 5; $i++ ) {
			$ua = $u{$i};         	$uo = 'u'.$ua;
         	$uf = 'utm'.$ua;
         	if (!isset( $$uo )) break;
		}

		$deep = ( $i < 4 ) ? true : false;
		$short = $core->get['ajax'] ? true : false;

		$oids = $core->db->col( "SELECT DISTINCT offer_id FROM ".DB_FLOW." WHERE user_id = '".$core->user->id."'" );
		$oids = implode( ',', $oids );
		$offer = $oids ? $core->db->icol( "SELECT offer_id, offer_name FROM ".DB_OFFER." WHERE offer_id IN ( $oids ) ORDER BY offer_name ASC" ) : array();
		$flow = $core->db->icol( "SELECT flow_id, flow_name FROM ".DB_FLOW." WHERE user_id = '".$core->user->id."' ".( $o ? " AND offer_id = '$o' " : '' )." ORDER BY flow_name ASC" );

		if ( ! $all ) {
			if ( ! $f ) {
				$flows = $flow ? implode( ', ', array_keys( $flow ) ) : 0;
				$flows = " AND flow_id IN ( $flows ) ";
			} else $flows = " AND flow_id = '$f' ";
		}

		$stats = array();
        $ww = '';
        if (isset( $us )) $ww .= " AND utms = '$us' ";
        if (isset( $uc )) $ww .= " AND utmc = '$uc' ";
        if (isset( $un )) $ww .= " AND utmn = '$un' ";
        if (isset( $ut )) $ww .= " AND utmt = '$ut' ";
        if (isset( $um )) $ww .= " AND utmm = '$um' ";

		// Counting space clicks
		$spaces = $core->db->icol( "SELECT $uf, COUNT(*) FROM ".DB_CLICK." WHERE ( click_date BETWEEN '$from' AND '$to' ) $flows $ww AND click_space = 1 GROUP BY $uf" );
		foreach ( $spaces as $a => $b ) $stats[$a]['spaces'] = $b;
		unset ( $spaces );
		$suni = $core->db->icol( "SELECT $uf, COUNT(*) FROM ".DB_CLICK." WHERE ( click_date BETWEEN '$from' AND '$to' ) $flows $ww AND click_space = 1 AND click_unique = 1 GROUP BY $uf" );
		foreach ( $suni as $a => $b ) $stats[$a]['suni'] = $b;
		unset ( $suni );
		$sgood = $core->db->icol( "SELECT $uf, COUNT(*) FROM ".DB_CLICK." WHERE ( click_date BETWEEN '$from' AND '$to' ) $flows $ww AND click_space = 1 AND click_good >= ".GOODCLICK." GROUP BY $uf" );
		foreach ( $sgood as $a => $b ) $stats[$a]['sgood'] = $b;
		unset ( $sgood );
		$stime = $core->db->icol( "SELECT $uf, AVG(click_good) FROM ".DB_CLICK." WHERE ( click_date BETWEEN '$from' AND '$to' ) $flows $ww AND click_space = 1 GROUP BY $uf" );
		foreach ( $stime as $a => $b ) $stats[$a]['stime'] = $b;
		unset ( $stime );

		// Counting land clicks
		$clicks = $core->db->icol( "SELECT $uf, COUNT(*) FROM ".DB_CLICK." WHERE ( click_date BETWEEN '$from' AND '$to' ) $flows $ww AND click_space = 0 GROUP BY $uf" );
		foreach ( $clicks as $a => $b ) $stats[$a]['clicks'] = $b;
		unset ( $clicks );
		$unique = $core->db->icol( "SELECT $uf, COUNT(*) FROM ".DB_CLICK." WHERE ( click_date BETWEEN '$from' AND '$to' ) $flows $ww AND click_space = 0 AND click_unique = 1 GROUP BY $uf" );
		foreach ( $unique as $a => $b ) $stats[$a]['unique'] = $b;
		unset ( $unique );
		$good = $core->db->icol( "SELECT $uf, COUNT(*) FROM ".DB_CLICK." WHERE ( click_date BETWEEN '$from' AND '$to' ) $flows $ww AND click_space = 0 AND click_good >= ".GOODCLICK." GROUP BY $uf" );
		foreach ( $good as $a => $b ) $stats[$a]['good'] = $b;
		unset ( $good );
		$tim = $core->db->icol( "SELECT $uf, AVG(click_good) FROM ".DB_CLICK." WHERE ( click_date BETWEEN '$from' AND '$to' ) $flows $ww AND click_space = 0 GROUP BY $uf" );
		foreach ( $tim as $a => $b ) $stats[$a]['time'] = $b;
		unset ( $tim );

		// Counting orders
		$ff = strtotime( date2form( $from ) . ' 00:00:00' );
		$tt = strtotime( date2form( $to ) . ' 23:59:59' );
		$ao = array();
		$orders = $core->db->start( "SELECT order_id, order_webstat, order_reason, cash_wm, $uf FROM ".DB_ORDER." WHERE order_time BETWEEN '$ff' AND '$tt' $flows $ww" );
		while ( $oo = $core->db->one( $orders ) ) {
			$d = $oo[$uf];
			if ( ! $stats[$d] ) continue;

			if ( $oo['order_webstat'] < 5 ) {
				$l = 'w';
			} elseif ( $oo['order_webstat'] > 5 && $oo['order_webstat'] < 11 ) {
				$l = 'a';
			} elseif ( $oo['order_webstat'] == 12 || $oo['order_reason'] == 5 || $oo['order_reason'] == 6 || $oo['order_reason'] == 7 ) {
				$l = 'x';
			} else $l = 'c';

			if ( $stats[$d]['c'.$l] ) $stats[$d]['c'.$l] += 1; else $stats[$d]['c'.$l] = 1;
			if ( $stats[$d]['m'.$l] ) $stats[$d]['m'.$l] += $oo['cash_wm']; else $stats[$d]['m'.$l] = $oo['cash_wm'];
			if ( $l != 'x' ) {
				if ( $stats[$d]['ct'] ) $stats[$d]['ct'] += 1; else $stats[$d]['ct'] = 1;
				if ( $stats[$d]['mt'] ) $stats[$d]['mt'] += $oo['cash_wm']; else $stats[$d]['mt'] = $oo['cash_wm'];
			}

		} $core->db->stop( $orders );

		if ( ! $short ) {

			$core->mainline->add( $core->lang['stats_utm'] );
			$core->header();
			$core->tpl->block( 'body', 'face' );

			if ( $core->user->level ) $core->tpl->block( 'body', 'face.alls' );
			for ( $i = 0; $i < 5; $i++ ) $core->tpl->block( 'body', 'face.utm', array( 'id' => $u{$i}, 'name' => $core->lang['utms'][$u{$i}] ) );
			foreach ( $offer as $of => $n ) $core->tpl->block( 'body', 'face.offer', array( 'name' => $n, 'value' => $of, 'select' => ($of==$o) ? 'selected="selected"' : '' ) );
			foreach ( $flow as $fl => $n ) $core->tpl->block( 'body', 'face.flow', array( 'name' => $n, 'value' => $fl, 'select' => ($fl==$f) ? 'selected="selected"' : '' ) );

		}

		$upr = 'u='.$u;
		if ( $o ) $upr .= '&o='.$o;
		if ( $f ) $upr .= '&f='.$f;
		if ( $all ) $upr .= '&a=1';
        if (isset( $us )) $upr .= '&us='.$us;
        if (isset( $uc )) $upr .= '&uc='.$uc;
        if (isset( $un )) $upr .= '&un='.$un;
        if (isset( $ut )) $upr .= '&ut='.$ut;
        if (isset( $um )) $upr .= '&um='.$um;

		$core->tpl->load( 'body', 'utm', defined('HACK_TPL_UTM') ? HACK : false );

		$core->tpl->vars( 'body', array(
			'tid'			=> md5(microtime()),
			'nostats'		=> $core->lang['nostats'],
			'type'			=> $core->lang['type'],
			'today'			=> $core->lang['today'],
			'source'		=> $core->lang['utms'][$ua],
			'showall'		=> $core->lang['showall'],
			'wait'			=> $core->lang['stat_wait'],
			'accept'		=> $core->lang['stat_accept'],
			'cancel'		=> $core->lang['stat_cancel'],
			'spaces'		=> $core->lang['stat_spaces'],
			'clicks'		=> $core->lang['stat_clicks'],
			'unique'		=> $core->lang['stat_unique'],
			'total'			=> $core->lang['total'],
			'flow'			=> $core->lang['flow'],
			'offer'			=> $core->lang['offer'],
			'show'			=> $core->lang['show'],
			'help'			=> $core->lang['help'],
			'helptext'		=> $core->lang['stat_help'],
			'from'			=> date2form( $from ),
			'to'			=> date2form( $to ),
			'u'				=> $u,
			'all'			=> $all ? 'checked="checked"' : '',
			'u_today'		=> $core->url( 'm', 'utm?from=' ) . date( 'Y-m-d' ) . '&to=' . date( 'Y-m-d' ) . '&' . $upr,
			'u_yest'		=> $core->url( 'm', 'utm?from=' ) . date( 'Y-m-d', strtotime( '-1 day' ) ) . '&to=' . date( 'Y-m-d', strtotime( '-1 day' ) ) . '&' . $upr,
			'u_week'		=> $core->url( 'm', 'utm?from=' ) . date( 'Y-m-d', strtotime( '-1 week' ) ) . '&to=' . date( 'Y-m-d' ) . '&' . $upr,
			'u_month'		=> $core->url( 'm', 'utm?from=' ) . date( 'Y-m-d', strtotime( '-1 month' ) ) . '&to=' . date( 'Y-m-d' ) . '&' . $upr,
		));

		if ( $stats ) {

			$t = array( 'spaces' => 0, 'suni' => 0, 'sgood' => 0, 'stime' => 0, 'clicks' => 0, 'unique' => 0, 'good' => 0, 'time' => 0, 'ca' => 0, 'cw' => 0, 'cc' => 0, 'ct' => 0, 'cx' => 0, 'ma' => 0, 'mw' => 0, 'mc' => 0, 'mt' => 0 );
			$tf = array_keys( $t );

			foreach ( $stats as $d => &$s ) {

				$tc = max( (int) $s['spaces'], (int) $s['clicks'], (int) $s['unique'] );
				$ts = $s['ct'] / $tc * 1000;
				$cls = ( $tc > 100 ) ? ( ( $ts < 1 ) ? 'red' : ( ( $ts < 10 ) ? 'yellow' : '' ) ) : '';
				foreach ( $tf as $ttf ) if ( $s[$ttf] ) $t[$ttf] += $s[$ttf];

				$url = $core->url( 'm', 'utm?from=' ) . date2form( $from ) . '&to=' . date2form( $to ) . '&' . $upr . '&' . $uo . '=' . $d;
				$lu = $core->url( 'm', 'lead?from=' ) . date2form( $from ) . '&to=' . date2form( $to ) . '&' . $upr . '&' . $uo . '=' . $d;

				$core->tpl->block( 'body', 'stat', array(
					'u'			=> $deep ? $url : false,
					'id'		=> md5( $url ),
	            	'name'		=> $d ? $d : $core->lang['na'],
	            	'class'		=> $cls,
					'cr'		=> $tc ? sprintf( "%0.2f", $s['ct'] / $tc * 100 ) : 0,
					'epc'		=> $tc ? rur ( $s['ma'] / $tc ) : '-',
					'app'		=> $s['ct'] ? sprintf( '%d', $s['ca'] * 100 / $s['ct'] ) : 0,
	                'spaces'	=> (int) $s['spaces'],
	                'suni'		=> (int) $s['suni'],
	                'sbad'		=> sprintf( '%d', $s['spaces'] ? ( ( $s['spaces'] - $s['sgood'] ) / $s['spaces'] * 100 ) : 0  ),
					'stime'		=> sprintf( '%d', $s['stime'] * 5 ),
					'per'		=> $s['suni'] ? sprintf( '%d', $s['unique'] / $s['suni'] * 100 ) : 0,
	                'clicks'	=> (int) $s['clicks'],
	                'unique'	=> (int) $s['unique'],
	                'bad'		=> sprintf( '%d', $s['clicks'] ? ( ( $s['clicks'] - $s['good'] ) / $s['clicks'] * 100 ) : 0  ),
					'time'		=> sprintf( '%d', $s['time'] * 5 ),
	                'ca'		=> (int) $s['ca'],
	                'cw'		=> (int) $s['cw'],
	                'cc'		=> (int) $s['cc'],
	                'ct'		=> (int) $s['ct'],
	                'cx'		=> (int) $s['cx'],
					'cau'		=> $lu . '&s=a',
					'cwu'		=> $lu . '&s=w',
					'ccu'		=> $lu . '&s=c',
					'ctu'		=> $lu,
					'ma'		=> rur( $s['ma'] ),
					'mw'		=> rur( $s['mw'] ),
					'mc'		=> rur( $s['mc'] ),
					'mt'		=> rur( $s['mt'] ),
				));

			} unset ( $d, $s );

			$sc = count( $stats );
	        if ( $sc > 1 ) {
	        	$cl = max( $t['suni'], $t['unique'] );
				$core->tpl->block( 'body', 'total', array(
					'cr'		=> $cl ? sprintf( "%0.2f", $t['ct'] / $cl * 100 ) : 0,
					'epc'		=> $cl ? rur ( $t['ma'] / $cl ) : '-',
					'app'		=> $t['ct'] ? sprintf( '%d', $t['ca'] * 100 / $t['ct'] ) : 0,
	                'spaces'	=> (int) $t['spaces'],
	                'suni'		=> (int) $t['suni'],
	                'sbad'		=> sprintf( '%d', $t['spaces'] ? ( ( $t['spaces'] - $t['sgood'] ) / $t['spaces'] * 100 ) : 0  ),
					'stime'		=> sprintf( '%d', $t['stime'] * 5 / $sc ),
					'per'		=> $t['suni'] ? sprintf( '%d', $t['unique'] / $t['suni'] * 100 ) : 0,
	                'clicks'	=> (int) $t['clicks'],
	                'unique'	=> (int) $t['unique'],
	                'bad'		=> sprintf( '%d', $t['clicks'] ? ( ( $t['clicks'] - $t['good'] ) / $t['clicks'] * 100 ) : 0  ),
					'time'		=> sprintf( '%d', $t['time'] * 5 / $sc ),
	                'ca'		=> (int) $t['ca'],
	                'cw'		=> (int) $t['cw'],
	                'cc'		=> (int) $t['cc'],
	                'ct'		=> (int) $t['ct'],
	                'cx'		=> (int) $t['cx'],
					'ma'		=> rur( $t['ma'] ),
					'mw'		=> rur( $t['mw'] ),
					'mc'		=> rur( $t['mc'] ),
					'mt'		=> rur( $t['mt'] ),
				));
	        }

		} else $core->tpl->block( 'body', 'nostat' );

		$core->tpl->output( 'body' );

		if ( ! $short ) $core->footer();
	  	$core->_die();

	  case 'flowstat':

        $today = date( 'Ymd' );
        $week1 = date( 'Ymd', strtotime( '-2 week' ) );
        $yest = strtotime( '-1 day' );

		extract(params( $core, array( 'to' => 'date', 'from' => 'date' ) ));
		if ( ! $to || $to > $today ) $to = $today;
        if ( $from > $to ) $from = $to;
        if ( ! $from ) $from = $week1;

		$stats = webmaster_flowstat ( $core, $core->user->id, $from, $to );
		$csv = ( $core->get['show'] == 'csv' ) ? 1 : 0;

		$core->mainline->add( $core->lang['stats_flow'] );
		if ( $csv ) {
			header('Content-type: text/csv');
			header('Content-disposition: attachment;filename=flowstat.csv');
		} else $core->header();

		if ( $csv ) {
			$core->tpl->load( 'body', 'csv-flowstat' );
		} else $core->tpl->load( 'body', 'flowstat', defined('HACK_TPL_FLOWSTAT') ? HACK : false );

		$core->tpl->vars( 'body', array(
			'nostats'		=> $core->lang['nostats'],
			'type'			=> $core->lang['type'],
			'today'			=> $core->lang['today'],
			'yesterday'		=> $core->lang['yesterday'],
			'target'		=> $core->lang['target'],
			'wait'			=> $core->lang['stat_wait'],
			'accept'		=> $core->lang['stat_accept'],
			'cancel'		=> $core->lang['stat_cancel'],
			'spaces'		=> $core->lang['stat_spaces'],
			'clicks'		=> $core->lang['stat_clicks'],
			'unique'		=> $core->lang['stat_unique'],
			'total'			=> $core->lang['total'],
			'flow'			=> $core->lang['flow'],
			'offer'			=> $core->lang['offer'],
			'show'			=> $core->lang['show'],
			'help'			=> $core->lang['help'],
			'helptext'		=> $core->lang['stat_help'],
			'confirm'		=> $core->lang['confirm'],
			'from'			=> date2form( $from ),
			'to'			=> date2form( $to ),
			'u_today'		=> $core->url( 'm', 'flowstat?from=' ) . date( 'Y-m-d' ) . '&to=' . date( 'Y-m-d' ) . ( $o ? '&o='.$o : '' ) . ( $f ? '&f='.$f : '' ),
			'u_yesterday'	=> $core->url( 'm', 'flowstat?from=' ) . date( 'Y-m-d', $yest ) . '&to=' . date( 'Y-m-d', $yest ) . ( $o ? '&o='.$o : '' ) . ( $f ? '&f='.$f : '' ),
			'u_csv'			=> $core->url( 'm', 'flowstat?show=csv&from=' ) . date2form( $from ) . '&to=' . date2form( $to ) . ( $o ? '&o='.$o : '' ) . ( $f ? '&f='.$f : '' )
		));

		if ( $stats ) {

			$t = array( 'space' => 0, 'suni' => 0, 'sgood' => 0, 'stime' => 0, 'clicks' => 0, 'unique' => 0, 'good' => 0, 'time' => 0, 'ca' => 0, 'cw' => 0, 'cc' => 0, 'ct' => 0, 'cx' => 0, 'ma' => 0, 'mw' => 0, 'mc' => 0, 'mt' => 0 );
			$tf = array_keys( $t );

			foreach ( $stats as $d => &$s ) {

				$tc = max( (int) $s['suni'], (int) $s['unique'] );
				$ts = $tc ? $s['ct'] / $tc * 1000 : 0;
				$cls = ( ( $tc > 100 ) ? ( ( $ts < 1 ) ? 'red' : ( ( $ts < 10 ) ? 'yellow' : '' ) ) : '' );
				foreach ( $tf as $ttf ) if ( $s[$ttf] ) $t[$ttf] += $s[$ttf];

				$core->tpl->block( 'body', 'stat', array(
	            	'class'		=> $cls,
	            	'offer'		=> $s['offer'],
					'flow'		=> $s['flow'],
					'type'		=> (int) $s['type'],
					'cr'		=> $tc ? sprintf( "%0.2f", $s['ct'] / $tc * 100 ) : 0,
					'epc'		=> $tc ? rur ( $s['ma'] / $tc ) : '-',
					'app'		=> $s['ct'] ? sprintf( '%d', $s['ca'] * 100 / $s['ct'] ) : 0,
	                'spaces'	=> (int) $s['space'],
	                'suni'		=> (int) $s['suni'],
	                'sbad'		=> sprintf( '%d', $s['space'] ? ( ( $s['space'] - $s['sgood'] ) / $s['space'] * 100 ) : 0  ),
	                'stime'		=> sprintf( '%d', $s['stime'] * 5 ),
					'per'		=> $s['suni'] ? sprintf( '%d', $s['unique'] / $s['suni'] * 100 ) : 0,
	                'clicks'	=> (int) $s['clicks'],
	                'unique'	=> (int) $s['unique'],
	                'bad'		=> sprintf( '%d', $s['clicks'] ? ( ( $s['clicks'] - $s['good'] ) / $s['clicks'] * 100 ) : 0  ),
	                'time'		=> sprintf( '%d', $s['time'] * 5 ),
	                'ca'		=> (int) $s['ca'],
	                'cw'		=> (int) $s['cw'],
	                'cc'		=> (int) $s['cc'],
	                'ct'		=> (int) $s['ct'],
	                'cx'		=> (int) $s['cx'],
					'ma'		=> rur( $s['ma'] ),
					'mw'		=> rur( $s['mw'] ),
					'mc'		=> rur( $s['mc'] ),
					'mt'		=> rur( $s['mt'] ),
				));

			} unset ( $d, $s );

			$sc = count( $stats );
	        if ( $sc > 1 ) {
	        	$cl = max( $t['suni'], $t['unique'] );
				$core->tpl->block( 'body', 'total', array(
					'cr'		=> $cl ? sprintf( "%0.2f", $t['ct'] / $cl * 100 ) : 0,
					'epc'		=> $cl ? rur ( $t['ma'] / $cl ) : '-',
					'app'		=> $t['ct'] ? sprintf( '%d', $t['ca'] * 100 / $t['ct'] ) : 0,
	                'spaces'	=> (int) $t['space'],
	                'suni'		=> (int) $t['suni'],
	                'sbad'		=> sprintf( '%d', $t['space'] ? ( ( $t['space'] - $t['sgood'] ) / $t['space'] * 100 ) : 0  ),
	                'stime'		=> sprintf( '%d', $t['stime'] * 5 / $sc ),
	                'per'		=> $t['suni'] ? sprintf( '%d', $t['unique'] / $t['suni'] * 100 ) : 0,
	                'clicks'	=> (int) $t['clicks'],
	                'unique'	=> (int) $t['unique'],
	                'bad'		=> sprintf( '%d', $t['clicks'] ? ( ( $t['clicks'] - $t['good'] ) / $t['clicks'] * 100 ) : 0  ),
	                'time'		=> sprintf( '%d', $t['time'] * 5 / $sc  ),
	                'ca'		=> (int) $t['ca'],
	                'cw'		=> (int) $t['cw'],
	                'cc'		=> (int) $t['cc'],
	                'ct'		=> (int) $t['ct'],
	                'cx'		=> (int) $t['cx'],
					'ma'		=> rur( $t['ma'] ),
					'mw'		=> rur( $t['mw'] ),
					'mc'		=> rur( $t['mc'] ),
					'mt'		=> rur( $t['mt'] ),
				));
	        }

		} else $core->tpl->block( 'body', 'nostat' );

		$core->tpl->output( 'body', $csv ? 'windows-1251' : false );

		if ( ! $csv ) $core->footer();
	  	$core->_die();

	  // Parked domains
	  case 'domain':

		switch ( $message ) {
	    	case 'ok':		$core->info( 'info', 'done_add' );				break;
	    	case 'del':		$core->info( 'info', 'done_del' );				break;
	    	case 'check':	$core->info( 'info', 'done_domain_check' );		break;
	    	case 'error':	$core->info( 'error', 'error_domain_check' );	break;
    		case 'access':	$core->info( 'error', 'access_denied' );		break;
		}

	    $core->mainline->add ( $core->lang['menu_domain'], $core->url( 'm', 'domain' ) );
	  	$core->header();

		$core->tpl->load( 'body', 'domain', defined('HACK_TPL_DOMAIN') ? HACK : false );

		$core->tpl->vars( 'body', array(
			'text'		=> $core->text->lines( $core->lang['domain_t'] ),
			'u_add'		=> $core->url( 'a', 'dmn-add', 0 ),
			'url'		=> $core->lang['domain'],
			'status'	=> $core->lang['status'],
			'action'	=> $core->lang['action'],
			'check'		=> $core->lang['domain_check'],
			'del'		=> $core->lang['del'],
			'confirm'	=> $core->lang['confirm'],
			'nodomain'	=> $core->lang['nodomain'],
		));

		$domain = $core->db->data( "SELECT * FROM ".DB_DOMAIN." WHERE user_id = '".$core->user->id."' ORDER BY dom_status ASC, dom_url ASC" );
		if (count( $domain )) foreach ( $domain as $d ) {
			$core->tpl->block( 'body', 'domain', array(
				'url'		=> $d['dom_url'],
				'stclass'	=> $d['dom_status'] ? 'isok' : 'wait',
				'status'	=> $d['dom_status'] ? $core->lang['dom_ok'] : $core->lang['dom_wait'],
				'check'		=> $core->url( 'a', 'dmn-check', $d['dom_id'] ),
				'del'		=> $core->url( 'a', 'dmn-del', $d['dom_id'] ),
			));
		} else $core->tpl->block( 'body', 'nodoms' );


		$core->tpl->output( 'body' );

	  	$core->footer();
	  	$core->_die();

	  // WorkFlow
	  default:
	  case 'flow':

		switch ( $message ) {
	    	case 'ok':		$core->info( 'info', 'done_flow_ok' );		break;
	    	case 'save':	$core->info( 'info', 'done_flow_save' );	break;
	    	case 'del':		$core->info( 'info', 'done_flow_del' );		break;
	    	case 'error':	$core->info( 'error', 'error_flow' );		break;
    		case 'access':	$core->info( 'error', 'access_denied' );	break;
		}

		if ( $id ) {
			$flow = $core->db->row( "SELECT * FROM ".DB_FLOW." WHERE flow_id = '$id' LIMIT 1" );
			if ( $flow['user_id'] != $core->user->id ) $core->go($core->url( 'mm', '', 'access' ));

			$sitel = $core->wmsale->get( 'lands', $flow['offer_id'] );
			$sites = array();
			foreach ( $sitel as $k => $v ) $sites[] = array( 'name' => $v['site_url'], 'value' => $v['site_id'], 'select' => $v['site_id'] == $flow['flow_site'] );
			$spacl = $core->wmsale->get( 'space', $flow['offer_id'] );
			$space = array( array( 'name' => '&mdash;', 'value' => 0 ));
			foreach ( $spacl as $k => $v ) $space[] = array( 'name' => $v['site_url'], 'value' => $v['site_id'], 'select' => $v['site_id'] == $flow['flow_space'] );

		    $core->mainline->add ( $core->lang['menu_flow'], $core->url( 'm', 'flow' ) );
		    $core->mainline->add ( $flow['flow_name'] );
			$core->header();

		    $title	= $core->lang['flow_edit_h'];
		    $action	= $core->url ( 'a', 'flow-edit', $id );
		    $method	= 'post';
		    $field 	= array(
		    	array( 'type' => 'line', 'value' => $core->text->lines( $core->lang['flow_edit_t'] ) ),
	            array( 'type' => 'text', 'length' => 100, 'name' => 'name', 'head' => $core->lang['name'], 'descr' => $core->lang['flow_name_d'], 'value' => $flow['flow_name']),
	            array( 'type' => 'select', 'name' => 'site', 'head' => $core->lang['flow_land'], 'value' => $sites ),
	            array( 'type' => 'select', 'name' => 'space', 'head' => $core->lang['flow_space'], 'value' => $space ),
	            array( 'type' => 'checkbox', 'name' => 'cb', 'head' => $core->lang['flow_comeback'], 'checked' => $flow['flow_cb'] ),
	            array( 'type' => 'checkbox', 'name' => 'param', 'head' => $core->lang['flow_param'], 'checked' => $flow['flow_param'] ),
	            array( 'type' => 'text', 'length' => 200, 'name' => 'url', 'head' => $core->lang['flow_url'], 'descr' => $core->lang['flow_url_d'], 'value' => $flow['flow_url']),
	            array( 'type' => 'text', 'length' => 200, 'name' => 'pbu', 'head' => $core->lang['flow_pbu'], 'descr' => $core->lang['flow_pbu_d'], 'value' => $flow['flow_pbu']),
		    );
		    $button = array(array('type' => 'submit', 'value' => $core->lang['save']));
		    $core->form ('flowedit', $action, $method, $title, $field, $button);

			$core->footer();
			$core->_die();

		}

		$flows = $core->db->data( "SELECT * FROM ".DB_FLOW." WHERE user_id = '".$core->user->id."' ORDER BY flow_id DESC" );
		$flow = array(); foreach ( $flows as $f ) $flow[$f['offer_id']][] = $f;
		$redmn = $core->wmsale->get( 'domain', $core->user->id );

	    $core->mainline->add ( $core->lang['menu_flow'], $core->url( 'm', 'flow' ) );
	    $core->header ();

		$core->tpl->load( 'body', 'flows', defined('HACK_TPL_FLOWS') ? HACK : false );

		$core->tpl->vars( 'body', array(

			'text'		=> $core->text->lines( $core->lang['flows_text'] ),
			'flow_site'	=> $core->text->lines( $core->lang['flow_site'] ),
			'flow_cb'	=> $core->lang['flow_comeback'],
			'flow_sub'	=> $core->text->lines( $core->lang['flow_sub'] ),
			'flow_ajax'	=> $core->url( 'a', 'flow-ajax', 0 ),
			'flow_rd'	=> defined('REDURL') ? REDURL : BASEURL,
			'flow_rb'	=> REDURLGO,

			'u_stats'	=> $core->url( 'm', 'stats' ),
			'u_flowstat'=> $core->url( 'm', 'flowstat' ),
			'u_lead'	=> $core->url( 'm', 'lead' ),
			'u_sources'	=> $core->url( 'm', 'utm' ),
			'u_domain'	=> $core->url( 'm', 'domain' ),

        	'name'		=> $core->lang['name'],
        	'action'	=> $core->lang['action'],
			'total'		=> $core->lang['total'],
			'offer'		=> $core->lang['offer'],
			'stats'		=> $core->lang['stats'],
			'url'		=> $core->lang['site'],
			'partner'	=> $core->lang['flow_partner_url'],
			'edit'		=> $core->lang['settings'],
			'del'		=> $core->lang['del'],
			'confirm'	=> $core->lang['flow_confirm'],

		));

		if ( $flow ) {
			foreach ( $flow as $o => $fl ) {
				$offer = $core->wmsale->get( 'offer', $o );
				$lands = $core->wmsale->get( 'lands', $o );
				$space = $core->wmsale->get( 'space', $o );

				$core->tpl->block( 'body', 'offer', array(
					'id'		=> $offer['offer_id'],
					'name'		=> $offer['offer_name'],
                	'url'		=> $core->url( 'i', 'offers', $o ),
                	'stats'		=> $core->url( 'm', 'stats' ) . '?o=' . $o,
                	'add'		=> $core->url( 'a', 'flow-add', $o ),
				));

				if ( $lands ) foreach ( $lands as &$ss ) {
                   	$core->tpl->block( 'body', 'offer.site', array(
						'id'	=> $ss['site_id'],
                       	'url'	=> $ss['site_url'],
                       	'name'	=> $ss['site_name'] ? $ss['site_name'] : $ss['site_url'],
						'epc'	=> sprintf( "%0.2f", $ss['site_epc'] ),
						'cr'	=> sprintf( "%0.2f", $ss['site_convert'] ),
					));
				} unset ( $ss );

				if ( $space ) {                   	$core->tpl->block( 'body', 'offer.subsite', array() );
					foreach ( $space as &$ss ) {
                    	$core->tpl->block( 'body', 'offer.subsite.s', array(
							'id'	=> $ss['site_id'],
	                       	'url'	=> $ss['site_url'],
	                       	'name'	=> $ss['site_name'] ? $ss['site_name'] : $ss['site_url'],
							'epc'	=> sprintf( "%0.2f", $ss['site_epc'] ),
							'cr'	=> sprintf( "%0.2f", $ss['site_convert'] ),
						));
					} unset ( $ss );
				}

				if ( $redmn ) {                   	$core->tpl->block( 'body', 'offer.redmn', array() );
					foreach ( $redmn as &$redm ) {
                    	$core->tpl->block( 'body', 'offer.redmn.s', array( 'url' => $redm ));
					} unset ( $redm );
				}

				foreach ( $fl as $f ) {					$core->tpl->block( 'body', 'offer.flow', array(
						'id'		=> $f['flow_id'],
						'name'		=> $search ? $search->highlight( $f['flow_name'] ) : $f['flow_name'],
						'site'		=> $f['flow_site'],
						'space'		=> $f['flow_space'],
						'cb'		=> $f['flow_cb'],
						'param'		=> $f['flow_param'],
						'url'		=> $f['flow_url'],
						'pbu'		=> $f['flow_pbu'],
						'offer'		=> $offer[$f['offer_id']],
						'cr'		=> $f['flow_convert'],
						'epc'		=> rur( $f['flow_epc'] ),
						'total'		=> $f['flow_total'],
	                	'edit'		=> $core->url( 'i', 'flow', $f['flow_id'] ),
	                	'del'		=> $core->url( 'a', 'flow-del', $f['flow_id'] ),
	                	'stats'		=> $core->url( 'm', 'stats' ) . '?f=' . $f['flow_id'],
	                	'u_offer'	=> $core->url( 'm', 'stats' ) . '?o=' . $f['offer_id'],
					));
				}

			} unset ( $f, $flows );
		} else $core->tpl->block( 'body', 'noflow' );

		$core->tpl->output( 'body' );

		$core->footer ();
		$core->_die();

	}

	return false;

}