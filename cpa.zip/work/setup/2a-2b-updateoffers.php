<?php

/*******************************************************************************

 *
 * 	AlterVision Core Framework - CPA platform
 * 	Created by AlterVision - altervision.me
 *  Copyright © 2005-2015 Anton Reznichenko
 *

 *
 *  File: 			cron.php
 *  Description:	Crontab Processing
 *  Author:			Anton 'AlterVision' Reznichenko - altervision13@gmail.com
 *

*******************************************************************************/

error_reporting (0);
define ( 'IN_ALTERCMS_CORE_ONE', true );
define ( 'INTHEWORK', true );
define ( 'PATH', realpath( dirname(__FILE__) . '/../' ). '/' ) ;
require_once PATH . 'core/core.php';

$offer = $core->db->data( "SELECT * FROM ".DB_OFFER );
foreach ( $offer as $o ) {

	$data = array( 'in_default' => 0, 'out_default' => 0, 'out_comps' => '' );

	// Script and Mean-Rand Table
	$mrt = unserialize( $o['offer_mrt'] );
	if ( $mrt ) {
		$mc = count( $mrt );
		$script = array();
		if ( $mc == 1 ) {
			$mk = array_keys( $mrt );
			$data['in_default'] = $mk[0];
		} else {
			$i = 0;
			$tp = array_sum( $mrt );
			foreach ( $mrt as $c => $p ) {
				$i += 1;
				$per = round( ( $p / $tp ) * 100 );
				$tp -= $p;
				$script[] = $per . '% #' . $c;
				if ( $i != $mc ) $data['in_default'] = $c;
			}
			$script = implode( "\n", $script );
			$script = trim( $o['offer_script'] . "\n" . $script );
			$data['in_script'] = $script;
		}
	}

	// Comps
	$comps = $o['offer_comps'] ? unserialize( $o['offer_comps'] ) : false;
	if ( $comps ) {
		$comps = array_keys ( $comps );
		if ( count( $comps ) == 1 ) {
			$data['out_default'] = $comps[0];
		} else $data['out_comps'] = implode( ',', $comps  );
	}

	// Price table
	$data['offer_prt'] = addslashes(serialize( array( 0 => $o['offer_price'] ) ));
	$core->db->edit( DB_OFFER, $data, "offer_id = '".$o['offer_id']."'" );

}
